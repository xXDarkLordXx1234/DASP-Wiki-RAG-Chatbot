
/* First created by JCasGen Fri Dec 19 14:20:47 CET 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.Feature;
import org.apache.uima.jcas.tcas.Annotation_Type;

/** 
 * Updated by JCasGen Sun Jan 04 13:34:25 CET 2009
 * @generated */
public class Summary_Type extends Annotation_Type {
  /** @generated */
  protected FSGenerator getFSGenerator() {return fsGenerator;}
  /** @generated */
  private final FSGenerator fsGenerator = 
    new FSGenerator() {
      public FeatureStructure createFS(int addr, CASImpl cas) {
  			 if (Summary_Type.this.useExistingInstance) {
  			   // Return eq fs instance if already created
  		     FeatureStructure fs = Summary_Type.this.jcas.getJfsFromCaddr(addr);
  		     if (null == fs) {
  		       fs = new Summary(addr, Summary_Type.this);
  			   Summary_Type.this.jcas.putJfsFromCaddr(addr, fs);
  			   return fs;
  		     }
  		     return fs;
        } else return new Summary(addr, Summary_Type.this);
  	  }
    };
  /** @generated */
  public final static int typeIndexID = Summary.typeIndexID;
  /** @generated 
     @modifiable */
  public final static boolean featOkTst = JCasRegistry.getFeatOkTst("de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
 
  /** @generated */
  final Feature casFeat_Sentences;
  /** @generated */
  final int     casFeatCode_Sentences;
  /** @generated */ 
  public int getSentences(int addr) {
        if (featOkTst && casFeat_Sentences == null)
      jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    return ll_cas.ll_getRefValue(addr, casFeatCode_Sentences);
  }
  /** @generated */    
  public void setSentences(int addr, int v) {
        if (featOkTst && casFeat_Sentences == null)
      jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    ll_cas.ll_setRefValue(addr, casFeatCode_Sentences, v);}
    
   /** @generated */
  public int getSentences(int addr, int i) {
        if (featOkTst && casFeat_Sentences == null)
      jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    if (lowLevelTypeChecks)
      return ll_cas.ll_getRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_Sentences), i, true);
    jcas.checkArrayBounds(ll_cas.ll_getRefValue(addr, casFeatCode_Sentences), i);
  return ll_cas.ll_getRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_Sentences), i);
  }
   
  /** @generated */ 
  public void setSentences(int addr, int i, int v) {
        if (featOkTst && casFeat_Sentences == null)
      jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    if (lowLevelTypeChecks)
      ll_cas.ll_setRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_Sentences), i, v, true);
    jcas.checkArrayBounds(ll_cas.ll_getRefValue(addr, casFeatCode_Sentences), i);
    ll_cas.ll_setRefArrayValue(ll_cas.ll_getRefValue(addr, casFeatCode_Sentences), i, v);
  }
 



  /** initialize variables to correspond with Cas Type and Features
	* @generated */
  public Summary_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl)this.casType, getFSGenerator());

 
    casFeat_Sentences = jcas.getRequiredFeatureDE(casType, "Sentences", "uima.cas.FSArray", featOkTst);
    casFeatCode_Sentences  = (null == casFeat_Sentences) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_Sentences).getCode();

  }
}



    