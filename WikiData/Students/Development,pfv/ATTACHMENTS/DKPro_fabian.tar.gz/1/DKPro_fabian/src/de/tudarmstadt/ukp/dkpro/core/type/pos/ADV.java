

/* First created by JCasGen Fri Sep 28 11:42:18 CEST 2007 */
package de.tudarmstadt.ukp.dkpro.core.type.pos;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import de.tudarmstadt.ukp.dkpro.core.type.POS;


/** 
 * Updated by JCasGen Thu Feb 07 11:07:33 CET 2008
 * XML source: /home/zesch/workspace/dkpro_core/desc/annotator/TreeTaggerPosLemma_old.xml
 * @generated */
public class ADV extends POS {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(ADV.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected ADV() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public ADV(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public ADV(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public ADV(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
}

    