package de.tudarmstadt.ukp.dkpro.semantics.annotator;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.util.UimaReflectionUtils;
import de.tudarmstadt.ukp.dkpro.core.util.UimaUtils;
import de.tudarmstadt.ukp.dkpro.semantics.type.AnnotationPair;
import de.tudarmstadt.ukp.dkpro.semantics.type.FilteredToken;

/**
 * Creates a fully connected lexical graph by adding AnnotationPair annotations that represent edges in the graph.
 * 
 * The type of the the annotation used, is indicated by a the AnnotationType parameter.
 * 
 * The annotator puts an edge in the graph, if two annotation co-occur in the window size.
 * 
 * If UsePosFilter is set to true, the annotator expects FilteredToken annotations to be present. It only takes annotation that have a corresponding (same offsets) FilterToken.
 * 
 * @author zesch
 * 
 */
public class CooccurrenceGraphAnnotator extends JCasAnnotator_ImplBase {

	private static final Logger logger = UIMAFramework.getLogger(CooccurrenceGraphAnnotator.class);

    // Size of the context window.
    // Two nodes in the graph are connected  if their corresponding lexical units co-occur within a window of that size. 
    public static final String PARAM_WINDOW_SIZE = "WindowSize";
    private int windowSize = 2;

    public static final String PARAM_USE_POS_FILTER = "UsePosFilter";
    private boolean usePosFilter = false;
    
    public static final String PARAM_ANNOTATION_TYPE = "AnnotationType";
    private String annotationType;
    
    public static final String PARAM_STRING_METHOD = "StringRepresentationMethod";
    private String stringRepresentationMethod;

    // datastructures for representing the cooccurrence graph
    private Map<String, Integer> termMap;
    private Set<Edge> edgeSet;
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
        super.initialize(context);

        annotationType = (String) context.getConfigParameterValue(PARAM_ANNOTATION_TYPE);
        stringRepresentationMethod = (String) context.getConfigParameterValue(PARAM_STRING_METHOD);
        usePosFilter = (Boolean) context.getConfigParameterValue(PARAM_USE_POS_FILTER);

        Object oWindowSize = context.getConfigParameterValue(PARAM_WINDOW_SIZE);
        if (oWindowSize != null) {
            windowSize = (Integer) oWindowSize;
        }
        
    }

    @Override
	public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.CONFIG, "Entering " + this.getClass().getSimpleName());

        // data structures need to be initialized here to provide fresh and clean ones for each run
        // Do NOT put that into initialize()!
        termMap = new HashMap<String, Integer>();
        edgeSet = new HashSet<Edge>();

        initializeGraph(jcas);

        for (Edge edge : edgeSet) {
            AnnotationPair pair = new AnnotationPair(jcas);
            pair.setAnnotation1( edge.annotation1 );
            pair.setAnnotation2( edge.annotation2 );
            pair.setStringRepresentation1( edge.term1 );
            pair.setStringRepresentation2( edge.term2 );
            pair.addToIndexes();
        }
	}



    /**
     * Initializes the co-occurrence graph. 
     * @param jcas The JCas.
     * @throws AnalysisEngineProcessException
     */
    private void initializeGraph(JCas jcas) throws AnalysisEngineProcessException {

        FSIterator filteredTokenIterator = null;
        if (usePosFilter) {
            filteredTokenIterator = ((AnnotationIndex) jcas.getAnnotationIndex(FilteredToken.type)).iterator();
        }
        
        FSIterator sentenceIterator = jcas.getAnnotationIndex(Sentence.type).iterator();
        
        // get the type using reflection
        int type = (Integer) UimaReflectionUtils.getReturnValueByReflection(jcas, annotationType, "getTypeIndexID");
        
        AnnotationIndex index = jcas.getAnnotationIndex(type);

        Queue<WindowItem> window = new LinkedList<WindowItem>();
        int wordId = 0;
        while (sentenceIterator.hasNext()) {
            Sentence sentence = (Sentence) sentenceIterator.next();

            // TODO we cannot use a subiterator here, as we cannot set the type priorities of unknown types. Is there a way to dynamically set type priorities?            
            List<Annotation> annotations = UimaUtils.getAnnotations(index.iterator(), sentence.getBegin(), sentence.getEnd());

            for (Annotation a : annotations) {
                if (usePosFilter && !matchesFilteredToken(a, filteredTokenIterator)) {
                    continue;
                }

                String term = (String) UimaReflectionUtils.getReturnValueByReflection(jcas, a, annotationType, stringRepresentationMethod);
                
                int currentWordId; 
                if (!termMap.containsKey(term)) {
                    // add a new term to the datastructures
                    termMap.put(term, wordId);
                    currentWordId = wordId;
                    wordId++;
                } else {
                    currentWordId = termMap.get(term);
                }
                
                for (WindowItem windowItem : window) {
                    if (!termMap.containsKey(windowItem.getTerm())) {
                        // add a new term to the datastructures
                        termMap.put(windowItem.getTerm(), wordId);
                        wordId++;
                    } 
                    int neighborId = termMap.get(windowItem.getTerm());
                    if (neighborId < currentWordId) {
                        edgeSet.add(new Edge(windowItem.getTerm(), term, windowItem.a, a, neighborId, currentWordId));
                    }
                    else {
                        edgeSet.add(new Edge(term, windowItem.getTerm(), a, windowItem.a, currentWordId, neighborId));
                    }
                }

                // slide the window
                window.offer(new WindowItem(a, term));
                if (window.size() >= windowSize) {
                    window.poll();
                }
            }
        }
    }

    // TODO does only work for single term annotations like Token or Lemma
    /**
     * @param annotation A UIMA annotation.
     * @return Returns true, if the given annotation is included in the FilteredTokens. False otherwise.
     */
    private boolean matchesFilteredToken(Annotation annotation, FSIterator filteredTokenIterator) {
        while (filteredTokenIterator.hasNext()) {
            FilteredToken ft = (FilteredToken) filteredTokenIterator.next();
            
            if (ft.getBegin() <= annotation.getBegin() && ft.getEnd() >= annotation.getEnd()) {
                filteredTokenIterator.moveToFirst();
                return true;
            }
        }
        
        filteredTokenIterator.moveToFirst();
        return false;
    }
    
    protected class WindowItem {
        private Annotation a;
        private String term;

        public WindowItem(Annotation a, String term) {
            super();
            this.a = a;
            this.term = term;
        }

        public Annotation getA() {
            return a;
        }

        public void setA(Annotation a) {
            this.a = a;
        }

        public String getTerm() {
            return term;
        }

        public void setTerm(String term) {
            this.term = term;
        }
    }

    protected class Edge {
        private Annotation annotation1;
        private Annotation annotation2;
        private String term1;
        private String term2;
        private int nodeId1;
        private int nodeId2;
        public Edge(String term1, String term2, Annotation a1, Annotation a2, int nodeId1, int nodeId2) {
            super();
            this.term1 = term1;
            this.term2 = term2;
            this.annotation1 = a1;
            this.annotation2 = a2;
            this.nodeId1 = nodeId1;
            this.nodeId2 = nodeId2;
        }
        public int getNodeId1() {
            return nodeId1;
        }
        public void setNodeId1(int nodeId1) {
            this.nodeId1 = nodeId1;
        }
        public int getNodeId2() {
            return nodeId2;
        }
        public void setNodeId2(int nodeId2) {
            this.nodeId2 = nodeId2;
        }
        public String getTerm1() {
            return term1;
        }
        public void setTerm1(String term1) {
            this.term1 = term1;
        }
        public String getTerm2() {
            return term2;
        }
        public void setTerm2(String term2) {
            this.term2 = term2;
        }
        public Annotation getAnnotation1() {
            return annotation1;
        }
        public void setAnnotation1(Annotation annotation1) {
            this.annotation1 = annotation1;
        }
        public Annotation getAnnotation2() {
            return annotation2;
        }
        public void setAnnotation2(Annotation annotation2) {
            this.annotation2 = annotation2;
        }
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(nodeId1);
            sb.append("-");
            sb.append(nodeId2);
            return sb.toString();
        }
        @Override
        public int hashCode() {
            final int PRIME = 31;
            int result = 1;
            result = PRIME * result + nodeId1;
            result = PRIME * result + nodeId2;
            return result;
        }
        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            final Edge other = (Edge) obj;
            if (nodeId1 != other.nodeId1)
                return false;
            if (nodeId2 != other.nodeId2)
                return false;
            return true;
        }
    }
}
