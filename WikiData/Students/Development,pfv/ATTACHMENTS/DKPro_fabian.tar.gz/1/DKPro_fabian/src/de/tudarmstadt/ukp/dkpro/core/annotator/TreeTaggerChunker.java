package de.tudarmstadt.ukp.dkpro.core.annotator;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceAccessException;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.annotator.util.chunker.TreeTaggerChunkMapping;
import de.tudarmstadt.ukp.dkpro.core.annotator.util.chunker.TreeTaggerChunkerWrapper;
import de.tudarmstadt.ukp.dkpro.core.type.Token;
import de.tudarmstadt.ukp.dkpro.core.util.StringUtils;

/**
 * Annotator class for annotating TreeTagger chunks
 * @author Cigdem Toprak
 * @author Delphine Bernhard
 */
public class TreeTaggerChunker extends JCasAnnotator_ImplBase {

    private static final Logger logger = UIMAFramework.getLogger(TreeTaggerChunker.class);
    
    private static final String PARAM_LANGUAGE = "LanguageCode";
    
    private static final String RESOURCE_TREETAGGER = "TreeTagger";

    private static final String PACKAGE = "de.tudarmstadt.ukp.dkpro.core.type.chunks.";
    
    private TreeTaggerChunkerWrapper mTaggerChunkerWrapper;
    private String languageCode = "en";             // default
    private String treeTaggerPath;    
    
    public void initialize(UimaContext aContext) throws ResourceInitializationException {
        // This saves the value of aContext in a field and makes
        // it available via the getContext() method of the superclass
        super.initialize(aContext);
        
        // Get the configuration parameter values from the descriptor 
        if ((String) getContext().getConfigParameterValue(PARAM_LANGUAGE) != null) {
            languageCode = (String) getContext().getConfigParameterValue(PARAM_LANGUAGE);
        }
        
        treeTaggerPath = null;
        try {
            treeTaggerPath = getContext().getResourceURL(RESOURCE_TREETAGGER).getFile();
        } catch (ResourceAccessException e1) {
            throw new ResourceInitializationException(e1);
        }

        // Create the tagger chunker wrapper instance
        try {
            mTaggerChunkerWrapper = new TreeTaggerChunkerWrapper(treeTaggerPath, languageCode);
        } catch (IOException e) {
            throw new ResourceInitializationException(e);
        }
    }
    
    public void process(JCas aJCas) throws AnalysisEngineProcessException {
        logger.log(Level.FINE, "entering chunker");
        
        // run the chunker
        try {
            mTaggerChunkerWrapper.runTagger(aJCas.getDocumentText());
        } catch (IOException e) {
            try {
                logger.log(Level.SEVERE,"Have to restart TaggerChunkerWrapperAlive due to exception. Tokendoctext: " + aJCas.getDocumentText() ,e);
                mTaggerChunkerWrapper.destroy();
                mTaggerChunkerWrapper = new TreeTaggerChunkerWrapper(treeTaggerPath, languageCode);
                mTaggerChunkerWrapper.runTagger(aJCas.getDocumentText());
            } catch (IOException e2) {
                logger.log(Level.SEVERE,"TaggerChunkerWrapperAlive failed second time.");
                throw new AnalysisEngineProcessException(e2);
            }           
        }
        
        // Get the chunker results (chunks and number of tokens for each individual chunk
        List<String> chunkTypes = mTaggerChunkerWrapper.getChunks();
        List<List<String>> chunkTokens = mTaggerChunkerWrapper.getChunkTokens();

        AnnotationIndex tokenIndex = (AnnotationIndex) aJCas.getAnnotationIndex(Token.type);
        FSIterator tokenIter = tokenIndex.iterator();

        for (int i=0; i < chunkTypes.size(); i++) {
            FSIterator tokenIterCopy = tokenIter.copy();
            int[] offset = getOffsets(tokenIter, chunkTokens.get(i));

            // For embedded chunks, the normal way of finding offsets does not work (we would have to go back in the iteration as parts of the embedded chunk (or the whole embedded chunk) have already been consumed).
            // We have to go back in the iterator
            // The method might sometimes find a chunk with a wrong offset (e.g. if a short chunk is directly repeated in a document).
            if (offset == null) {
                FSIterator tokenIterCopy2 = tokenIterCopy.copy();
                tokenIterCopy.moveToPrevious();
                tokenIterCopy.moveToPrevious();
                tokenIterCopy.moveToPrevious();
                tokenIterCopy.moveToPrevious();
                tokenIterCopy.moveToPrevious();
                offset = getOffsets(tokenIterCopy2, chunkTokens.get(i));
            }
            
            // collapse spaces to find matching tokens
            if (offset == null) {
                offset = getRelaxedOffsets(tokenIterCopy, chunkTokens.get(i));
            }
            
            if (offset != null) {
                addChunkAnnotation(aJCas, offset[0], offset[1], chunkTypes.get(i));
            }
            else {
                logger.log(Level.WARNING, "No more tokens, but chunks left after relaxing offsets.");
                logger.log(Level.WARNING, chunkTokens.toString());
            }
        }       
    }
    
    /**
     * As the TreeTaggerChunker does its own tokenization, we have to find the right UIMA Token annotations for the tokens returned by TreeTaggerChunker. 
     * @param tokenIter An iterator over UIMA tokens.
     * @param chunkTokens The tokens as returned by TreeTaggerChunker.
     * @return The begin and end offset of the chunk retrieved from the underlying UIMA Token annotations. Or null, if no UIMA tokens for this chunk could be found.
     */
    private int[] getOffsets(FSIterator tokenIter, List<String> chunkTokens) {
        int[] offsets = new int[2];
        
        if (!tokenIter.hasNext()) {
            logger.log(Level.WARNING, "No more tokens, but chunks left.");
            logger.log(Level.WARNING, chunkTokens.toString());
            return null;
        }
        
        Token startToken = null;
        Token endToken   = null;

        // save currentToken and get back to old offset 
        Token currentToken = (Token) tokenIter.next();
        tokenIter.moveToPrevious();
        
        // find start token
        boolean startTokenFound = false;
        while (tokenIter.hasNext() && !startTokenFound) {
            Token t = (Token) tokenIter.next();
            if (t.getCoveredText().equals(chunkTokens.get(0))) {
                startToken = t;
                startTokenFound = true;
            }
        }

        // if no start token has been found, then the chunk cannot be found
        if (startToken == null) {
            tokenIter.moveTo(currentToken); // reset tokenIter
            return null;
        }
        
        if (chunkTokens.size() == 1) {
            offsets[0] = startToken.getBegin();
            offsets[1] = startToken.getEnd();
            return offsets;
        }
        
        // beginning with the start token, all tokens must be consecutive
        for (int i=1; i<chunkTokens.size(); i++) {
            if (!tokenIter.hasNext()) {
                tokenIter.moveTo(currentToken); // reset tokenIter, as it might has run to far down while searching
                return null;
            }
            
            Token t = (Token) tokenIter.next();
            if (!t.getCoveredText().equals(chunkTokens.get(i))) {
                tokenIter.moveTo(currentToken); // reset tokenIter, as it might has run to far down while searching
                return null;
            }
            endToken = t;
        }

        if (startToken != null && endToken != null) {
            offsets[0] = startToken.getBegin();
            offsets[1] = endToken.getEnd();
        }
        
        return offsets;
    }

    /**
     * Collapse spaces to find matching tokens.
     * @param tokenIter An iterator over UIMA tokens.
     * @param chunkTokens The tokens as returned by TreeTaggerChunker.
     * @return The begin and end offset of the chunk retrieved from the underlying UIMA Token annotations. Or null, if no UIMA tokens for this chunk could be found.
     */
    private int[] getRelaxedOffsets(FSIterator tokenIter, List<String> chunkTokens) {
        int[] offsets = new int[2];

        Token startToken = null;
        Token endToken = null;
        
        String concatenatedChunkTokens = StringUtils.join(chunkTokens, "");
        
        String concatenatedSourceTokens = "";
        
        boolean found = false;
        while (tokenIter.hasNext() && !found) {
            Token t = (Token) tokenIter.next();
            concatenatedSourceTokens += t.getCoveredText();
            if (concatenatedChunkTokens.startsWith(t.getCoveredText())) {
                startToken = t;
            }
            if (concatenatedChunkTokens.equals(concatenatedSourceTokens)) {
                endToken = t;
                found = true;
            }
        }
        
        if (startToken != null && endToken != null) {
            offsets[0] = startToken.getBegin();
            offsets[1] = endToken.getEnd();
        }
        
        return offsets;
    }

    
//    /**
//     * As the TreeTaggerChunker does its own tokenization, we have to find the right UIMA Token annotations for the tokens returned by TreeTaggerChunker. 
//     * @param tokenIter An iterator over UIMA tokens.
//     * @param chunkTokens The tokens as returned by TreeTaggerChunker.
//     * @return The begin and end offset of the chunk retrieved from the underlying UIMA Token annotations.
//     */
//    private int[] getOffsets(FSIterator tokenIter, List<String> chunkTokens) {
//        int[] offsets = new int[2];
//        
//        if (!tokenIter.hasNext()) {
//            logger.log(Level.WARNING, "No more tokens, but chunks left.");
//        }
//        
//        Token startToken = null;
//        Token endToken = null;
//        
//        //Tokenisation by TreeTagger and tokenisation by the UIMA tokeniser is different
//        //Quick hack to prevent token mapping errors: remove whitespace
//        StringBuffer chunkText = new StringBuffer();
//        for (int i=0; i<chunkTokens.size(); i++) {
//            chunkText.append(chunkTokens.get(i));
//        }
//
//System.out.println("C:" + chunkText);
//        
//        Token nextToken = null;
//        while (chunkText.length() > 0) {
//            nextToken = getNextToken(chunkText, tokenIter);
//            if (nextToken == null) {
//                break;
//            }
//            if (startToken == null) {
//                startToken = nextToken;
//            }
//        }
//        endToken = nextToken;
//        if (startToken != null && endToken != null) {
//            offsets[0] = startToken.getBegin();
//            offsets[1] = endToken.getEnd();
//        }
//        
//        return offsets;
//    }
//    
//    private Token getNextToken(StringBuffer chunk, FSIterator tokenIter) {
//        while (tokenIter.hasNext()) {
//            Token t = (Token) tokenIter.next();
//            String text = t.getCoveredText();
//System.out.println(text);
//            String chunkString = chunk.toString();
//            if (chunkString.startsWith(text)) {
//              chunk.replace(0, text.length(), "");
//              return t;
//            } else if (text.startsWith(chunkString) || text.endsWith(chunkString) || chunkString.endsWith(text)) {
//              chunk.replace(0, chunk.length(), "");
//              return t;
//            }
//        }
//        return null;
//    }
    
    /**
     * Add the correct chunk annotation for the given tag.
     * @param begin The begin offset of the annotation.
     * @param end The end offset of the annotation.
     * @param chunk The chunk string.
     * @throws AnalysisEngineProcessException 
     */
    private void addChunkAnnotation(JCas aJCas, int begin, int end, String chunk) throws AnalysisEngineProcessException {

        // TODO this depends on the language of the source document and the tagset that is valid for this language

        String setBeginMethodName      = "setBegin";
        String setEndMethodName        = "setEnd";
        String setChunkValueMethodName = "setChunkValue";
        String addToIndexesMethodName  = "addToIndexes";
        
        // create the necessary objects and methods
        String posClassName = PACKAGE + getChunkClass(chunk);
 
        Class posClass;
        Method setBegin;
        Method setEnd;
        Method setPosValue;
        Method addToIndexes;
        
        Object chunkInstance;
            try {
                posClass = Class.forName(posClassName);

                Class[] setBeginParameterTypes     = new Class[]{int.class};
                Class[] setEndParameterTypes       = new Class[]{int.class};
                Class[] setChunkValueParameterTypes  = new Class[]{String.class};
                Class[] addToIndexesParameterTypes = new Class[]{};
                
                setBegin     = posClass.getMethod(setBeginMethodName,      setBeginParameterTypes);
                setEnd       = posClass.getMethod(setEndMethodName,        setEndParameterTypes);
                setPosValue  = posClass.getMethod(setChunkValueMethodName, setChunkValueParameterTypes);
                addToIndexes = posClass.getMethod(addToIndexesMethodName,  addToIndexesParameterTypes);
                
                Class[] constructorTypes = new Class[]{JCas.class};
                Constructor constructor = posClass.getConstructor(constructorTypes);
              
                Object[] constructorArguments = new Object[]{aJCas};
                chunkInstance = constructor.newInstance(constructorArguments);

                Object[] setBeginArguments      = new Object[]{begin};
                Object[] setEndArguments        = new Object[]{end};
                Object[] setChunkValueArguments = new Object[]{chunk};
                
                // invoke the setter methods on the POS object
                setBegin.invoke(chunkInstance, setBeginArguments);
                setEnd.invoke(chunkInstance, setEndArguments);
                setPosValue.invoke(chunkInstance, setChunkValueArguments);
                addToIndexes.invoke(chunkInstance);
                
            } catch (ClassNotFoundException e) {
                logger.log(Level.SEVERE, "No such class " + posClassName, new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (NoSuchMethodException e) {
                logger.log(Level.SEVERE, "No such method", new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (IllegalArgumentException e) {
                logger.log(Level.SEVERE, "You can call this method, but not with THIS arguments.", new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (IllegalAccessException e) {
                logger.log(Level.SEVERE, "You're not allowed to call this method.", new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (InvocationTargetException e) {
                logger.log(Level.SEVERE, "Invoked method has thrown an exception.", new Throwable(e.getCause()));
                throw new AnalysisEngineProcessException(e);
            } catch (InstantiationException e) {
                logger.log(Level.SEVERE, "Instantiation exception", new Throwable());
                throw new AnalysisEngineProcessException(e);
            }
        
    }

    private String getChunkClass(String chunk) throws AnalysisEngineProcessException {
        Map<String, String> chunkMap = null;
        if (languageCode.equals("en")) {
            chunkMap = TreeTaggerChunkMapping.getEnglishChunkMap(); 
        }
        else if (languageCode.equals("de")) {
            chunkMap = TreeTaggerChunkMapping.getGermanChunkMap(); 
        }
        else {
            throw new AnalysisEngineProcessException(new Throwable("There is no chunk mapping for languageCode " + this.languageCode));
        }
        
        if (chunkMap.containsKey(chunk)) {
            return chunkMap.get(chunk);
        }
        else {
            logger.log(Level.WARNING, "ChunkMap does not contain chunk: " + chunk);
            return "O"; // return default "Other" tag for this tag
        }
        
    }

}