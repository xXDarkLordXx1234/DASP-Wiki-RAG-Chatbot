

/* First created by JCasGen Fri Dec 19 14:23:18 CET 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.tcas.Annotation;


/** 
 * Updated by JCasGen Tue Dec 23 15:48:39 CET 2008
 * XML source: E:/workspace/dkpro_semantics/desc/annotator/summarization/LexRankNodeDegreeSummarizer.xml
 * @generated */
public class SummarySourceDocument extends Annotation {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(SummarySourceDocument.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected SummarySourceDocument() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public SummarySourceDocument(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public SummarySourceDocument(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public SummarySourceDocument(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
}

    