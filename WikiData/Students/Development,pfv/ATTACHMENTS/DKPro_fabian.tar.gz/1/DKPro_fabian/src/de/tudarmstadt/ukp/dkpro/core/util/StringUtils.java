package de.tudarmstadt.ukp.dkpro.core.util;

import static de.tudarmstadt.ukp.dkpro.core.util.IOUtil.close;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.Collection;
import java.util.Iterator;
import java.util.regex.Pattern;

public final 
class StringUtils 
{
    public static final String LF = System.getProperty("line.separator"); 

    private StringUtils() 
    {
    	// No instance of this class
	}
    
    /**
     * Joins the elements of a collection into a string.
     * @param c The collection which elements should be joined.
     * @param delimiter String that is introduced between two joined elements.
     * @return The joined string.
     */
    public static String join(Collection c, String delimiter) {
        StringBuilder sb = new StringBuilder();
        Iterator iter = c.iterator();
        while (iter.hasNext()) {
            sb.append(iter.next());
            if (iter.hasNext()) {
                sb.append(delimiter);
            }
        }
        return sb.toString();
    }
    /**
	 * <p>Remove the characters at the beginning and end matching the given regular expression. Every time a character 
	 * is read from head to see if it matches to the given pattern, if it matches, the character is removed from text, it proceeds 
	 * until no matching is found. Then it does the same thing from the end of the text.  
	 *  
	 * @param text a string
	 * @param regex character pattern for each single character
	 * @return a striped string.
	 */
	public static String strip(String text,String regex){
		int startIndex = 0;
		boolean match = true;
		for(int i = 0 ; i < text.length() && match ; i++){
			if(!Pattern.matches(regex,String.valueOf(text.charAt(i)))){
				startIndex = i;
				match = false;
			}
		}
		int endIndex = text.length();
		match = true;
		for(int i = text.length() ; i > 0 && match; i--){
			if(!Pattern.matches(regex,String.valueOf(text.charAt(i - 1)))){
				endIndex = i;
				match = false;
			}
		}
		
		if(endIndex > startIndex){
			return text.substring(startIndex,endIndex);
		}else{
			return text;
		}
	}
    
    public static String collection2String(Collection c, String info) {
        StringBuilder sb = new StringBuilder();
        sb.append(LF);
        sb.append(info); sb.append(LF);
        for (Object item : c) {
            sb.append(item); sb.append(LF);
        }
        sb.append(LF);
        return sb.toString();
    }
    
    /**
     * Checks if the given character sequence contains only whitespace characters.
     * 
     * @param s a character sequence.
     * @return if there are only whitespaces in the given sequence.
     */
    public static
    boolean isWhitespace(
    		final CharSequence s)
    {
    	return isWhitespace(s, 0, s.length());
    }
    
    /**
     * Checks if the given character sequence contains only whitespace
     * characters starting at <code>start</code> and ending at <code>end-1</code>.
     * 
     * @param s a character sequence.
     * @param start the left boundary (inclusive).
     * @param end the right boundary (exclusive).
     * @return if there are only whitespace in the given sequence.
     */
    public static
    boolean isWhitespace(
    		final CharSequence s,
    		final int start,
    		final int end)
    {
    	for (int i = start; i < end; i++) {
    		if (!Character.isWhitespace(s.charAt(i))) {
    			return false;
    		}
    	}
    	return true;
    }
    
    /**
     * Load a string from a file using the UTF-8 encoding.
     * 
     * @param aFile the file to read from.
     * @return the string.
     */
    public static
    String loadString(
    		final File aFile)
    throws IOException
    {
    	return loadString(new FileInputStream(aFile));
    }

    /**
     * Load a string from an URL using the UTF-8 encoding.
     * 
     * @param aUrl the URL to load from.
     * @return the string.
     */
    public static
    String loadString(
    		final URL aUrl)
    throws IOException
    {
    	return loadString(aUrl.openStream());
    }

    /**
     * Load a string from a stream using the UTF-8 encoding. The stream will be
     * closed by this method.
     * 
     * @param aIs the stream to read from.
     * @return the string.
     */
    public static
    String loadString(
    		final InputStream aIs)
    throws IOException
    {
    	Reader r = null;
    	try {
    		char[] buffer = new char[16000];
    		StringBuilder sb = new StringBuilder();
    		r = new InputStreamReader(aIs, "UTF-8");
    		int len = r.read(buffer, 0, buffer.length);
    		while (len > 0) {
    			sb.append(buffer, 0, len);
    			len = r.read(buffer, 0, buffer.length);
    		}
    		return sb.toString();
    	}
    	finally {
    		close(r);
    	}
    }
}
