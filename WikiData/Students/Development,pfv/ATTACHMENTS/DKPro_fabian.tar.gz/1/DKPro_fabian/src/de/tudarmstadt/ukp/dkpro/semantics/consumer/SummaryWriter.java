package de.tudarmstadt.ukp.dkpro.semantics.consumer;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.cas.FSArray;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import de.tudarmstadt.ukp.dkpro.semantics.type.Summary;
import de.tudarmstadt.ukp.dkpro.semantics.type.SummarySourceDocument;

/**
 * Writes summaries.
 * @author zesch
 *
 */
// TODO should really write the summary and read the parameter
public class SummaryWriter extends JCasAnnotator_ImplBase {
    
    public static final Logger logger = UIMAFramework.getLogger(SummaryWriter.class);

    private static final String LF = System.getProperty("line.separator");
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
        super.initialize(context);
    }
    
    @Override
    public void process(JCas jcas) throws AnalysisEngineProcessException {

        StringBuilder summaryInfo = new StringBuilder();
        summaryInfo.append("SUMMARY SOURCE DOCUMENTS");  summaryInfo.append(LF);
        FSIterator summarySourceDocumentIter = jcas.getAnnotationIndex(SummarySourceDocument.type).iterator();
        while (summarySourceDocumentIter.hasNext()) {
            SummarySourceDocument ssd = (SummarySourceDocument) summarySourceDocumentIter.next();
            summaryInfo.append("----------------------------------------------------------------------"); summaryInfo.append(LF);
            summaryInfo.append(ssd.getCoveredText()); summaryInfo.append(LF);
            summaryInfo.append("----------------------------------------------------------------------"); summaryInfo.append(LF);
        }
        
        StringBuilder summaryString = new StringBuilder();
        summaryString.append("SUMMARY");  summaryString.append(LF);
        FSIterator summaryIter = jcas.getAnnotationIndex(Summary.type).iterator();
        while (summaryIter.hasNext()) {
            summaryString.append("----------------------------------------------------------------------"); summaryString.append(LF);
            Summary summary = (Summary) summaryIter.next();
            FSArray sentences = summary.getSentences();
            for (int i=0; i<sentences.size(); i++) {
                Sentence sentence = (Sentence) sentences.get(i);
                summaryString.append( sentence.getCoveredText() );
                summaryString.append(LF);
            }
            summaryString.append("----------------------------------------------------------------------"); summaryString.append(LF);
            summaryString.append(LF);
        }

        System.out.println(summaryInfo.toString());
        System.out.println(summaryString.toString());
    }
}