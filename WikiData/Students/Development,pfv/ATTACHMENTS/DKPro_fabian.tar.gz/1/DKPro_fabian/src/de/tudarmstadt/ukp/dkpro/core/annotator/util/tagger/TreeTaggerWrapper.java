package de.tudarmstadt.ukp.dkpro.core.annotator.util.tagger;

import java.io.IOException;
import java.util.List;

public interface TreeTaggerWrapper {

	/**
	 * Returns the input text. 
	 * @return The input text.
	 */
	public abstract List<String> getTokens();

	/**
	 * Returns the lemmas assigned to the input text.
	 * Ordering is the same as for the tokens. 
	 * @return Lemmas assigned to input text.
	 */
	public abstract List<String> getLemmas();

	/**
	 * Returns the tags assigned to the input text. 
	 * Ordering is the same as for the tokens. 
	 * @return Tags assigned to input text.
	 */
	public abstract List<String> getTags();

	/**
	 * Runs TreeTagger on the input tokens.
	 * @param tokens The tokens to be processed.
	 * @return TaggerOutput An object containing tokens, lemmas and POS.
	 * @throws IOException 
	 */
	public abstract void runTagger(List<String> tokens) throws IOException;

	/**
	 * Runs TreeTagger on the input tokens.
	 * @param tokens The tokens to be processed.
	 * @return TaggerOutput An object containing tokens, lemmas and POS.
	 * @throws IOException
	 */
	public abstract void runTagger(String tokens) throws IOException;

	public abstract void destroy();

}