

/* First created by JCasGen Fri Jul 04 18:11:30 CEST 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import de.tudarmstadt.ukp.dkpro.core.type.Token;


/** 
 * Updated by JCasGen Tue Aug 05 14:19:58 CEST 2008
 * XML source: /home/zesch/workspace/dkpro_semantics/desc/annotator/keywords/PageRankKeywordExtractor.xml
 * @generated */
public class FilteredToken extends Token {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(FilteredToken.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected FilteredToken() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public FilteredToken(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public FilteredToken(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public FilteredToken(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
}

    