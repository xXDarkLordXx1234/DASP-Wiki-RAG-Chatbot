

/* First created by JCasGen Wed Sep 10 17:32:54 CEST 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.tcas.Annotation;


/** 
 * Updated by JCasGen Wed Jan 28 13:01:14 CET 2009
 * XML source: /home/zesch/workspace/dkpro_semantics/desc/type/KeyphraseCandidatePair.xml
 * @generated */
public class KeyphraseCandidate extends Annotation {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(KeyphraseCandidate.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected KeyphraseCandidate() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public KeyphraseCandidate(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public KeyphraseCandidate(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public KeyphraseCandidate(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
 
    
  //*--------------*
  //* Feature: keyphrase

  /** getter for keyphrase - gets 
   * @generated */
  public String getKeyphrase() {
    if (KeyphraseCandidate_Type.featOkTst && ((KeyphraseCandidate_Type)jcasType).casFeat_keyphrase == null)
      jcasType.jcas.throwFeatMissing("keyphrase", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidate");
    return jcasType.ll_cas.ll_getStringValue(addr, ((KeyphraseCandidate_Type)jcasType).casFeatCode_keyphrase);}
    
  /** setter for keyphrase - sets  
   * @generated */
  public void setKeyphrase(String v) {
    if (KeyphraseCandidate_Type.featOkTst && ((KeyphraseCandidate_Type)jcasType).casFeat_keyphrase == null)
      jcasType.jcas.throwFeatMissing("keyphrase", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidate");
    jcasType.ll_cas.ll_setStringValue(addr, ((KeyphraseCandidate_Type)jcasType).casFeatCode_keyphrase, v);}    
  }

    