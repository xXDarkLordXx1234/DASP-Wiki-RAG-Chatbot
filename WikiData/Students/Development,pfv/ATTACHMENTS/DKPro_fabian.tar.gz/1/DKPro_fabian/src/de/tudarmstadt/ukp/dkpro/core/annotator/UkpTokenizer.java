package de.tudarmstadt.ukp.dkpro.core.annotator;

import java.text.BreakIterator;
import java.text.ParsePosition;
import java.util.Locale;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.type.Token;

public class UkpTokenizer extends JCasAnnotator_ImplBase {

	public static final Logger logger = UIMAFramework
			.getLogger(UkpTokenizer.class);
	public static final String PARAM_LOCALE = "Locale";
	public static final String PARAM_SPLIT_AT_APOSTROPHE = "SplitAtApostrophe";
	private BreakIterator wordIterator;
	private boolean splitAtApostrophe;

	@Override
	public void initialize(UimaContext aContext)
			throws ResourceInitializationException {
		super.initialize(aContext);

		String localeName = (String) aContext
				.getConfigParameterValue(PARAM_LOCALE);
		if (localeName == null || localeName == "") {
			wordIterator = BreakIterator.getWordInstance();

		} else {
			Locale locale = new Locale(localeName);
			wordIterator = BreakIterator.getWordInstance(locale);

		}
		splitAtApostrophe = false;
		Object paramSplit = aContext.getConfigParameterValue(PARAM_SPLIT_AT_APOSTROPHE);
		if(paramSplit!=null)
			splitAtApostrophe = (Boolean)paramSplit;
	}

	static abstract class Maker {
		abstract Annotation newAnnotation(JCas jcas, int start, int end);
	}

	JCas jcas;
	String input;
	ParsePosition pp = new ParsePosition(0);

	// *************************************************************
	// * process *
	// *************************************************************
	@Override
	public void process(JCas jcas) throws AnalysisEngineProcessException {
		this.jcas = jcas;

		AnnotationIndex sentenceIndex = jcas.getJFSIndexRepository()
				.getAnnotationIndex(Sentence.type);

		FSIterator sentenceIterator = sentenceIndex.iterator();

		// Create Annotations
		while (sentenceIterator.hasNext()) {
			Sentence sentence = (Sentence) sentenceIterator.next();
			String sentenceText = sentence.getCoveredText();
			// logger.log(Level.INFO,"tokenising: "+sentenceText);
			wordIterator.setText(sentenceText);
			int sstart = sentence.getBegin();
			// logger.log(Level.INFO,"sbegin: "+sstart+" send:
			// "+sentence.getEnd());
			for (int end = wordIterator.next(), start = wordIterator.first(); end != BreakIterator.DONE; start = end, end = wordIterator
					.next()) {
				// eliminate all-whitespace tokens
				// logger.log(Level.INFO,"begin: "+start+" end: "+end);

				boolean isWhitespace = true;
				for (int i = start; i < end; i++) {
					// logger.log(Level.INFO,"i:"+i);

					if (!Character.isWhitespace(sentenceText.charAt(i))) {
						isWhitespace = false;
						break;
					}
				}

				if (!isWhitespace) {
					if(splitAtApostrophe) {
						// check for ...'...
						String tokenText = sentenceText.substring(start, end);
						int index = tokenText.indexOf("'");
						// if ' occurs and is not the first character (e.g. the token could just be ')
						if(index>0) {
							// split token into two
							// part 1
							Token token = new Token(jcas, sstart + start, sstart + start + index);
							token.addToIndexes();
							// part 2 (including ')
							token = new Token(jcas, sstart + start + index, sstart + end);
							token.addToIndexes();
						} else {
							// add complete token
							Token token = new Token(jcas, sstart + start, sstart + end);
							token.addToIndexes();
						}
					} else {
						// add complete token
						Token token = new Token(jcas, sstart + start, sstart + end);
						token.addToIndexes();
					}
				}
			}
		}
	}

}
