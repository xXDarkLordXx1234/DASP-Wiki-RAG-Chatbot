
/* First created by JCasGen Fri Dec 19 17:24:36 CET 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.Feature;
import org.apache.uima.jcas.tcas.Annotation_Type;

/** 
 * Updated by JCasGen Sun Jan 04 13:33:23 CET 2009
 * @generated */
public class SentencePair_Type extends Annotation_Type {
  /** @generated */
  protected FSGenerator getFSGenerator() {return fsGenerator;}
  /** @generated */
  private final FSGenerator fsGenerator = 
    new FSGenerator() {
      public FeatureStructure createFS(int addr, CASImpl cas) {
  			 if (SentencePair_Type.this.useExistingInstance) {
  			   // Return eq fs instance if already created
  		     FeatureStructure fs = SentencePair_Type.this.jcas.getJfsFromCaddr(addr);
  		     if (null == fs) {
  		       fs = new SentencePair(addr, SentencePair_Type.this);
  			   SentencePair_Type.this.jcas.putJfsFromCaddr(addr, fs);
  			   return fs;
  		     }
  		     return fs;
        } else return new SentencePair(addr, SentencePair_Type.this);
  	  }
    };
  /** @generated */
  public final static int typeIndexID = SentencePair.typeIndexID;
  /** @generated 
     @modifiable */
  public final static boolean featOkTst = JCasRegistry.getFeatOkTst("de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
 
  /** @generated */
  final Feature casFeat_Sentence1;
  /** @generated */
  final int     casFeatCode_Sentence1;
  /** @generated */ 
  public int getSentence1(int addr) {
        if (featOkTst && casFeat_Sentence1 == null)
      jcas.throwFeatMissing("Sentence1", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    return ll_cas.ll_getRefValue(addr, casFeatCode_Sentence1);
  }
  /** @generated */    
  public void setSentence1(int addr, int v) {
        if (featOkTst && casFeat_Sentence1 == null)
      jcas.throwFeatMissing("Sentence1", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    ll_cas.ll_setRefValue(addr, casFeatCode_Sentence1, v);}
    
  
 
  /** @generated */
  final Feature casFeat_Sentence2;
  /** @generated */
  final int     casFeatCode_Sentence2;
  /** @generated */ 
  public int getSentence2(int addr) {
        if (featOkTst && casFeat_Sentence2 == null)
      jcas.throwFeatMissing("Sentence2", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    return ll_cas.ll_getRefValue(addr, casFeatCode_Sentence2);
  }
  /** @generated */    
  public void setSentence2(int addr, int v) {
        if (featOkTst && casFeat_Sentence2 == null)
      jcas.throwFeatMissing("Sentence2", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    ll_cas.ll_setRefValue(addr, casFeatCode_Sentence2, v);}
    
  
 
  /** @generated */
  final Feature casFeat_Similarity;
  /** @generated */
  final int     casFeatCode_Similarity;
  /** @generated */ 
  public double getSimilarity(int addr) {
        if (featOkTst && casFeat_Similarity == null)
      jcas.throwFeatMissing("Similarity", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    return ll_cas.ll_getDoubleValue(addr, casFeatCode_Similarity);
  }
  /** @generated */    
  public void setSimilarity(int addr, double v) {
        if (featOkTst && casFeat_Similarity == null)
      jcas.throwFeatMissing("Similarity", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    ll_cas.ll_setDoubleValue(addr, casFeatCode_Similarity, v);}
    
  



  /** initialize variables to correspond with Cas Type and Features
	* @generated */
  public SentencePair_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl)this.casType, getFSGenerator());

 
    casFeat_Sentence1 = jcas.getRequiredFeatureDE(casType, "Sentence1", "de.tudarmstadt.ukp.dkpro.core.type.Sentence", featOkTst);
    casFeatCode_Sentence1  = (null == casFeat_Sentence1) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_Sentence1).getCode();

 
    casFeat_Sentence2 = jcas.getRequiredFeatureDE(casType, "Sentence2", "de.tudarmstadt.ukp.dkpro.core.type.Sentence", featOkTst);
    casFeatCode_Sentence2  = (null == casFeat_Sentence2) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_Sentence2).getCode();

 
    casFeat_Similarity = jcas.getRequiredFeatureDE(casType, "Similarity", "uima.cas.Double", featOkTst);
    casFeatCode_Similarity  = (null == casFeat_Similarity) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_Similarity).getCode();

  }
}



    