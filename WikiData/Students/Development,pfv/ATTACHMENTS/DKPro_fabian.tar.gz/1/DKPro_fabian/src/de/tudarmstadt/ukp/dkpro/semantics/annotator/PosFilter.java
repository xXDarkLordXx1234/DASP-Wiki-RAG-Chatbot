package de.tudarmstadt.ukp.dkpro.semantics.annotator;

import java.util.ArrayList;
import java.util.List;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.POS;
import de.tudarmstadt.ukp.dkpro.core.type.Token;
import de.tudarmstadt.ukp.dkpro.semantics.type.FilteredToken;

/**
 * This class filters tokens for parts-of-speech and shifts their annotation
 * from Token to FilteredToken.
 * 
 * @author Florian Schwager
 * 
 */
public class PosFilter extends JCasAnnotator_ImplBase {

	public static final Logger logger = UIMAFramework.getLogger(PosFilter.class);

	public static final String PARAM_ADJ  = "Adjectives";
    public static final String PARAM_ADV  = "Adverbs";
    public static final String PARAM_ART  = "Articles";
    public static final String PARAM_CARD = "Cardinals";
    public static final String PARAM_CONJ = "Conjunctions";
    public static final String PARAM_N    = "Nouns";
    public static final String PARAM_O    = "Others";
    public static final String PARAM_PP   = "Prepositions";
    public static final String PARAM_PR   = "Pronouns";
    public static final String PARAM_PUNC = "Punctuation";
    public static final String PARAM_V    = "Verbs";

    private boolean adj    = false;
	private boolean adv    = false;
	private boolean art    = false;
	private boolean card   = false;
	private boolean conj   = false;
	private boolean n      = false;
	private boolean o      = false;
	private boolean pp     = false;
	private boolean pr     = false;
	private boolean punc   = false;
	private boolean v      = false;

	private JCas jcas;

	/**
	 * Returns the POS annotation of a token.
	 * 
	 * @param token A Token.
	 * @return The Pos annotation.
	 */
	private Annotation getPos(Token token) {
		FSIterator posIterator = jcas.getAnnotationIndex(POS.type).subiterator(token);
		if (posIterator.hasNext()) {
            return (Annotation) posIterator.next();
        }
		logger.log(Level.WARNING, "Could not find matching POS annotation for token: " + token.getCoveredText());
		return null;
	}

	@Override
	public void initialize(UimaContext context) throws ResourceInitializationException {
		super.initialize(context);

		logger.setLevel(Level.FINE);
		logger.log(Level.CONFIG, "Initializing " + this.getClass().getSimpleName());

		adj  = (Boolean) getContext().getConfigParameterValue(PARAM_ADJ);
		adv  = (Boolean) getContext().getConfigParameterValue(PARAM_ADV);
		art  = (Boolean) getContext().getConfigParameterValue(PARAM_ART);
		card = (Boolean) getContext().getConfigParameterValue(PARAM_CARD);
		conj = (Boolean) getContext().getConfigParameterValue(PARAM_CONJ);
		n    = (Boolean) getContext().getConfigParameterValue(PARAM_N);
		o    = (Boolean) getContext().getConfigParameterValue(PARAM_O);
		pp   = (Boolean) getContext().getConfigParameterValue(PARAM_PP);
		pr   = (Boolean) getContext().getConfigParameterValue(PARAM_PR);
		punc = (Boolean) getContext().getConfigParameterValue(PARAM_PUNC);
		v    = (Boolean) getContext().getConfigParameterValue(PARAM_V);

    }

	@Override
	public void process(JCas jcas) throws AnalysisEngineProcessException {
		this.jcas = jcas;

		logger.log(Level.CONFIG, "Entering " + this.getClass().getSimpleName());

		FSIterator tokenIterator = jcas.getAnnotationIndex(Token.type).iterator();
		List<Token> tokens = new ArrayList<Token>();
		while (tokenIterator.hasNext()) {
			Token token = (Token) tokenIterator.next();
			Annotation pos = getPos(token);
            if (pos == null) {
                continue;
            }
            
            String posString = pos.getType().getShortName();
            if (posString.equals("ADJ") && adj) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("ADV") && adv) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("ART") && art) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("CARD") && card) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("CONJ") && conj) {
                tokens.add(token);
                continue;
            }
            if ((posString.equals("N") || posString.equals("NN") || posString.equals("NP")) && n) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("O") && o) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("PP") && pp) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("PR") && pr) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("PUNC") && punc) {
                tokens.add(token);
                continue;
            }
            if (posString.equals("V") && v) {
                tokens.add(token);
                continue;
            }
		}
		for (Token i : tokens) {
			FilteredToken filtered = new FilteredToken(jcas);
			filtered.setBegin(i.getBegin());
			filtered.setEnd(i.getEnd());
			filtered.addToIndexes();

            // Remove the original token from indexes.
            // As FilteredToken is a subtype of Token, an iterator over Token will still give you the same annotations
            i.removeFromIndexes();
		}
	}
}
