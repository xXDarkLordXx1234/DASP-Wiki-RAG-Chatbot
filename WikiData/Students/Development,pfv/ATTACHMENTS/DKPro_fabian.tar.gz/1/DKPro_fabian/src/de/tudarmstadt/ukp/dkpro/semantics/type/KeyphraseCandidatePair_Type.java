
/* First created by JCasGen Wed Jan 28 13:01:14 CET 2009 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.Feature;
import org.apache.uima.jcas.tcas.Annotation_Type;

/** 
 * Updated by JCasGen Wed Jan 28 13:01:14 CET 2009
 * @generated */
public class KeyphraseCandidatePair_Type extends Annotation_Type {
  /** @generated */
  protected FSGenerator getFSGenerator() {return fsGenerator;}
  /** @generated */
  private final FSGenerator fsGenerator = 
    new FSGenerator() {
      public FeatureStructure createFS(int addr, CASImpl cas) {
  			 if (KeyphraseCandidatePair_Type.this.useExistingInstance) {
  			   // Return eq fs instance if already created
  		     FeatureStructure fs = KeyphraseCandidatePair_Type.this.jcas.getJfsFromCaddr(addr);
  		     if (null == fs) {
  		       fs = new KeyphraseCandidatePair(addr, KeyphraseCandidatePair_Type.this);
  			   KeyphraseCandidatePair_Type.this.jcas.putJfsFromCaddr(addr, fs);
  			   return fs;
  		     }
  		     return fs;
        } else return new KeyphraseCandidatePair(addr, KeyphraseCandidatePair_Type.this);
  	  }
    };
  /** @generated */
  public final static int typeIndexID = KeyphraseCandidatePair.typeIndexID;
  /** @generated 
     @modifiable */
  public final static boolean featOkTst = JCasRegistry.getFeatOkTst("de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
 
  /** @generated */
  final Feature casFeat_Candidate1;
  /** @generated */
  final int     casFeatCode_Candidate1;
  /** @generated */ 
  public int getCandidate1(int addr) {
        if (featOkTst && casFeat_Candidate1 == null)
      jcas.throwFeatMissing("Candidate1", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    return ll_cas.ll_getRefValue(addr, casFeatCode_Candidate1);
  }
  /** @generated */    
  public void setCandidate1(int addr, int v) {
        if (featOkTst && casFeat_Candidate1 == null)
      jcas.throwFeatMissing("Candidate1", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    ll_cas.ll_setRefValue(addr, casFeatCode_Candidate1, v);}
    
  
 
  /** @generated */
  final Feature casFeat_Candidate2;
  /** @generated */
  final int     casFeatCode_Candidate2;
  /** @generated */ 
  public int getCandidate2(int addr) {
        if (featOkTst && casFeat_Candidate2 == null)
      jcas.throwFeatMissing("Candidate2", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    return ll_cas.ll_getRefValue(addr, casFeatCode_Candidate2);
  }
  /** @generated */    
  public void setCandidate2(int addr, int v) {
        if (featOkTst && casFeat_Candidate2 == null)
      jcas.throwFeatMissing("Candidate2", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    ll_cas.ll_setRefValue(addr, casFeatCode_Candidate2, v);}
    
  



  /** initialize variables to correspond with Cas Type and Features
	* @generated */
  public KeyphraseCandidatePair_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl)this.casType, getFSGenerator());

 
    casFeat_Candidate1 = jcas.getRequiredFeatureDE(casType, "Candidate1", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidate", featOkTst);
    casFeatCode_Candidate1  = (null == casFeat_Candidate1) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_Candidate1).getCode();

 
    casFeat_Candidate2 = jcas.getRequiredFeatureDE(casType, "Candidate2", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidate", featOkTst);
    casFeatCode_Candidate2  = (null == casFeat_Candidate2) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_Candidate2).getCode();

  }
}



    