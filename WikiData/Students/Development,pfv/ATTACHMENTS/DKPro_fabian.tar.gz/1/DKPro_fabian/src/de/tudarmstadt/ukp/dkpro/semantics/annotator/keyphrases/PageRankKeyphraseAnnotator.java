package de.tudarmstadt.ukp.dkpro.semantics.annotator.keyphrases;

import java.util.List;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.semantics.type.AnnotationPair;
import de.tudarmstadt.ukp.dkpro.semantics.type.Keyphrase;
import de.tudarmstadt.ukp.dkpro.semantics.type.SemanticRelatedness;
import de.tudarmstadt.ukp.dkpro.semantics.util.pagerank.PageRank;
import de.tudarmstadt.ukp.dkpro.semantics.util.pagerank.PageRank.Term;
import de.tudarmstadt.ukp.dkpro.semantics.util.pagerank.PageRank.TermRank;

public class PageRankKeyphraseAnnotator extends JCasAnnotator_ImplBase {

    public static final Logger logger = UIMAFramework.getLogger(PageRankKeyphraseAnnotator.class);

    public static final String PARAM_WEIGHTED = "Weighted";

    private boolean weighted;
    private PageRank pageRank;
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
        super.initialize(context);

        weighted = (Boolean) context.getConfigParameterValue(PARAM_WEIGHTED);
        
        pageRank = new PageRank();
    
    }

    @Override
    public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.CONFIG, "Entering " + this.getClass().getSimpleName());

        FSIterator apIterator = ((AnnotationIndex) jcas.getAnnotationIndex(AnnotationPair.type)).iterator();
        FSIterator srIterator = ((AnnotationIndex) jcas.getAnnotationIndex(SemanticRelatedness.type)).iterator();

        pageRank.initializeFromAnnotationPairIterator(apIterator, srIterator, weighted);
        
        pageRank.run();

        List<TermRank> termRanks = pageRank.getTermRanks();
        logger.log(Level.FINE, termRanks.toString());
        for (TermRank termRank : termRanks) {
            addKeyphrase(jcas, termRank);
        }
    }

    private void addKeyphrase(JCas jcas, TermRank termRank) {
        String termStringRepresentation = termRank.getStringRepresentation();
        double score = termRank.getScore();

        for (Term term : termRank.getTermList()) {
            int[] offset = term.getOffset();
            
            Keyphrase keyphrase = new Keyphrase(jcas);
            keyphrase.setKeyphrase(termStringRepresentation);
            keyphrase.setScore(score);
            keyphrase.setBegin(offset[0]);
            keyphrase.setEnd(offset[1]);
            keyphrase.addToIndexes();
        }
    }
}