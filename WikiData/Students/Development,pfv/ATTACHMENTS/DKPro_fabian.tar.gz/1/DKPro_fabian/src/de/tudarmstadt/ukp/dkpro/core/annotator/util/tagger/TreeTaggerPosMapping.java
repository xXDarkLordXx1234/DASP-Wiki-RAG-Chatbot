package de.tudarmstadt.ukp.dkpro.core.annotator.util.tagger;

import java.util.HashMap;
import java.util.Map;

public class TreeTaggerPosMapping {

    private final static Map<String, String> germanTagMap = new HashMap<String, String>() {
        private static final long serialVersionUID = 1L;
        {
            put("ADJA"   , "ADJ" );
            put("ADJD"   , "ADJ" );
            put("ADV"    , "ADV" );
            put("APPR"   , "PP"  );
            put("APPRART", "PP"  );
            put("APPO"   , "PP"  );
            put("APZR"   , "PP"  );
            put("ART"    , "ART" );
            put("CARD"   , "CARD");
            put("FM"     , "O"   );
            put("ITJ"    , "O"   );
            put("KOUI"   , "CONJ");
            put("KOUS"   , "CONJ");
            put("KON"    , "CONJ");
            put("KOKOM"  , "CONJ");
            put("NN"     , "NN"  );
            put("NE"     , "NP"  );
            put("PDS"    , "PR"  );
            put("PDAT"   , "PR"  );
            put("PIS"    , "PR"  );
            put("PIAT"   , "PR"  );
            put("PIDAT"  , "PR"  );
            put("PPER"   , "PR"  );
            put("PPOSS"  , "PR"  );
            put("PPOSAT" , "PR"  );
            put("PRELS"  , "PR"  );
            put("PRELAT" , "PR"  );
            put("PRF"    , "PR"  );
            put("PWS"    , "PR"  );
            put("PWAT"   , "PR"  );
            put("PWAV"   , "PR"  );
            put("PAV"    , "PR"  ); // TODO Pronominaladverb "dafuer", "dabei", "deswegen" - PR oder ADV??
            put("PTKZU"  , "O"   ); 
            put("PTKNEG" , "O"   );
            put("PTKVZ"  , "V"   ); // verb particle treated as verb 
            put("PTKANT" , "O"   );
            put("PTKA"   , "O"   ); 
            put("TRUNC"  , "O"   ); 
            put("VVFIN"  , "V"   );
            put("VVIMP"  , "V"   );
            put("VVINF"  , "V"   );
            put("VVIZU"  , "V"   );
            put("VVPP"   , "V"   );
            put("VAFIN"  , "V"   );
            put("VAIMP"  , "V"   );
            put("VAINF"  , "V"   );
            put("VAPP"   , "V"   );
            put("VMFIN"  , "V"   );
            put("VMINF"  , "V"   );
            put("VMPP"   , "V"   );
            put("XY"     , "O"   );
            put("$,"     , "PUNC");
            put("$."     , "PUNC");
            put("$("     , "PUNC");
        }
    };

    private final static Map<String, String> englishTagMap = new HashMap<String, String>() {

		private static final long serialVersionUID = 1L;

		{
           
            put("CC"   , "CONJ");
            put("CD"   , "CARD");
            put("DT"   , "ART" );
            put("EX"   , "ART" );  // ??? check it
            put("IN"   , "PP"  );
            put("JJ"   , "ADJ" );
            put("JJR"  , "ADJ" );
            put("JJS"  , "ADJ" );
            put("MD"   , "V"   );
            put("NN"   , "NN"  );
            put("NNS"  , "NN"  );
            put("NP"   , "NP"  );
            put("NPS"  , "NP"  );
            put("PDT"  , "ART"  );
            // put("POS"     , "???"  ); possesive ending ("'s")
            put("PP"   , "PR"  );
            put("PP$"  , "PR"  );
            put("RB"   , "ADV"  );
            put("RBR"  , "ADV"  );
            put("RBS"  , "ADV"  );
            put("RP"   , "PP"   );
            // put("TO"   , ""     );
            put("SENT" , "PUNC" );
            put("UH"   , "O"    );
            put("VB"   , "V"    );
            put("VBD"  , "V"    );
            put("VBG"  , "V"    );
            put("VBN"  , "V"    );
            put("VBP"  , "V"    );
            put("VBZ"  , "V"    );
            put("VH"   , "V"    );
            put("VHD"  , "V"    );
            put("VHG"  , "V"    );
            put("VHP"  , "V"    );
            put("VHN"  , "V"    );
            put("VHZ"  , "V"    );
            put("VV"   , "V"    );
            put("VVD"  , "V"    );
            put("VVG"  , "V"    );
            put("VVN"  , "V"    );
            put("VVP"  , "V"    );
            put("VVZ"  , "V"    );
            put("WDT"  , "ART"  );
            put("WP"   , "PR"   );
            put("WP$"  , "PR"   );
            put("WRB"  , "ADV"  ); 
            
        }
    };
    
    private final static Map<String, String> frenchTagMap = new HashMap<String, String>() {

		private static final long serialVersionUID = 1L;

		{
			
            //put("SYM", " ");
            //put("ABR"   , "???");
            put("NUM"   , "CARD");
            put("ADJ"   , "ADJ" );
            put("ADV"   , "ADV"  );
            put("DET:ART"   , "ART" );
            put("INT"   , "O"    );
            put("NOM"   , "NN"  );
            put("NAM"   , "NP"  );
            put("KON"   , "CONJ");
            put("PRP"   , "PP"  );
            put("PRP:det"   , "PP"  );
            
            put("DET:POS"   , "PR"  );
            
            put("PRO"   , "PR"  );
            put("PRO:DEM"  , "PR"  );
            put("PRO:IND"  , "PR"  );
            put("PRO:PER"   , "PR"  );
            put("PRO:POS"  , "PR"  );
            put("PRO:REL"  , "PR"  );
   			put("PUN" , "PUNC" );
            put("PUN:cit" , "PUNC" );
            put("SENT" , "PUNC" );	
            put("VER:cond"   , "V"    );
            put("VER:futu"  , "V"    );
            put("VER:impe"  , "V"    );
            put("VER:impf"  , "V"    );
            put("VER:infi"  , "V"    );
            put("VER:pper"  , "V"    );
            put("VER:ppre"   , "V"    );
            put("VER:pres"  , "V"    );
            put("VER:simp"  , "V"    );
            put("VER:subi"  , "V"    );
            put("VER:subp"  , "V"    );
 
        }
    };
    
    
    public static Map<String, String> getRussianTagMap() {
        return TreeTaggerPosMappingRussianSmall.TAG_MAP;
    }
    
    public static Map<String, String> getGermanTagMap() {
        return germanTagMap;
    }
    
    public static Map<String, String> getEnglishTagMap(){
    	return englishTagMap;
    }

    public static Map<String, String> getFrenchTagMap(){
    	return frenchTagMap;
    }

////STTS Stuttgart-Tuebingen-TagSet    
//  ADJA    attributives Adjektiv   [das] große [Haus]
//  ADJD    adverbiales oder prädikatives Adjektiv  [er fährt] schnell, [er ist] schnell
//                                                                    
//  ADV     Adverb  schon, bald, doch
//                                                                    
//  APPR    Präposition; Zirkumposition links   in [der Stadt], ohne [mich]
//  APPRART     Präposition mit Artikel     im [Haus], zur [Sache]
//  APPO    Postposition    [ihm] zufolge, [der Sache] wegen
//  APZR    Zirkumposition rechts   [von jetzt] an
//                                                                    
//  ART     bestimmter oder unbestimmter Artikel    der, die, das, ein, eine
//                                                                    
//  CARD    Kardinalzahl    zwei [Männer], [im Jahre] 1994
//                                                                    
//  FM  Fremdsprachliches Material  [Er hat das mit ``] A big fish ['' übersetzt]
//                                                                    
//  ITJ     Interjektion    mhm, ach, tja
//                                                                    
//  KOUI    unterordnende Konjunktion mit ``zu'' und Infinitiv  um [zu leben], anstatt [zu fragen]
//  KOUS    unterordnende Konjunktion mit Satz  weil, daß, damit, wenn, ob
//  KON     nebenordnende Konjunktion   und, oder, aber
//  KOKOM   Vergleichskonjunktion   als, wie
//                                                                    
//  NN  normales Nomen  Tisch, Herr, [das] Reisen
//  NE  Eigennamen  Hans, Hamburg, HSV
//                                                                    
//  PDS     substituierendes Demonstrativpronomen   dieser, jener
//  PDAT    attribuierendes Demonstrativpronomen    jener [Mensch]
//                                                                    
//  PIS     substituierendes Indefinitpronomen  keiner, viele, man, niemand
//  PIAT    attribuierendes Indefinitpronomen ohne Determiner   kein [Mensch], irgendein [Glas]
//  PIDAT   attribuierendes Indefinitpronomen mit Determiner    [ein] wenig [Wasser], [die] beiden [Brüder]
//                                                                    
//  PPER    irreflexives Personalpronomen   ich, er, ihm, mich, dir
//                                                                    
//  PPOSS   substituierendes Possessivpronomen  meins, deiner
//  PPOSAT  attribuierendes Possessivpronomen   mein [Buch], deine [Mutter]
//                                                                    
//  PRELS   substituierendes Relativpronomen    [der Hund ,] der
//  PRELAT  attribuierendes Relativpronomen     [der Mann ,] dessen [Hund]
//                                                                    
//  PRF     reflexives Personalpronomen     sich, einander, dich, mir
//                                                                    
//  PWS     substituierendes Interrogativpronomen   wer, was
//  PWAT    attribuierendes Interrogativpronomen    welche [Farbe], wessen [Hut]
//  PWAV    adverbiales Interrogativ- oder Relativpronomen  warum, wo, wann, worüber, wobei
//                                                                    
//  PAV     Pronominaladverb    dafür, dabei, deswegen, trotzdem
//                                                                    
//  PTKZU   ``zu'' vor Infinitiv    zu [gehen]
//  PTKNEG  Negationspartikel   nicht
//  PTKVZ   abgetrennter Verbzusatz     [er kommt] an, [er fährt] rad
//  PTKANT  Antwortpartikel     ja, nein, danke, bitte
//  PTKA    Partikel bei Adjektiv oder Adverb   am [schönsten], zu [schnell]
//                                                                    
//  TRUNC   Kompositions-Erstglied  An- [und Abreise]
//                                                                    
//  VVFIN   finites Verb, voll  [du] gehst, [wir] kommen [an]
//  VVIMP   Imperativ, voll     komm [!]
//  VVINF   Infinitiv, voll     gehen, ankommen
//  VVIZU   Infinitiv mit ``zu'', voll  anzukommen, loszulassen
//  VVPP    Partizip Perfekt, voll  gegangen, angekommen
//  VAFIN   finites Verb, aux   [du] bist, [wir] werden
//  VAIMP   Imperativ, aux  sei [ruhig !]
//  VAINF   Infinitiv, aux  werden, sein
//  VAPP    Partizip Perfekt, aux   gewesen
//  VMFIN   finites Verb, modal     dürfen
//  VMINF   Infinitiv, modal    wollen
//  VMPP    Partizip Perfekt, modal     gekonnt, [er hat gehen] können
//                                                                    
//  XY  Nichtwort, Sonderzeichen enthaltend     3:7, H2O, D2XW3
//                                                                    
//  \$,     Komma   ,
//  \$.     Satzbeendende Interpunktion     . ? ! ; :
//  \$(     sonstige Satzzeichen; satzintern    - [,]()            

    private final static Map<String, String> sttsTagMap = new HashMap<String, String>() {
        private static final long serialVersionUID = 1L;
        {
            put("ADJA"   , "ADJ" );
            put("ADJD"   , "ADJ" );
            put("ADV"    , "ADV" );
            put("APPR"   , "PP"  );
            put("APPRART", "PP"  );
            put("APPO"   , "PP"  );
            put("APZR"   , "PP"  );
            put("ART"    , "ART" );
            put("CARD"   , "CARD");
            put("FM"     , "O"   );
            put("ITJ"    , "O"   );
            put("KOUI"   , "CONJ");
            put("KOUS"   , "CONJ");
            put("KON"    , "CONJ");
            put("KOKOM"  , "CONJ");
            put("NN"     , "NN"  );
            put("NE"     , "NP"  );
            put("PAV"    , "ADV" );
            put("PDS"    , "PR"  );
            put("PDAT"   , "PR"  );
            put("PIS"    , "PR"  );
            put("PIAT"   , "PR"  );
            put("PIDAT"  , "PR"  );
            put("PPER"   , "PR"  );
            put("PPOSS"  , "PR"  );
            put("PPOSAT" , "PR"  );
            put("PRELS"  , "PR"  );
            put("PRELAT" , "PR"  );
            put("PRF"    , "PR"  );
            put("PWS"    , "PR"  );
            put("PWAT"   , "PR"  );
            put("PWAV"   , "PR"  );
            put("PTKZU"  , "PR"  ); 
            put("PTKVZ"  , "V"   ); 
            put("PTKA"   , "ADV" ); 
            put("VVFIN"  , "V"   ); 
            put("VVIMP"  , "V"   ); 
            put("VVINF"  , "V"   ); 
            put("VVIZU"  , "V"   ); 
            put("VVPP"   , "V"   ); 
            put("VAFIN"  , "V"   ); 
            put("VAIMP"  , "V"   ); 
            put("VAINF"  , "V"   ); 
            put("VAPP"   , "V"   ); 
            put("VMFIN"  , "V"   ); 
            put("VMINF"  , "V"   ); 
            put("VMPP"   , "V"   ); 
            put("XY"     , "O"   ); 
            put("\\$."   , "PUNC");
            put("\\$,"   , "PUNC");
            put("\\$("   , "PUNC");
        }
    };

    
    public static Map<String, String> getSTTSTagMap() {
        return sttsTagMap;
    }
}