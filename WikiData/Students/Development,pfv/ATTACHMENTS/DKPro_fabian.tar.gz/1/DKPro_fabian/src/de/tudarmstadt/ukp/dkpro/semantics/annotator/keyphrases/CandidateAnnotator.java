package de.tudarmstadt.ukp.dkpro.semantics.annotator.keyphrases;

import java.util.ArrayList;
import java.util.List;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.util.UimaReflectionUtils;
import de.tudarmstadt.ukp.dkpro.semantics.type.FilteredToken;
import de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidate;

/**
 * This annotator takes a fully qualified type name and a method name that returns a string representation of the type as parameters.
 *
 * In case of overlapping annotations and a resolveOverlaps parameter set to true:
 * a)
 * xxxx yyyy zzzz
 *      yyyy
 * We only add the larger one (xxxx yyyy zzzz) as a candidate .
 *
 * b)
 * xxxx yyyy
 *      yyyy zzzz
 * We add a merged candiate (xxxx yyyy zzzz).
 *  
 * @author zesch
 */
public class CandidateAnnotator extends JCasAnnotator_ImplBase {

    public static final Logger logger = UIMAFramework.getLogger(CandidateAnnotator.class);

    public static final String PARAM_ANNOTATION_TYPE = "AnnotationType";
    private String annotationType;
    
    public static final String PARAM_STRING_METHOD = "StringRepresentationMethod";
    private String stringRepresentationMethod;

    public static final String PARAM_USE_POS_FILTER = "UsePosFilter";
    private boolean usePosFilter = false;
    
    public static final String PARAM_RESOLVE        = "resolveOverlaps";
    private boolean resolveOverlaps; // setting this true might not make too much sense with NGrams :)
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
        super.initialize(context);
        
        annotationType             = (String) context.getConfigParameterValue(PARAM_ANNOTATION_TYPE);
        stringRepresentationMethod = (String) context.getConfigParameterValue(PARAM_STRING_METHOD);
        usePosFilter               = (Boolean) context.getConfigParameterValue(PARAM_USE_POS_FILTER);
        resolveOverlaps            = (Boolean) context.getConfigParameterValue(PARAM_RESOLVE);
    }

    @Override
    public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.FINE, "Entering " + this.getClass().getSimpleName());
        
        // get the candidates according to the parameters
        List<Candidate> candidates = new ArrayList<Candidate>();
        
        // get the type using reflection
        int type = (Integer) UimaReflectionUtils.getReturnValueByReflection(jcas, annotationType, "getTypeIndexID");

        AnnotationIndex  annotationIndex = jcas.getAnnotationIndex(type);
        FSIterator annotationIter = annotationIndex.iterator();

        while (annotationIter.hasNext()) {
            Annotation annotation = (Annotation) annotationIter.next();
            String term = (String) UimaReflectionUtils.getReturnValueByReflection(jcas, annotation, annotationType, stringRepresentationMethod);
            candidates.add(new Candidate(term, annotation.getBegin(), annotation.getEnd()));
        }
        
        List<Candidate> resolvedCandidates;
        if (resolveOverlaps) {
            resolvedCandidates = resolveOverlappingCandidates(candidates);
        }
        else {
            resolvedCandidates = candidates;
        }
        
        
        FSIterator filteredTokenIterator = null;
        if (usePosFilter) {
            filteredTokenIterator = ((AnnotationIndex) jcas.getAnnotationIndex(FilteredToken.type)).iterator();
        }
        
        AnnotationIndex candidateIndex = jcas.getAnnotationIndex(KeyphraseCandidate.type);
        for (Candidate candidate : resolvedCandidates) {
            if (usePosFilter && !matchesFilteredToken(candidate, filteredTokenIterator)) {
                continue;
            }
            KeyphraseCandidate kc = new KeyphraseCandidate(jcas);
            kc.setKeyphrase(candidate.term);
            kc.setBegin(candidate.begin);
            kc.setEnd(candidate.end);

            // do not allow duplicates
            if (!candidateIndex.contains(kc)) {
                kc.addToIndexes(jcas);
            }
        }
    }


    // TODO does currently only work for single term annotations like Token or Lemma
    /**
     * @param candidate A keyphrase candidate.
     * @return Returns true, if the given annotation is included in the FilteredTokens. False otherwise.
     */
    private boolean matchesFilteredToken(Candidate candidate, FSIterator filteredTokenIterator) {
        while (filteredTokenIterator.hasNext()) {
            FilteredToken ft = (FilteredToken) filteredTokenIterator.next();
            
            if (ft.getBegin() <= candidate.begin && ft.getEnd() >= candidate.end) {
                filteredTokenIterator.moveToFirst();
                return true;
            }
        }
        
        filteredTokenIterator.moveToFirst();
        return false;
    }
    private List<Candidate> resolveOverlappingCandidates(List<Candidate> candidates) {
        List<Candidate> resolvedCandidates = new ArrayList<Candidate>();
        
        boolean finished = false;
        while (!finished && candidates.size() > 0) {
            if (candidates.size() == 1) {
                resolvedCandidates.add(candidates.get(0));
                finished = true;
                continue;
            }
            
            Candidate firstCandidate = candidates.get(0);
            
            Overlap overlap = getOverlappingCandidate(firstCandidate, candidates.subList(1, candidates.size()));

            if (overlap == null) {
                // if there is no overlap, add the firstCandidate to the list of resolved cases
                resolvedCandidates.add(firstCandidate);
                // shorten candidate list
                candidates = candidates.subList(1, candidates.size());
            }
            else {
                // resolve
                Candidate resolvedCandidate = resolve(firstCandidate, overlap.candidate);

                if (resolvedCandidate != null) {
                    // Add the resolved candidate at the position of the overlap and shorten list.
                    candidates.set(overlap.offset, resolvedCandidate); 
                    candidates = candidates.subList(1, candidates.size());
                }
                else {
                    // just shorten the list => remove the candidate that caused the error
                    candidates = candidates.subList(1, candidates.size());
                }
            }
        }
        
        return resolvedCandidates;
    }
    
    /**
     * @param candidate
     * @param candidateList
     * @return Returns an Overlap object containing the first candidate from candidateList overlapping with candidate. Or null, if no overlap was found.
     */
    private Overlap getOverlappingCandidate(Candidate candidate, List<Candidate> candidateList) {
        int i = 1;
        for (Candidate c : candidateList) {
            if (overlaps(c, candidate)) {
                return new Overlap(c,i); 
            }
            i++;
        }
        return null;
    }
    
    /**
     * @param c1
     * @param c2
     * @return True, if c1 and c2 overlap.
     */
    private boolean overlaps(Candidate c1, Candidate c2) {
        if ((c1.begin == c2.begin || c1.end == c2.end) ||
            (c1.begin < c2.begin && c1.end > c2.end) ||
            (c1.begin > c2.begin && c1.end < c2.end) ||
            (c1.begin < c2.begin && c1.end > c2.begin) || 
            (c2.begin < c1.begin && c2.end > c1.begin)) {
            
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * Resolve cases:
     * a)
     * Equal candidates. Return one.
     * 
     * b)
     * xxxx yyyy zzzz
     *      yyyy
     * We only add the larger one (xxxx yyyy zzzz) as a candidate.
     * 
     * c)
     * xxxx yyyy
     *      yyyy zzzz
     * We add a merged candiate (xxxx yyyy zzzz).
     * 
     * 
     * @param firstCandidate
     * @param secondCandidate
     * @return The resolved candidate or null.
     */
    private Candidate resolve(Candidate c1, Candidate c2) {
        // case a
        if (c1.begin == c2.begin && c1.end == c2.end) {
            logger.log(Level.FINEST, "Resolve case a");
            return c1;
        }
        // case b(1)
        else if (c1.begin <= c2.begin && c1.end >= c2.end) {
            logger.log(Level.FINEST, "Resolve case b1");
            return c1;
        }
        // case b(2)
        else if (c1.begin >= c2.begin && c1.end <= c2.end) {
            logger.log(Level.FINEST, "Resolve case b2");
            return c2;
        }
        // case c(1)
        else if (c1.begin < c2.begin && c1.end > c2.begin) {
            logger.log(Level.FINEST, "Resolve case c1");
            int mismatch = c2.begin - c1.begin;
            if (mismatch < c2.term.length()) {
                String term = c1.term.substring(0,mismatch) + c2.term;
                return new Candidate(term, c1.begin, c2.end);
            }
            else {
                return null;
            }
        }
        // case c(2)
        else if (c2.begin < c1.begin && c2.end > c1.begin) {
            logger.log(Level.FINEST, "Resolve case c2");
            int mismatch = c1.begin - c2.begin;
            if (mismatch < c1.term.length()) {
                String term = c2.term.substring(0,mismatch) + c1.term;
                return new Candidate(term, c2.begin, c1.end);
            }
            else {
                return null;
            }
        }
        else {
            logger.log(Level.WARNING, "Reached unexpected case when resolving overlaps.");
            logger.log(Level.WARNING, c1.toString());
            logger.log(Level.WARNING, c2.toString());
            return null;
        }
    }
    
    private class Candidate {
        private String term;
        private int begin;
        private int end;
        public Candidate(String term, int begin, int end) {
            super();
            this.term = term;
            this.begin = begin;
            this.end = end;
        }
        public String toString() {
            return term + " (" + begin + " - " + end + ")";
        }
    
    }
    
    private class Overlap {
        private Candidate candidate;
        private int offset;
        public Overlap(Candidate candidate, int offset) {
            super();
            this.candidate = candidate;
            this.offset = offset;
        }
        public String toString() {
            return candidate.toString() + " #:" + offset;
        }
    }
}