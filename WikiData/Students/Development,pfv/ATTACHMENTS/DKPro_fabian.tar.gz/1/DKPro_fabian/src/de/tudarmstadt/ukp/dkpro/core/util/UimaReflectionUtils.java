package de.tudarmstadt.ukp.dkpro.core.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.uima.UIMAFramework;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

public class UimaReflectionUtils {

    private static final Logger logger = UIMAFramework.getLogger(UimaReflectionUtils.class);

    /**
     * @param jcas The JCas.
     * @param className The name of the annotation class.
     * @param methodName The name of the method to call.
     * @return An object representing the return value. It is in the responsiblity of the caller to cast this object to the correct type.
     * @throws AnalysisEngineProcessException
     */
    public static Object getReturnValueByReflection(JCas jcas, String className, String methodName) throws AnalysisEngineProcessException {

        try {
            Class annotationTypeClass = Class.forName(className);

            Class[] emptyParameterTypes = new Class[]{};
            
            Method method = annotationTypeClass.getMethod(methodName, emptyParameterTypes);
            
            Class[] constructorTypes = new Class[]{JCas.class};
            Constructor constructor = annotationTypeClass.getConstructor(constructorTypes);
          
            Object[] constructorArguments = new Object[]{jcas};
            Object annotationTypeInstance = constructor.newInstance(constructorArguments);

            Object[] emptyArguments = new Object[]{};
            
            Object returnValue = method.invoke(annotationTypeInstance, emptyArguments);
            return returnValue;
            
        } catch (ClassNotFoundException e) {
            logger.log(Level.SEVERE, "No such class " + className, new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (NoSuchMethodException e) {
            logger.log(Level.SEVERE, "No such method", new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (IllegalArgumentException e) {
            logger.log(Level.SEVERE, "You can call this method, but not with THIS arguments.", new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (IllegalAccessException e) {
            logger.log(Level.SEVERE, "You're not allowed to call this method.", new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (InvocationTargetException e) {
            logger.log(Level.SEVERE, "Invoked method has thrown an exception.", new Throwable(e.getCause()));
            throw new AnalysisEngineProcessException(e);
        } catch (InstantiationException e) {
            logger.log(Level.SEVERE, "Instantiation exception", new Throwable());
            throw new AnalysisEngineProcessException(e);
        }
    }

    /**
     * @param jcas The JCas.
     * @param object An already instantiated object of the given type.
     * @param className The name of the annotation class.
     * @param methodName The name of the method to call.
     * @return An object representing the return value. It is in the responsiblity of the caller to cast this object to the correct type.
     * @throws AnalysisEngineProcessException
     */
    public static Object getReturnValueByReflection(JCas jcas, Object object, String className, String methodName) throws AnalysisEngineProcessException {

        try {
            Class annotationTypeClass = Class.forName(className);

            Class[] emptyParameterTypes = new Class[]{};
            
            Method method = annotationTypeClass.getMethod(methodName, emptyParameterTypes);
            
            Object[] emptyArguments = new Object[]{};
            
            Object castObject = annotationTypeClass.cast(object);
            
            Object returnValue = method.invoke(castObject, emptyArguments);
            return returnValue;
            
        } catch (ClassNotFoundException e) {
            logger.log(Level.SEVERE, "No such class " + className, new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (NoSuchMethodException e) {
            logger.log(Level.SEVERE, "No such method", new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (IllegalArgumentException e) {
            logger.log(Level.SEVERE, "You can call this method, but not with THIS arguments.", new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (IllegalAccessException e) {
            logger.log(Level.SEVERE, "You're not allowed to call this method.", new Throwable());
            throw new AnalysisEngineProcessException(e);
        } catch (InvocationTargetException e) {
            logger.log(Level.SEVERE, "Invoked method has thrown an exception.", new Throwable(e.getCause()));
            throw new AnalysisEngineProcessException(e);
        }
    }
    
}
