
/* First created by JCasGen Tue Oct 23 00:18:31 CEST 2007 */
package de.tudarmstadt.ukp.dkpro.core.type;

import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.cas.impl.CASImpl;
import org.apache.uima.cas.impl.FSGenerator;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.impl.TypeImpl;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.impl.FeatureImpl;
import org.apache.uima.cas.Feature;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.tcas.DocumentAnnotation_Type;

/** 
 * Updated by JCasGen Tue Nov 06 18:25:36 CET 2007
 * @generated */
public class DocumentMetaData_Type extends DocumentAnnotation_Type {
  /** @generated */
  protected FSGenerator getFSGenerator() {return fsGenerator;}
  /** @generated */
  private final FSGenerator fsGenerator = 
    new FSGenerator() {
      public FeatureStructure createFS(int addr, CASImpl cas) {
  			 if (DocumentMetaData_Type.this.useExistingInstance) {
  			   // Return eq fs instance if already created
  		     FeatureStructure fs = DocumentMetaData_Type.this.jcas.getJfsFromCaddr(addr);
  		     if (null == fs) {
  		       fs = new DocumentMetaData(addr, DocumentMetaData_Type.this);
  			   DocumentMetaData_Type.this.jcas.putJfsFromCaddr(addr, fs);
  			   return fs;
  		     }
  		     return fs;
        } else return new DocumentMetaData(addr, DocumentMetaData_Type.this);
  	  }
    };
  /** @generated */
  public final static int typeIndexID = DocumentMetaData.typeIndexID;
  /** @generated 
     @modifiable */
  public final static boolean featOkTst = JCasRegistry.getFeatOkTst("de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
 
  /** @generated */
  final Feature casFeat_documentTitle;
  /** @generated */
  final int     casFeatCode_documentTitle;
  /** @generated */ 
  public String getDocumentTitle(int addr) {
        if (featOkTst && casFeat_documentTitle == null)
      jcas.throwFeatMissing("documentTitle", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    return ll_cas.ll_getStringValue(addr, casFeatCode_documentTitle);
  }
  /** @generated */    
  public void setDocumentTitle(int addr, String v) {
        if (featOkTst && casFeat_documentTitle == null)
      jcas.throwFeatMissing("documentTitle", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    ll_cas.ll_setStringValue(addr, casFeatCode_documentTitle, v);}
    
  
 
  /** @generated */
  final Feature casFeat_documentId;
  /** @generated */
  final int     casFeatCode_documentId;
  /** @generated */ 
  public String getDocumentId(int addr) {
        if (featOkTst && casFeat_documentId == null)
      jcas.throwFeatMissing("documentId", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    return ll_cas.ll_getStringValue(addr, casFeatCode_documentId);
  }
  /** @generated */    
  public void setDocumentId(int addr, String v) {
        if (featOkTst && casFeat_documentId == null)
      jcas.throwFeatMissing("documentId", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    ll_cas.ll_setStringValue(addr, casFeatCode_documentId, v);}
    
  
 
  /** @generated */
  final Feature casFeat_documentUri;
  /** @generated */
  final int     casFeatCode_documentUri;
  /** @generated */ 
  public String getDocumentUri(int addr) {
        if (featOkTst && casFeat_documentUri == null)
      jcas.throwFeatMissing("documentUri", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    return ll_cas.ll_getStringValue(addr, casFeatCode_documentUri);
  }
  /** @generated */    
  public void setDocumentUri(int addr, String v) {
        if (featOkTst && casFeat_documentUri == null)
      jcas.throwFeatMissing("documentUri", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    ll_cas.ll_setStringValue(addr, casFeatCode_documentUri, v);}
    
  
 
  /** @generated */
  final Feature casFeat_collectionId;
  /** @generated */
  final int     casFeatCode_collectionId;
  /** @generated */ 
  public String getCollectionId(int addr) {
        if (featOkTst && casFeat_collectionId == null)
      jcas.throwFeatMissing("collectionId", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    return ll_cas.ll_getStringValue(addr, casFeatCode_collectionId);
  }
  /** @generated */    
  public void setCollectionId(int addr, String v) {
        if (featOkTst && casFeat_collectionId == null)
      jcas.throwFeatMissing("collectionId", "de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData");
    ll_cas.ll_setStringValue(addr, casFeatCode_collectionId, v);}
    
  



  /** initialize variables to correspond with Cas Type and Features
	* @generated */
  public DocumentMetaData_Type(JCas jcas, Type casType) {
    super(jcas, casType);
    casImpl.getFSClassRegistry().addGeneratorForType((TypeImpl)this.casType, getFSGenerator());

 
    casFeat_documentTitle = jcas.getRequiredFeatureDE(casType, "documentTitle", "uima.cas.String", featOkTst);
    casFeatCode_documentTitle  = (null == casFeat_documentTitle) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_documentTitle).getCode();

 
    casFeat_documentId = jcas.getRequiredFeatureDE(casType, "documentId", "uima.cas.String", featOkTst);
    casFeatCode_documentId  = (null == casFeat_documentId) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_documentId).getCode();

 
    casFeat_documentUri = jcas.getRequiredFeatureDE(casType, "documentUri", "uima.cas.String", featOkTst);
    casFeatCode_documentUri  = (null == casFeat_documentUri) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_documentUri).getCode();

 
    casFeat_collectionId = jcas.getRequiredFeatureDE(casType, "collectionId", "uima.cas.String", featOkTst);
    casFeatCode_collectionId  = (null == casFeat_collectionId) ? JCas.INVALID_FEATURE_CODE : ((FeatureImpl)casFeat_collectionId).getCode();

  }
}



    