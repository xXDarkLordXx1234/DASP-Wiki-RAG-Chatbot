package de.tudarmstadt.ukp.dkpro.semantics.annotator.keyphrases;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.annotator.util.tagger.TreeTaggerPosMapping;
import de.tudarmstadt.ukp.dkpro.core.type.POS;
import de.tudarmstadt.ukp.dkpro.core.util.UimaUtils;
import de.tudarmstadt.ukp.dkpro.semantics.annotator.keyphrases.util.PosPatternFilter;
import de.tudarmstadt.ukp.dkpro.semantics.type.Keyphrase;
import de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidate;

/**
 * Removes all annotations that:
 * 1) contain less than MinTokens or more than MaxTokens
 * 2) do not conform to certain POS-combinations
 *
 * If there is a keyphrase index, it works on keyphrases. Otherwise, it works on candidates.
 *
 * @author zesch
 * 
 */
public class StructureFilter extends JCasAnnotator_ImplBase {

	public static final Logger logger = UIMAFramework.getLogger(StructureFilter.class);

    public static final String PARAM_MIN_TOKENS   = "MinTokens";
    public static final String PARAM_MAX_TOKENS   = "MaxTokens";
    public static final String PARAM_POS_PATTERNS = "UsePosPatterns";
    private int minTokens = 1;
    private int maxTokens = 4;
    private boolean usePosPatterns = false;
    
    // the mode is automatically determined from the indexes present in the CAS
    private enum Mode {
        Candidates,
        Keyphrases
    }
    private Mode mode;
    
    private PosPatternFilter posPatternFilter;

    @Override
	public void initialize(UimaContext context) throws ResourceInitializationException {
		super.initialize(context);

        minTokens = (Integer) context.getConfigParameterValue(PARAM_MIN_TOKENS);
        maxTokens = (Integer) context.getConfigParameterValue(PARAM_MAX_TOKENS);
        usePosPatterns = (Boolean) context.getConfigParameterValue(PARAM_POS_PATTERNS);

        if (usePosPatterns) {
            posPatternFilter = new PosPatternFilter(minTokens, maxTokens);
        }
    }

	@Override
	public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.CONFIG, "Entering " + this.getClass().getSimpleName());

        AnnotationIndex keyphraseIndex = jcas.getAnnotationIndex(Keyphrase.type);
        if (keyphraseIndex.size() > 0) {
            mode = Mode.Keyphrases;
        }
        else {
            mode = Mode.Candidates;
        }
        
        FSIterator annotationIter = null;
        if (mode.equals(Mode.Candidates)) {
            annotationIter = jcas.getAnnotationIndex(KeyphraseCandidate.type).iterator();
        }
        else if (mode.equals(Mode.Keyphrases)) {
            annotationIter = jcas.getAnnotationIndex(Keyphrase.type).iterator();
        }

        List<Annotation> toRemove = new ArrayList<Annotation>(); 
        while (annotationIter.hasNext()) {
            Annotation a = (Annotation) annotationIter.next();
            
            int start = a.getBegin();
            int end = a.getEnd();
            
            List<Annotation> annotations = UimaUtils.getAnnotations(jcas.getAnnotationIndex(POS.type).iterator(), start, end);

            if (annotations.size() == 0) {
                logger.log(Level.FINE, "Could not get annotations: " + a + ". Skipping!");
                continue;
            }
            
            if (usePosPatterns) {
                Map<String, String> tagMap = TreeTaggerPosMapping.getEnglishTagMap(); 
                List<String> posList = new ArrayList<String>();
                for (Annotation item : annotations) {
                    POS pos = (POS) item;
                    
                    if (tagMap.containsKey(pos.getPosValue())) {
                        posList.add( tagMap.get(pos.getPosValue()).substring(0,1) );
                        }
                    else {
                        posList.add( "O" );
                    }
                }
                
                if (!posPatternFilter.isValidPosPattern(posList)) {
                    toRemove.add(a);
                }
            }
            else {
                // TODO in the final results, there might be keyphrases of other size, as this only checks the original candidate terms *with* stopwords
//                if (annotations.size() < minTokens || annotations.size() > maxTokens) {
//                    toRemove.add(a);
//                }
                String termString = "";
                if (mode.equals(Mode.Candidates)) {
                    KeyphraseCandidate c = (KeyphraseCandidate) a;
                    termString = c.getKeyphrase();
                }
                else if (mode.equals(Mode.Keyphrases)) {
                    Keyphrase k = (Keyphrase) a;
                    termString = k.getKeyphrase();
                }

                termString = termString.trim();
                termString = termString.replaceAll("\\s{2,}"," ");
                String[] parts = termString.split(" ");
                if (parts.length < minTokens || parts.length > maxTokens) {
                    toRemove.add(a);
                }
            }
        }
        
        // remove candidates
        for (Annotation a : toRemove) {
            a.removeFromIndexes();
        }
	}
}