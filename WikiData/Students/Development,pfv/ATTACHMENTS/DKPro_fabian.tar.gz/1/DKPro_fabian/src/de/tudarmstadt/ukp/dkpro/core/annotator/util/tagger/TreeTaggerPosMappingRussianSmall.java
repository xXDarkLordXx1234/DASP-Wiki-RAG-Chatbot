package de.tudarmstadt.ukp.dkpro.core.annotator.util.tagger;

import java.util.HashMap;
import java.util.Map;

/**
 * See  http://www.ruscorpora.ru/en/corpora-morph.html
 *
 */
public class TreeTaggerPosMappingRussianSmall {
	
	
	
	public final static Map<String, String> TAG_MAP = new HashMap<String, String>() {
        private static final long serialVersionUID = 1L;
        {
        	put("A","ADJ");
        	put("A-NUM","ADJ"); //numeral adjective
            put("ADV","ADV");
            put("PRAEDIC","NN");
            put("S","NN");
            put("S-PRO","PR");
            put("A-PRO","PR");
            put("ADV-PRO","PR");
            put("PRAEDIC-PRO","PR");
            put("PR","PP");
            put("CONJ","CONJ");
            put("PARENTH","PUNC");
            put("V","V");
            put("NUM","CARD");
            put("INTJ","O");
            put("PART","O");
            
            put("PUNCT","PUNC");
            put("SENT","PUNC");
            
            
        }
    };
}
