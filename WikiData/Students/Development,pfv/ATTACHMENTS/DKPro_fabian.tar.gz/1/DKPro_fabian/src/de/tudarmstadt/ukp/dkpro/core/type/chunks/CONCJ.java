

/* First created by JCasGen Thu Aug 14 18:27:53 CEST 2008 */
package de.tudarmstadt.ukp.dkpro.core.type.chunks;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import de.tudarmstadt.ukp.dkpro.core.type.Chunk;


/** 
 * Updated by JCasGen Thu Aug 14 18:27:53 CEST 2008
 * XML source: /home/zesch/workspace/dkpro_core/desc/type/Chunk.xml
 * @generated */
public class CONCJ extends Chunk {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(CONCJ.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected CONCJ() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public CONCJ(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public CONCJ(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public CONCJ(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
}

    