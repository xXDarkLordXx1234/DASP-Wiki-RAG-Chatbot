

/* First created by JCasGen Fri Dec 19 14:20:46 CET 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.cas.FSArray;
import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.jcas.cas.FSList;


/** 
 * Updated by JCasGen Sun Jan 04 13:34:25 CET 2009
 * XML source: E:/workspace/dkpro_semantics/desc/type/Summary.xml
 * @generated */
public class Summary extends Annotation {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(Summary.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected Summary() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public Summary(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public Summary(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public Summary(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
 
    
  //*--------------*
  //* Feature: Sentences

  /** getter for Sentences - gets 
   * @generated */
  public FSArray getSentences() {
    if (Summary_Type.featOkTst && ((Summary_Type)jcasType).casFeat_Sentences == null)
      jcasType.jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    return (FSArray)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr, ((Summary_Type)jcasType).casFeatCode_Sentences)));}
    
  /** setter for Sentences - sets  
   * @generated */
  public void setSentences(FSArray v) {
    if (Summary_Type.featOkTst && ((Summary_Type)jcasType).casFeat_Sentences == null)
      jcasType.jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    jcasType.ll_cas.ll_setRefValue(addr, ((Summary_Type)jcasType).casFeatCode_Sentences, jcasType.ll_cas.ll_getFSRef(v));}    
    
  /** indexed getter for Sentences - gets an indexed value - 
   * @generated */
  public Sentence getSentences(int i) {
    if (Summary_Type.featOkTst && ((Summary_Type)jcasType).casFeat_Sentences == null)
      jcasType.jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    jcasType.jcas.checkArrayBounds(jcasType.ll_cas.ll_getRefValue(addr, ((Summary_Type)jcasType).casFeatCode_Sentences), i);
    return (Sentence)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefArrayValue(jcasType.ll_cas.ll_getRefValue(addr, ((Summary_Type)jcasType).casFeatCode_Sentences), i)));}

  /** indexed setter for Sentences - sets an indexed value - 
   * @generated */
  public void setSentences(int i, Sentence v) { 
    if (Summary_Type.featOkTst && ((Summary_Type)jcasType).casFeat_Sentences == null)
      jcasType.jcas.throwFeatMissing("Sentences", "de.tudarmstadt.ukp.dkpro.semantics.type.Summary");
    jcasType.jcas.checkArrayBounds(jcasType.ll_cas.ll_getRefValue(addr, ((Summary_Type)jcasType).casFeatCode_Sentences), i);
    jcasType.ll_cas.ll_setRefArrayValue(jcasType.ll_cas.ll_getRefValue(addr, ((Summary_Type)jcasType).casFeatCode_Sentences), i, jcasType.ll_cas.ll_getFSRef(v));}
  }

    