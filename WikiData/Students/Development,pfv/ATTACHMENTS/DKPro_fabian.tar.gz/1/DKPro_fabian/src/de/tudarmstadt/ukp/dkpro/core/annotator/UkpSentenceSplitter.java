package de.tudarmstadt.ukp.dkpro.core.annotator;

import java.text.BreakIterator;
import java.text.ParsePosition;
import java.util.Locale;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.resource.ResourceInitializationException;

import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import static de.tudarmstadt.ukp.dkpro.core.util.StringUtils.*;

public 
class UkpSentenceSplitter 
extends JCasAnnotator_ImplBase 
{
    public static final String PARAM_LOCALE = "Locale";

    private BreakIterator sentenceIterator;

    @Override
	public 
    void initialize(
    		UimaContext aContext) 
    throws ResourceInitializationException 
    {
        super.initialize(aContext);

        // FIXME RE 2009-04-29: Should use the language set in the CAS 
        // to determine the break iterator instance.
        String localeName = (String) aContext.getConfigParameterValue(PARAM_LOCALE);
        if (localeName == null || localeName == "") {
            sentenceIterator = BreakIterator.getSentenceInstance();
        } else {
            Locale locale = new Locale(localeName);
            sentenceIterator = BreakIterator.getSentenceInstance(locale);
        }
    }

    static abstract class Maker {
        abstract Annotation newAnnotation(JCas jcas, int start, int end);
    }

    JCas jcas;

    String input;

    ParsePosition pp = new ParsePosition(0);

    // *********************************************
    // * function pointers for new instances *
    // *********************************************
    static final Maker sentenceAnnotationMaker = new Maker() {
        Annotation newAnnotation(JCas jcas, int start, int end) {
            return new Sentence(jcas, start, end);
        }
    };

    // *************************************************************
    // * process *
    // *************************************************************
    public 
    void process(
    		JCas jcas) 
    throws AnalysisEngineProcessException 
    {
        this.jcas = jcas;

        input = jcas.getDocumentText();

        // Create Annotations
        makeAnnotations(sentenceAnnotationMaker, sentenceIterator);
    }

    // *************************************************************
    // * Helper Methods *
    // *************************************************************
    private
    void makeAnnotations(
    		Maker m, 
    		BreakIterator b) 
    {
        b.setText(input);
        for (int end = b.next(), start = b.first(); end != BreakIterator.DONE; start = end, end = b.next()) {
            // eliminate all-whitespace tokens
            if (!isWhitespace(input, start, end)) {
                m.newAnnotation(jcas, start, end).addToIndexes();
            }
        }
    }
}
