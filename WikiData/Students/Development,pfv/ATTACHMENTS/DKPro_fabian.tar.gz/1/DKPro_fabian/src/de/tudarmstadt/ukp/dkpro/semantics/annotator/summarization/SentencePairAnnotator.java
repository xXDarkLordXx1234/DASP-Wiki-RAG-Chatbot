package de.tudarmstadt.ukp.dkpro.semantics.annotator.summarization;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair;
import de.tudarmstadt.ukp.dkpro.semantics.type.SummarySourceDocument;
import de.tudarmstadt.ukp.dkpro.semantics.type.Tfidf;

/**
 * Annotates the similarity between all sentence pairs.
 * Similarity is measured by the cosine similarity between the tfidf vectors of the sentences.
 * 
 * Sentence pairs are created:
 * a) if SingleGraph is true:
 *    Sentence pairs are created between all sentences in the CAS. In case of multi-document summarization, this means that a single sentence graph is constructed from all documents. Some documents might not occur in the summary at all.
 * b) is SingleGraph is false:
 *    Sentence pairs are only created between sentences in a single source document. In case of multi-document summarization, the most central sentences from each document are selected from the single documents.

 * @author zesch
 */
public class SentencePairAnnotator extends JCasAnnotator_ImplBase {

    public final static Logger logger = UIMAFramework.getLogger(SentencePairAnnotator.class);

    public static final String SINGLE_GRAPH = "SingleGraph";

    private boolean singleGraph;
    
    private JCas jcas;
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
        super.initialize(context);
    
        this.singleGraph = (Boolean) context.getConfigParameterValue(SINGLE_GRAPH);    
    }

    @Override
    public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.FINE, "Entering SentencePairAnnotator");            
        
        this.jcas = jcas;
        
        AnnotationIndex sentenceIndex = ((AnnotationIndex) jcas.getAnnotationIndex(Sentence.type));
        
        if (singleGraph) {
            FSIterator sentenceIter = sentenceIndex.iterator();

            addSentencePairs(sentenceIter);
        }
        else {
            FSIterator summarySourceDocumentIter = jcas.getAnnotationIndex(SummarySourceDocument.type).iterator();
            while (summarySourceDocumentIter.hasNext()) {
                SummarySourceDocument ssd = (SummarySourceDocument) summarySourceDocumentIter.next();
                FSIterator sourceDocumentSentenceIterator = sentenceIndex.subiterator(ssd);
                
                addSentencePairs(sourceDocumentSentenceIterator);
            }
        }
    }

    /**
     * Adds a sentence pair to the CAS.
     * The offset of a sentence pair is set to equal the offset of the first sentence. Thus, sentence pairs are implicitely bound to a certain SummarySourceDocument.
     * 
     * @param sentenceIter An iterator over the sentences which should be used to create pairs.
     */
    private void addSentencePairs(FSIterator sentenceIter) {

        List<Sentence> sentenceList = new ArrayList<Sentence>();
        while (sentenceIter.hasNext()) {
            Sentence s1 = (Sentence) sentenceIter.next();
            sentenceList.add(s1);
        }

        for (Sentence s1 : sentenceList) {
            for (Sentence s2 : sentenceList) {
                if (s1.getBegin() > s2.getBegin()) {
                    continue;
                }

                if (s1.getBegin() ==  s2.getBegin()) {
                    continue;
                }

                double similarity = getSentenceSimilarity(s1,s2);    
                
                // by also setting the offset of sentence pairs, they are implicitely assigned to a certain SummarySourceDocument
                SentencePair sp = new SentencePair(jcas);
                sp.setBegin(s1.getBegin());
                sp.setEnd(s1.getEnd());
                sp.setSentence1(s1);
                sp.setSentence2(s2);
                sp.setSimilarity(similarity);
                sp.addToIndexes();
            }
        }
    }
    
    /**
     * @param s1 The first sentence.
     * @param s2 The second sentence.
     * @return The similarity between the given sentences.
     */
    private double getSentenceSimilarity(Sentence s1, Sentence s2) {

        Map<String,Double> sparseVector1 = getSparseVector(s1);
        Map<String,Double> sparseVector2 = getSparseVector(s2);
                
        return computeCosine(sparseVector1, sparseVector2);
    }
    
    /**
     * The sparse vector is represented as a HashMap.
     * 
     * @param s1 A sentence.
     * @return A sparse vector build from the given sentence.
     */
    private Map<String,Double> getSparseVector(Sentence s1) {        
        Map<String,Double> sv = new HashMap<String,Double>();
        FSIterator tfidfIter = jcas.getAnnotationIndex(Tfidf.type).subiterator(s1);
        while (tfidfIter.hasNext()) {
            Tfidf tfidf = (Tfidf) tfidfIter.next();
            sv.put(tfidf.getTerm(), tfidf.getTfidfValue());
        }
        return sv;
    }
    
    /**
     * Computes the cosine between two sparse vectors represented as maps.
     * @param v1 The first sparse vector represented as a map. 
     * @param v2 The second sparse vector represented as a map.
     * @return The cosine similarity between the two vectors.
     */
    private double computeCosine(Map<String, Double> v1, Map<String, Double> v2) {
        
        // cosine(a,b) =  a . b / sqrt(a^2 * b^2)
        double normValue1 = getL2Norm(v1);
        double normValue2 = getL2Norm(v2);
        
        if (normValue1 <= 0.0 || normValue2 <= 0.0) {
            return -1.0;
        }
        
        double cosine = sparseScalarProduct(v1, v2) / (normValue1 * normValue2);

        return cosine;
    }

    
    /**
     * Compute the scalar product of two sparse vectors represented as maps. The key indicates the position in the vector.
     * @param v1 The first sparse vector represented as a map. 
     * @param v2 The second sparse vector represented as a map.
     * @return
     */
    private double sparseScalarProduct(Map<String, Double> v1, Map<String, Double> v2) {
        double scalarProduct = 0.0;
        
        List<String> keyList = new ArrayList<String>(v1.size());
        keyList.addAll(v1.keySet());

        for (String key : keyList) {
            if (v2.containsKey(key)) {
                scalarProduct += v1.get(key) * v2.get(key);
            }
                
        }
        
        return scalarProduct;
    }
    
    /**
     * @param v The sparse vector.
     * @return The normalization value for a sparse vector represented as a map.
     */
    private double getL2Norm(Map<String, Double> v) {
        
        double sumOfSquares = 0.0;
        for (String key : v.keySet()) {
            sumOfSquares += v.get(key) * v.get(key);
        }
        
        return Math.sqrt(sumOfSquares);
    }

}