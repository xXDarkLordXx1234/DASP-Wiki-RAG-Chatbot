

/* First created by JCasGen Tue Dec 23 16:51:02 CET 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.tcas.Annotation;


/** 
 * Updated by JCasGen Sun Jan 04 13:32:00 CET 2009
 * XML source: E:/workspace/dkpro_semantics/desc/type/Tfidf.xml
 * @generated */
public class Tfidf extends Annotation {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(Tfidf.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected Tfidf() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public Tfidf(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public Tfidf(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public Tfidf(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
 
    
  //*--------------*
  //* Feature: tfidfValue

  /** getter for tfidfValue - gets 
   * @generated */
  public double getTfidfValue() {
    if (Tfidf_Type.featOkTst && ((Tfidf_Type)jcasType).casFeat_tfidfValue == null)
      jcasType.jcas.throwFeatMissing("tfidfValue", "de.tudarmstadt.ukp.dkpro.semantics.type.Tfidf");
    return jcasType.ll_cas.ll_getDoubleValue(addr, ((Tfidf_Type)jcasType).casFeatCode_tfidfValue);}
    
  /** setter for tfidfValue - sets  
   * @generated */
  public void setTfidfValue(double v) {
    if (Tfidf_Type.featOkTst && ((Tfidf_Type)jcasType).casFeat_tfidfValue == null)
      jcasType.jcas.throwFeatMissing("tfidfValue", "de.tudarmstadt.ukp.dkpro.semantics.type.Tfidf");
    jcasType.ll_cas.ll_setDoubleValue(addr, ((Tfidf_Type)jcasType).casFeatCode_tfidfValue, v);}    
   
    
  //*--------------*
  //* Feature: term

  /** getter for term - gets 
   * @generated */
  public String getTerm() {
    if (Tfidf_Type.featOkTst && ((Tfidf_Type)jcasType).casFeat_term == null)
      jcasType.jcas.throwFeatMissing("term", "de.tudarmstadt.ukp.dkpro.semantics.type.Tfidf");
    return jcasType.ll_cas.ll_getStringValue(addr, ((Tfidf_Type)jcasType).casFeatCode_term);}
    
  /** setter for term - sets  
   * @generated */
  public void setTerm(String v) {
    if (Tfidf_Type.featOkTst && ((Tfidf_Type)jcasType).casFeat_term == null)
      jcasType.jcas.throwFeatMissing("term", "de.tudarmstadt.ukp.dkpro.semantics.type.Tfidf");
    jcasType.ll_cas.ll_setStringValue(addr, ((Tfidf_Type)jcasType).casFeatCode_term, v);}    
  }

    