package de.tudarmstadt.ukp.dkpro.core.annotator.util.chunker;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.uima.UIMAFramework;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.util.StringUtils;

/**
 * Creates an external process of the TreeTagger chunker software and sends, receives data while keeping the process running during calls of runTagger()
 * Works only on Linux!
 * @author Christof Mueller
 * @author Torsten Zesch
 * @author Delphine Bernhard
 */
public class TreeTaggerChunkerWrapper {

	//logging
	private static final Logger logger = UIMAFramework.getLogger(TreeTaggerChunkerWrapper.class);
	
    public enum KnownChunkTypes {
        NC,
        VC,
        ADVC,
        PRT,
        PC,
        ADJC,
        CONCJ,
        LST,
        INTJ
    }
    
    private static final String protectionString = "#";
    
    // Chunker results
    private TaggerChunkerOutput taggerChunkerOutput;

    private final int SLEEP = 10;

    private ProcessBuilder mProBuilder;
    private Process mProcess;
    private BufferedReader mResultReader;
    private OutputStream mOut;

    private String languageCode;
    
    // Tree Tagger outputs iso encoded strings, thus the InputStreamReader must use CHARSET parameter
    private final String CHARSET = "ISO-8859-1";

    /**
     * creates tree tagger process 
     * 
     * @param treeTaggerPath path to the TreeTagger software
     * @param paramFileName file name of the paramter file to use for TreeTagger
     * @throws IOException
     */
    public TreeTaggerChunkerWrapper(String treeTaggerPath, String languageCode) throws IOException {
        this.languageCode = languageCode;
        
        String cmdPath = treeTaggerPath + File.separator + "cmd" + File.separator;
        
        String command;
        if (languageCode.equals("en")) {
            command = "tagger-chunker-english";
        }
        else if (languageCode.equals("de")) {
            command = "tagger-chunker-german";
        }
        else {
            throw new UnsupportedOperationException("Unknown language code. Only English 'en' or German 'de' are valid.");
        }
//        System.out.println(cmdPath + command);
        makeTreeTaggerCmdsExecutable(cmdPath);
        mProBuilder = new ProcessBuilder("/bin/sh","-c", cmdPath + command );
    }

    private void makeTreeTaggerCmdsExecutable(String cmdPath) {
		// all files in cmdPath need to be executable
    	File cmdDir = new File(cmdPath);
    	File[] files = cmdDir.listFiles(new FileFilter() {
    		public boolean accept(File file) {
    			return file.isFile();
    		}
    	});
    	
    	for (File file : files)	{
    		if (!file.canExecute()) {
    			file.setExecutable(true);
    		}
    	}
	}

	/**
     * Returns the lemmas assigned to the input text.
     * Ordering is the same as for the tokens. 
     * @return Lemmas assigned to input text.
     */
    public List<String> getChunks() {
        return taggerChunkerOutput.chunkList;
    }

    /**
     * Returns the tokens in the chunks. 
     * Ordering is the same as for the chunks. 
     * @return A list containing lists of tokens in the chunks.
     */
    public List<List<String>> getChunkTokens() {
        return taggerChunkerOutput.chunkTokenList;
    }

    /**
     * Runs TreeTagger on the input tokens.
     * @param tokens The tokens to be processed.
     * @return TaggerOutput An object containing tokens, lemmas and POS.
     * @throws IOException 
     */
    public void runTagger(List<String> tokens) throws IOException {
        String tokenString = StringUtils.join(tokens, System.getProperty("line.separator"));
        tokenString = protectChunkTags(tokenString);
        this.runTagger(tokenString);
    }

    /**
     * Runs TreeTagger on the input tokens.
     * @param tokens The tokens to be processed.
     * @return TaggerOutput An object containing tokens, lemmas and POS.
     * @throws IOException
     */
    public void runTagger(String tokens) throws IOException {

        taggerChunkerOutput = new TaggerChunkerOutput();
        
        logger.log(Level.FINE,"starting process");
        mProcess = mProBuilder.start();
        mResultReader = new BufferedReader( new InputStreamReader( mProcess.getInputStream(), CHARSET ) );
        mOut = mProcess.getOutputStream();

        // convert tokens to IS08559 as TreeTagger internally uses this encoding
        //   and may insert IS08559 characters into differently encoded characters

        taggerChunkerOutput.chunkList.clear();
        taggerChunkerOutput.chunkTokenList.clear();

        mOut.write(tokens.getBytes(CHARSET));
        mOut.close();

        String line = null;
        
        while(!mResultReader.ready()) {
            try {
                Thread.sleep(SLEEP);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } 

        Stack<StackItem> chunkStack = new Stack<StackItem>();
        int offset = 0;
        List<String> englishChunkTokens = new ArrayList<String>();
        while (mResultReader.ready()) {
            line = mResultReader.readLine();
            if(line==null) {
                throw new IOException("Unexpected end of TreeTagger-OutputStream.");
            }
            
            offset = addChunk(line, englishChunkTokens, offset, chunkStack);
        }
    }
    
    private Integer addChunk(String line, List<String> englishChunkTokens, int offset, Stack<StackItem> chunkStack) {
        if (languageCode.equals("de")) {
            String[] lineParts = line.split("\\t");

            List<String> chunkTokens = new ArrayList<String>();
            for (int i=1; i<lineParts.length; i++) {
                if (lineParts[i].length() > 0) {
                    chunkTokens.add(lineParts[i]);
                }
            }
            if (chunkTokens.size() > 0) {
                taggerChunkerOutput.chunkList.add(lineParts[0]);
                taggerChunkerOutput.chunkTokenList.add(chunkTokens); 
            }
        }
        else if (languageCode.equals("en")) {
            
            if (line.startsWith("<NC>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.NC, offset));
            }
            else if (line.startsWith("<VC>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.VC, offset));
            }
            else if (line.startsWith("<ADVC>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.ADVC, offset));
            }
            else if (line.startsWith("<PRT>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.PRT, offset));
            }
            else if (line.startsWith("<PC>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.PC, offset));
            }
            else if (line.startsWith("<ADJC>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.ADJC, offset));
            }
            else if (line.startsWith("<CONJC>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.CONCJ, offset));
            }
            else if (line.startsWith("<LST>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.LST, offset));
            }
            else if (line.startsWith("<INTJ>")) {
                chunkStack.push(new StackItem(KnownChunkTypes.INTJ, offset));
            }
            else if (line.matches("<[^/].*>")){
                System.err.println("Unknown clause type or literal tag in source file. Line: " + line);
            }
            else if (line.matches("</(NC|VC|ADVC|PRT|PC|ADJC|CONJC|LST|INTJ)>")) {
                StackItem stackItem = chunkStack.pop();
                List<String> chunkTokenList = new ArrayList<String>(englishChunkTokens.subList(stackItem.offset, offset));

                taggerChunkerOutput.chunkList.add(stackItem.chunk.name());
                taggerChunkerOutput.chunkTokenList.add(unprotectChunkTags(chunkTokenList));
            }
            else {  // not a clause marker => it's a token
                offset++;
                String token = line.split("\\t")[0];
                englishChunkTokens.add(token);
            }
        }
        return offset;
    }

    public void destroy() {
        try {
            mResultReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mProcess.destroy();
    }

    /**
     * Protect tags that might occur in the source text and that match chunk tags introduced by the TreeTaggerChunker.
     * If unprotected, these tags confuse the recognition of chunks.
     * @param text The text to protect.
     * @return The protected text.
     */
    private String protectChunkTags(String text) {
        text = text.replaceAll("<(NC|VC|ADVC|PRT|PC|ADJC|CONJC|LST|INTJ)>", protectionString + "$1" + protectionString);
        return text;
    }
    
    /**
     * @param textList A list of strings to unprotect.
     * @return An list of unprotected strings.
     */
    private List<String> unprotectChunkTags(List<String> textList) {
        List<String> unprotectedList = new ArrayList<String>();
        for (String item : textList) {
            String unprotectedItem = item.replaceAll(protectionString + "NC" + protectionString, "<NC>");
            unprotectedList.add(unprotectedItem);
        }
        return unprotectedList;
    }
    
    /**
     * Class for holding chunking results (chunks and number of tokens for each chunk)
     * @author Cigdem Toprak
     */
    class TaggerChunkerOutput {
        public List<String> chunkList            = new ArrayList<String>();
        public List<List<String>> chunkTokenList = new ArrayList<List<String>>();
    }

    private class StackItem {
        KnownChunkTypes chunk;
        Integer offset;

        public StackItem(KnownChunkTypes chunk, Integer offset) {
            super();
            this.chunk = chunk;
            this.offset = offset;
        }
    }
}