package de.tudarmstadt.ukp.dkpro.semantics.annotator.keyphrases;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.Token;
import de.tudarmstadt.ukp.dkpro.semantics.type.Keyphrase;

/**
 * If two keyphrases are directly adjacent, they can be joined to form a larger keyphrase.
 * They are not joined if there length exceeds maxKeyphraseLength that is given by a parameter.
 * This length is measured in Tokens underlying the keyphrase.
 *
 * @author zesch
 * 
 */

public class KeyphraseMerger extends JCasAnnotator_ImplBase {

	public static final Logger logger = UIMAFramework.getLogger(KeyphraseMerger.class);

    public static final String PARAM_MAX_LENGTH = "MaxLength";
    private int maxLength = 8;

    public static final String PARAM_KEEP_PARTS = "KeepParts";
    private boolean keepParts = false;
    
    private KeyphraseOffsetMerger offsetMerger;
    
    @Override
	public void initialize(UimaContext context) throws ResourceInitializationException {
		super.initialize(context);

        Object oMaxLength = context.getConfigParameterValue(PARAM_MAX_LENGTH);
        if (oMaxLength != null) {
            maxLength = (Integer) oMaxLength;
        }
        keepParts = (Boolean) context.getConfigParameterValue(PARAM_KEEP_PARTS);

    }

	@Override
	public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.CONFIG, "Entering " + this.getClass().getSimpleName());

        // do not create in initialize (there has to be a new Merger for each document)
        this.offsetMerger = new KeyphraseOffsetMerger(jcas);
        offsetMerger.merge();
	}
    
    public class KeyphraseOffsetMerger {
        JCas jcas;
        Map<Integer,Set<Keyphrase>> keyphraseOffsetMap;
        Map<Keyphrase,Integer> keyphraseTokenMap;
        Map<Keyphrase,String> keyphraseStringMap;
        Set<Keyphrase> toRemove; 
        Set<Keyphrase> toRegister;


        AnnotationIndex tokenIndex;
        
        public KeyphraseOffsetMerger(JCas jcas) {
            this.jcas = jcas;
            toRemove = new HashSet<Keyphrase>();
            toRegister = new HashSet<Keyphrase>();
            keyphraseOffsetMap = new TreeMap<Integer,Set<Keyphrase>>();
            keyphraseStringMap = new HashMap<Keyphrase,String>();
            
            FSIterator keyphraseIter = jcas.getAnnotationIndex(Keyphrase.type).iterator();
            tokenIndex = jcas.getAnnotationIndex(Token.type);
            keyphraseTokenMap = getKeyphraseTokenMap(keyphraseIter, tokenIndex);
            for (Keyphrase k : keyphraseTokenMap.keySet()) {
                registerKeyphrase(k);
                keyphraseStringMap.put(k, k.getKeyphrase());
            }
        }

        /**
         * Merges keyphrases.
         * 
         */
        public void merge() {
            boolean changes;
            do {
                changes = false;
                
                // iterate over the sorted (lowest first) start offsets and try to concatenate
                for (Integer startOffset : keyphraseOffsetMap.keySet()) {
                    if (concatenateKeyphrases(startOffset)) {
                        changes = true;
                        if (!keepParts) {
                            removeSubsumedKeyphrases();
                        }
                        else {
                            // TODO this does not really merge as expected
                            changes = false;
                        }
                        registerNewKeyphrases();
                    }
                }
            } while (changes);

//// disabled overlap merging due to bugs colliding with urgent deadlines            
//            do {
//                changes = false;
//                if (mergeOverlapping()) {
//                    changes = true;
//                    removeSubsumedKeyphrases();
//                    registerNewKeyphrases();
//                }
//            } while (changes);
        }
        
        private void removeSubsumedKeyphrases() {
            // remove keyphrases that are substituted by the merged keyphrase
            for (Keyphrase k : toRemove) {
                logger.log(Level.FINE, "Removing " + k.getKeyphrase());
                k.removeFromIndexes();
                keyphraseTokenMap.remove(k);
                keyphraseStringMap.remove(k);
                removeFromKeyphraseOffsetMap(k);
            }
            toRemove.clear();
        }
        
        private void registerNewKeyphrases() {
            for (Keyphrase k : toRegister) {
                logger.log(Level.FINE, "Registering " + k.getKeyphrase());
                registerKeyphrase(k);
            }
            toRegister.clear();
        }
 
        private void removeFromKeyphraseOffsetMap(Keyphrase k) {
            int tmpOffset = k.getBegin();
            Set<Keyphrase> keyphrases = keyphraseOffsetMap.get(tmpOffset);
            keyphrases.remove(k);
            keyphraseOffsetMap.put(tmpOffset, keyphrases);
        }
        
        // try to concatenate keyphrases at starting at startOffset with other keyphrases with subsequent offsets
        private boolean concatenateKeyphrases(int startOffset) {
            boolean changes = false;

            // concatenate keyphrases
            for (Keyphrase k : keyphraseOffsetMap.get(startOffset)) {
                // a keyphrase that can be merged with a keyphrase starting at k.getEnd() + 1
                int startOffsetNextKeyphrase = k.getEnd() + 1;
                if (keyphraseOffsetMap.containsKey(startOffsetNextKeyphrase)) {
                    // concatenate with all keyphrases in the list
                    if (concatenateWithSet(k, keyphraseOffsetMap.get(startOffsetNextKeyphrase))) {
                        changes = true;
                    }
                }
            }
            
            return changes;
        }
        
        private boolean concatenateWithSet(Keyphrase startKeyphrase, Set<Keyphrase> keyphraseSet) {
            boolean changes = false;
            
            if (!keyphraseTokenMap.containsKey(startKeyphrase)) {
                System.err.println(startKeyphrase);
                System.err.println(keyphraseTokenMap.keySet());
                System.exit(1);
            }
            
            int startKeyphraseTokens = keyphraseTokenMap.get(startKeyphrase);

            for (Keyphrase endKeyphrase : keyphraseSet) {
                int endKeyphraseTokens = keyphraseTokenMap.get(endKeyphrase);

                if (startKeyphraseTokens + endKeyphraseTokens > maxLength) {
                    continue;
                }
                else {
                    changes = true;
                }

                StringBuilder mergedString = new StringBuilder();
                mergedString.append(startKeyphrase.getKeyphrase());
                mergedString.append(" ");
                mergedString.append(endKeyphrase.getKeyphrase());
                
                // create a new keyphrase
                Keyphrase mergedKeyphrase = new Keyphrase(jcas);
                mergedKeyphrase.setBegin(startKeyphrase.getBegin());
                mergedKeyphrase.setEnd(endKeyphrase.getEnd());
                mergedKeyphrase.setKeyphrase(mergedString.toString());
                
                setKeyphraseScore(mergedKeyphrase, startKeyphrase, endKeyphrase);

                mergedKeyphrase.addToIndexes();
                toRegister.add(mergedKeyphrase);
                keyphraseTokenMap.put(mergedKeyphrase, startKeyphraseTokens + endKeyphraseTokens);
                keyphraseStringMap.put(mergedKeyphrase, mergedString.toString());
                
                toRemove.add(startKeyphrase);
                toRemove.add(endKeyphrase);
            }
            return changes;
        }
        
//        /**
//         * Merge overlapping keyphrases.
//         */
//        private boolean mergeOverlapping() {
//            boolean changes = false;
//
//            // overlaps can easily be detected: k.getEnd() < k2.getStart()
//            for (Integer startOffset : keyphraseOffsetMap.keySet()) {
//                for (Keyphrase startKeyphrase : keyphraseOffsetMap.get(startOffset)) {
//                    String startKeyphraseString = keyphraseStringMap.get(startKeyphrase);
//                    int startKeyphraseBegin = startKeyphrase.getBegin();
//                    int startKeyphraseEnd = startKeyphrase.getEnd();
//                    for (int i=startKeyphraseBegin; i<=startKeyphraseEnd; i++) {
//                        
//                        if (keyphraseOffsetMap.containsKey(i)) {
//                            Set<Keyphrase> overlappingKeyphrases = keyphraseOffsetMap.get(i);
//                            if (overlappingKeyphrases.size() > 0) {
//                                if (mergeOverlapping(startKeyphrase, startKeyphraseString, startKeyphraseBegin, startKeyphraseEnd, overlappingKeyphrases)) {
//                                    changes = true;
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//            
//            return changes;
//        }
        
//        // some parameters are only here for reasons of optimization (do not call the getter methods to often)
//        private boolean mergeOverlapping(Keyphrase startKeyphrase, String startKeyphraseString, int startKeyphraseBegin, int startKeyphraseEnd, Set<Keyphrase> overlappingKeyphrases) {
//            boolean changes = false;
//            for (Keyphrase  endKeyphrase : overlappingKeyphrases) {
//                String endKeyphraseString = keyphraseStringMap.get(endKeyphrase);
//                int endKeyphraseBegin = endKeyphrase.getBegin();
//                int endKeyphraseEnd = endKeyphrase.getEnd();
//                if (startKeyphraseString.equals(endKeyphraseString)) {
//                    continue;
//                }
//                
//                // test whether overlapping longer than k, otherwise overlapping is fully covered by k and we do not need to do anything
//                if (endKeyphraseEnd > startKeyphraseEnd) {
//                    int start = startKeyphraseEnd - endKeyphraseBegin;
//                    int end = endKeyphraseEnd - endKeyphraseBegin;
//                    
//                    StringBuilder mergedString = new StringBuilder();
//                    mergedString.append(startKeyphraseString);
//                    mergedString.append(endKeyphraseString.substring(start, end));
//
//                    // create a new keyphrase
//                    Keyphrase mergedKeyphrase = new Keyphrase(jcas);
//                    mergedKeyphrase.setBegin(startKeyphraseBegin);
//                    mergedKeyphrase.setEnd(endKeyphraseEnd);
//                    mergedKeyphrase.setKeyphrase(mergedString.toString());
//
//                    // check whether merged string does not exceed max token threshold
//                    int nrOfUnderlyingTokens = getNrofUnderlyingTokens(tokenIndex, mergedKeyphrase);
//                    if (nrOfUnderlyingTokens > maxLength) {
//                        return false;
//                    }
//                    
//                    setKeyphraseScore(mergedKeyphrase, startKeyphrase, endKeyphrase);
//
//                    mergedKeyphrase.addToIndexes();
//                    toRegister.add(mergedKeyphrase);
//                    keyphraseTokenMap.put(mergedKeyphrase, nrOfUnderlyingTokens);
//                    keyphraseStringMap.put(mergedKeyphrase, mergedString.toString());
//                    
//                    toRemove.add(startKeyphrase);
//                    toRemove.add(endKeyphrase);
//                    
//                    changes = true;
//                }
//            }
//            return changes;
//        }
        
        /**
         * Registers the keyphrase k within the OffsetMerger
         * @param k A keyphrase.
         */
        private void registerKeyphrase(Keyphrase k) {
            int startOffset = k.getBegin();
            Set<Keyphrase> keyphraseSet;
            if (keyphraseOffsetMap.containsKey(startOffset)) {
                keyphraseSet = keyphraseOffsetMap.get(startOffset);
            }
            else {
                keyphraseSet = new HashSet<Keyphrase>();
            }
            keyphraseSet.add(k);
            keyphraseOffsetMap.put(startOffset, keyphraseSet);
        }

        /**
         * @param keyphraseIter
         * @param tokenIndex
         * @return Returns a mapping between keyphrases and the number of underlying tokens.
         */
        private Map<Keyphrase,Integer> getKeyphraseTokenMap(FSIterator keyphraseIter, AnnotationIndex tokenIndex) {
            Map<Keyphrase,Integer> keyphraseTokenMap = new HashMap<Keyphrase,Integer>();
            while (keyphraseIter.hasNext()) {
                Keyphrase keyphrase = (Keyphrase) keyphraseIter.next();
                keyphraseTokenMap.put(keyphrase, getNrofUnderlyingTokens(tokenIndex, keyphrase));
            }
            return keyphraseTokenMap;
        }

        private int getNrofUnderlyingTokens(AnnotationIndex tokenIndex, Keyphrase keyphrase) {
            FSIterator tokenSubIter = tokenIndex.subiterator(keyphrase);
            int i = 0;
            while (tokenSubIter.hasNext()) {
                tokenSubIter.next();
                i++;
            }
            return i;
        }

        private void setKeyphraseScore(Keyphrase targetKeyphrase, Keyphrase k1, Keyphrase k2) {
            if (k1.getScore() >= k2.getScore()) {
                targetKeyphrase.setScore(k1.getScore());
            }
            else {
                targetKeyphrase.setScore(k2.getScore());
            }
        }
    }
}