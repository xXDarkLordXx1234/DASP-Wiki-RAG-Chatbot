package de.tudarmstadt.ukp.dkpro.core.annotator.util.tagger;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import de.tudarmstadt.ukp.dkpro.core.util.OsUtils;
import de.tudarmstadt.ukp.dkpro.core.util.StringUtils;

//import java.util.logging.Level;
//import java.util.logging.Logger;


import org.apache.uima.UIMAFramework;
import org.apache.uima.util.Logger;
import org.apache.uima.util.Level;

/**
 * Creates an external process of the TreeTagger software and sends, receives data while keeping the process running during calls of runTagger()
 * Works only on Linux!
 * @author Christof Mueller
 *
 */
public 
class TreeTaggerWrapperAlive implements 
TreeTaggerWrapper 
{
	//TODO check for OS and adjust process init
	
	//logging
	private static final Logger logger = UIMAFramework.getLogger(TreeTaggerWrapperAlive.class);
	
	private TaggerOutput taggerOutput;
   
    
    // the COMMAND to run TreeTagger
    //private final String TREETAGGERPATH = "/usr/local/sir/sir_data/tools/TreeTagger/bin/"; 
    //private final String PARAMETERFILE = "/usr/local/sir/sir_data/tools/TreeTagger/lib/german.par";
    //private final String TREETAGGERPATH = "~/sir_data/tools/TreeTagger/bin/"; 
    //private final String PARAMETERFILE = "~/sir_data/tools/TreeTagger/lib/german.par";
    
    private final String FLUSHTEXT = "TEXTFORFLUSHINGTREETAGGER";
    private final String STARTTEXT = "<STARTTEXTFORTREETAGGER>";
    private final String ENDTEXT = "<ENDTEXTFORTREETAGGER>";
    
    private final int SLEEP = 1;
    public static final int MAX_FLUSH_BEFORE_REFRESH = 8000;
    
    
    private ProcessBuilder mProBuilder;
    private Process mProcess;
    //private BufferedReader errin;
    private BufferedReader mResultReader;
    private OutputStream mOut;
    private int mRunCnt;
    private int externalProcessRefreshRate;
    
    // Tree Tagger outputs iso encoded strings
    // so InputStreamReader for reading tagging results must use CHARSET parameter
    private final String CHARSET = "ISO-8859-1";
    private final String CHARSET_RU = "UTF-8";
    private String charset;
    
    /**
     * creates tree tagger process which will be closed and recreated after the specified number of runs.
     * 
     * @param treeTaggerPath path to the TreeTagger software
     * @param paramFileName file name of the paramter file to use for TreeTagger
     * @param externalProcessRefreshRate after the specified number of runs the external tree tagger process is closed and a new one is started to prevent errors (has to be further checked)
     * @throws IOException
     */
    public TreeTaggerWrapperAlive(String treeTaggerPath, String paramFileName, int externalProcessRefreshRate, String charset) throws IOException {
        if(charset==null) {
        	this.charset = CHARSET;
        	logger.log(Level.WARNING, "no charset provided. using default: "+CHARSET);
        } else {
        	this.charset = charset;
        }
        
    	
        // The path to the bin directory should is relative to the tree tagger path.
        String binPath = treeTaggerPath + File.separator + "bin" + File.separator;
        String libPath = treeTaggerPath + File.separator + "lib" + File.separator;
        
        String paramFile = libPath + paramFileName;
        
        logger.log(Level.CONFIG, "binPath: " + binPath + "  paramFile:" + paramFile + "   charset:"+this.charset + "  refreshrate:" + externalProcessRefreshRate);
    	this.externalProcessRefreshRate = externalProcessRefreshRate;

        
        File paramFileTest = new File(paramFile);
        if (!paramFileTest.exists()) {
            throw new IOException("TreeTagger parameter file " + paramFile + " does not exist.");
        }
        
        File treeTaggerFileTest = new File(binPath + "tree-tagger"); 
        if (OsUtils.getOsType().equals("Windows")) {
            treeTaggerFileTest = new File(binPath + "tree-tagger.exe");
        }
        else if (System.getProperty("os.name").contains("Mac OS X")||System.getProperty("os.name").contains("Darwin"))
        {
        	treeTaggerFileTest = new File(binPath + "tree-tagger-mac-intel");
        }
        
        if (!treeTaggerFileTest.exists()) {
            throw new IOException("TreeTagger executable" + treeTaggerFileTest.getAbsolutePath() + " does not exist.");
        }
        
        if (!treeTaggerFileTest.canExecute()) {
        	treeTaggerFileTest.setExecutable(true);
        }
        
        taggerOutput = new TaggerOutput();
        mRunCnt=0;
        
        // we have to use different invocation methods for different operating systems
        if (OsUtils.getOsType().equals("Windows")) {
        	// the first to chars must be removed since pathnames dont begin with a "/" on win
        	String binPathWindows = binPath.substring(1);
        	paramFile = paramFile.substring(1);
            mProBuilder = new ProcessBuilder(binPathWindows+"tree-tagger.exe", 
            		"-token", "-lemma", "-no-unknown", paramFile);
        }
        else if (OsUtils.getOsType().equals("Linux")) {
        	String exeName = "tree-tagger";
        	
            if (System.getProperty("os.name").contains("Mac OS X")||System.getProperty("os.name").contains("Darwin"))
            {
            	exeName = "tree-tagger-mac-intel";
            }
        	
            String pathToTreeTagger = binPath + exeName;
            
            mProBuilder = new ProcessBuilder(pathToTreeTagger, "-token", 
            		"-lemma", "-no-unknown", paramFile);
        }
        
        
        logger.log(Level.FINE,"starting process");
        mProcess = mProBuilder.start();
        mResultReader = new BufferedReader( new InputStreamReader( mProcess.getInputStream(), this.charset ) );
        mOut = mProcess.getOutputStream();
        //errin = new BufferedReader (new InputStreamReader(mProcess.getErrorStream()));
    }

    /**
     * Returns the input text. 
     * @return The input text.
     */
    public List<String> getTokens() {
        return taggerOutput.tokens;
    }

    /**
     * Returns the lemmas assigned to the input text.
     * Ordering is the same as for the tokens. 
     * @return Lemmas assigned to input text.
     */
    public List<String> getLemmas() {
        return taggerOutput.lemmas;
    }
    
    /**
     * Returns the tags assigned to the input text. 
     * Ordering is the same as for the tokens. 
     * @return Tags assigned to input text.
     */
    public List<String> getTags() {
        return taggerOutput.tags;
    }

    /**
     * Runs TreeTagger on the input tokens.
     * @param tokens The tokens to be processed.
     * @return TaggerOutput An object containing tokens, lemmas and POS.
     * @throws IOException 
     */
    public void runTagger(List<String> tokens) throws IOException {
        String tokenString = StringUtils.join(tokens, System.getProperty("line.separator"));
        this.runTagger(tokenString);
    }
    
    /**
     * Runs TreeTagger on the input tokens.
     * @param tokens The tokens to be processed.
     * @return TaggerOutput An object containing tokens, lemmas and POS.
     * @throws IOException
     */
    public void runTagger(String tokens) throws IOException {

      // convert tokens to IS08559 as TreeTagger internally uses this encoding
      //   and may insert IS08559 characters into differently encoded characters
 
      
      
      //mProBuilder.redirectErrorStream(true);
      if(mRunCnt>=externalProcessRefreshRate) {
    	  logger.log(Level.CONFIG, "refreshing treetaggerprocess after "+ mRunCnt +" runs.");
          mOut.close();
          mResultReader.close();
          mProcess.destroy();
          
          mProcess = mProBuilder.start();
          mResultReader = new BufferedReader( new InputStreamReader( mProcess.getInputStream(), charset ) );
          mOut = mProcess.getOutputStream();
          mRunCnt = 0;
      }
      mRunCnt++;
      
      taggerOutput.tokens.clear();     
      taggerOutput.lemmas.clear();
      taggerOutput.tags.clear();
          
      String lf = System.getProperty("line.separator");
      
      String startText = new String(STARTTEXT+lf+"."+lf);
      String endText = new String(lf+ENDTEXT+lf+"."+lf);
      String flushText = new String(lf+FLUSHTEXT+lf);
      
      mOut.write(startText.getBytes(charset));
      mOut.write(tokens.getBytes(charset));
      mOut.write(endText.getBytes(charset));
      mOut.write(flushText.getBytes(charset));
      mOut.flush();
      
      String line = null;
      String[] lineParts;
      boolean gotAll=false;
      boolean isToken=false;
      boolean foundStart = false;
      while(!gotAll) {
          
        if(!mResultReader.ready()) {
            mOut.write(flushText.getBytes(charset));
            mOut.flush();
            /*
            nFlushs++;
            if(nFlushs>MAX_FLUSH_BEFORE_REFRESH) {
            	System.out.println("more than "+MAX_FLUSH_BEFORE_REFRESH+" flushs => refresh");
            	//System.out.println("refresh and exiting");
            	//gotAll = true;
            	
            	//System.out.println(tokens.length());
            	mOut.close();
                mResultReader.close();
                mProcess.destroy();
                
                mProcess = mProBuilder.start();
                mResultReader = new BufferedReader( new InputStreamReader( mProcess.getInputStream(), charset ) );
                mOut = mProcess.getOutputStream();
                mRunCnt = 0;
                
                taggerOutput.tokens.clear();     
                taggerOutput.lemmas.clear();
                taggerOutput.tags.clear();
                    
                
                mOut.write(startText.getBytes(charset));
                mOut.write(tokens.getBytes(charset));
                mOut.write(endText.getBytes(charset));
                mOut.write(flushText.getBytes(charset));
                mOut.flush();
                foundStart = false;
                nFlushs = 0;
               	
            }
            */
            //System.out.println("flush:"+nFlushs);
            
            try {
                    Thread.sleep(SLEEP);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            
        } else {
        	//nFlushs = 0;
            line = mResultReader.readLine();
            if(line==null)
                throw new IOException("Unexpected end of TreeTagger-OutputStream.");
            if (line.indexOf(ENDTEXT)!=-1) {
                gotAll=true;
                isToken=false;
                foundStart = false;
            }
            if (isToken && line!=null && !line.equals("")){
                lineParts = line.split("\\s"); // matches a whitespace character
                taggerOutput.tokens.add(lineParts[0]);
                taggerOutput.tags.add(lineParts[1]);
                // TreeTagger sometimes outputs multiple lemmas e.g. Auto|Autos
                // we must choose one => always take the first
                String[] lemmaParts = lineParts[2].split("\\|");
                //taggerOutput.lemmas.add(lineParts[2]);
                taggerOutput.lemmas.add(lemmaParts[0]);
            }
            if(line.indexOf(STARTTEXT)!=-1) {
                foundStart = true;
            } 
            if (foundStart && !isToken && (line.indexOf(".")==0)) {
                isToken = true;
            }
                 
        }
      }
    }
    
//    private void writeTokens(String tokens, OutputStream mOut) throws UnsupportedEncodingException, IOException {
//        int maxTokenLength = 15; // strings with a higher length should be split up (TreeTagger might stop if package size is too large)
//        int maxTokens = 3;       // maximum number of tokens allowed 
//
//        // only split tokens if they are too large
//        if (tokens.length() > maxTokenLength) {
//            List<String> tokenStringList = new ArrayList<String>();
//
//            String[] tokenArray = tokens.split(System.getProperty("line.separator"));
//            int nrOfTokens = tokenArray.length;
//
//            List<String> tokenList = new ArrayList<String>();
//            for (int i=0; i<nrOfTokens; i++) {
//                if (i % maxTokens == 0 && i != 0) {
//                    tokenStringList.add(StringUtils.join(tokenList, System.getProperty("line.separator")) + System.getProperty("line.separator"));
//                    tokenList.clear();
//                }
//                tokenList.add(tokenArray[i]);
//            }
//            tokenStringList.add(StringUtils.join(tokenList, System.getProperty("line.separator")) + System.getProperty("line.separator"));
//
//            for (String tokenString : tokenStringList) {
//                mOut.write(tokenString.getBytes(charset));
//            }
//        }
//        else {
//            mOut.write(tokens.getBytes(charset));
//        }
//    }
    
    
    public 
    void destroy() 
    {
		if (mResultReader != null) {
			try {
				mResultReader.close();
			} catch (IOException e) {
				// Ignore
			}
		}
		if (mOut != null) {
			try {
				mOut.close();
			} catch (IOException e) {
				// Ignore
			}
		}
		
    	if (mProcess != null) {
    		logger.log(Level.FINE, "Destroying TreeTagger process");
            mProcess.destroy();
    	}
    }
    
    /**
     * holds Tagging results
     */
    class TaggerOutput {
        public List<String> tokens = new ArrayList<String>();
        public List<String> lemmas = new ArrayList<String>();
        public List<String> tags   = new ArrayList<String>();
    }
}