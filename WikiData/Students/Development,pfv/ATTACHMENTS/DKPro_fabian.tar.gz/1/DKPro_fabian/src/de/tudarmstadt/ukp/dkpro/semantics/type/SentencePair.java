

/* First created by JCasGen Fri Dec 19 17:24:36 CET 2008 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import org.apache.uima.jcas.tcas.Annotation;


/** 
 * Updated by JCasGen Sun Jan 04 13:33:23 CET 2009
 * XML source: E:/workspace/dkpro_semantics/desc/type/SentencePair.xml
 * @generated */
public class SentencePair extends Annotation {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(SentencePair.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected SentencePair() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public SentencePair(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public SentencePair(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public SentencePair(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
 
    
  //*--------------*
  //* Feature: Sentence1

  /** getter for Sentence1 - gets 
   * @generated */
  public Sentence getSentence1() {
    if (SentencePair_Type.featOkTst && ((SentencePair_Type)jcasType).casFeat_Sentence1 == null)
      jcasType.jcas.throwFeatMissing("Sentence1", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    return (Sentence)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr, ((SentencePair_Type)jcasType).casFeatCode_Sentence1)));}
    
  /** setter for Sentence1 - sets  
   * @generated */
  public void setSentence1(Sentence v) {
    if (SentencePair_Type.featOkTst && ((SentencePair_Type)jcasType).casFeat_Sentence1 == null)
      jcasType.jcas.throwFeatMissing("Sentence1", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    jcasType.ll_cas.ll_setRefValue(addr, ((SentencePair_Type)jcasType).casFeatCode_Sentence1, jcasType.ll_cas.ll_getFSRef(v));}    
   
    
  //*--------------*
  //* Feature: Sentence2

  /** getter for Sentence2 - gets 
   * @generated */
  public Sentence getSentence2() {
    if (SentencePair_Type.featOkTst && ((SentencePair_Type)jcasType).casFeat_Sentence2 == null)
      jcasType.jcas.throwFeatMissing("Sentence2", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    return (Sentence)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr, ((SentencePair_Type)jcasType).casFeatCode_Sentence2)));}
    
  /** setter for Sentence2 - sets  
   * @generated */
  public void setSentence2(Sentence v) {
    if (SentencePair_Type.featOkTst && ((SentencePair_Type)jcasType).casFeat_Sentence2 == null)
      jcasType.jcas.throwFeatMissing("Sentence2", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    jcasType.ll_cas.ll_setRefValue(addr, ((SentencePair_Type)jcasType).casFeatCode_Sentence2, jcasType.ll_cas.ll_getFSRef(v));}    
   
    
  //*--------------*
  //* Feature: Similarity

  /** getter for Similarity - gets 
   * @generated */
  public double getSimilarity() {
    if (SentencePair_Type.featOkTst && ((SentencePair_Type)jcasType).casFeat_Similarity == null)
      jcasType.jcas.throwFeatMissing("Similarity", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    return jcasType.ll_cas.ll_getDoubleValue(addr, ((SentencePair_Type)jcasType).casFeatCode_Similarity);}
    
  /** setter for Similarity - sets  
   * @generated */
  public void setSimilarity(double v) {
    if (SentencePair_Type.featOkTst && ((SentencePair_Type)jcasType).casFeat_Similarity == null)
      jcasType.jcas.throwFeatMissing("Similarity", "de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair");
    jcasType.ll_cas.ll_setDoubleValue(addr, ((SentencePair_Type)jcasType).casFeatCode_Similarity, v);}    
  }

    