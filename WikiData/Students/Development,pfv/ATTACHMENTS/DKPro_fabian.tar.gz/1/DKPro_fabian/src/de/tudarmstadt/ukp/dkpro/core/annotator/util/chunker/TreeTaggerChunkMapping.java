package de.tudarmstadt.ukp.dkpro.core.annotator.util.chunker;

import java.util.HashMap;
import java.util.Map;

public class TreeTaggerChunkMapping {

    private final static Map<String, String> germanChunkMap = new HashMap<String, String>() {
        private static final long serialVersionUID = 1L;
        {
            put("NC"   , "NC" );
            put("VC"   , "VC" );
            put("PC"   , "PC" );
            put("ADVC" , "ADVC" );
            put("PRT"  , "PRT");
            put("0"    , "O" );
        }
    };

    private final static Map<String, String> englishChunkMap = new HashMap<String, String>() {

		private static final long serialVersionUID = 1L;

		{
           
            put("NC"   , "NC" );
            put("VC"   , "VC" );
            put("PC"   , "PC" );
            put("ADVC" , "ADVC");
            put("ADJC" , "ADJC");
            put("CONCJ", "CONCJ");
            put("INTJ" , "INTJ");
            put("LST"  , "LST");
            put("PRT"  , "PRT");
            put("0"    , "O" );
            
        }
    };
    
    public static Map<String, String> getGermanChunkMap() {
        return germanChunkMap;
    }
    
    public static Map<String, String> getEnglishChunkMap(){
    	return englishChunkMap;
    }
}