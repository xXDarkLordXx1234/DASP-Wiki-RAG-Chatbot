package de.tudarmstadt.ukp.dkpro.core.annotator;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.util.*;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceAccessException;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.annotator.util.tagger.TreeTaggerPosMapping;
import de.tudarmstadt.ukp.dkpro.core.annotator.util.tagger.TreeTaggerWrapperAlive;
import de.tudarmstadt.ukp.dkpro.core.type.Lemma;
import de.tudarmstadt.ukp.dkpro.core.type.Token;

/**
 * 
 * Works only on Linux or Windows Vista.
 *
 */
public 
class TreeTaggerPosLemma 
extends JCasAnnotator_ImplBase 
{
	private static final Logger logger = UIMAFramework.getLogger(TreeTaggerPosLemma.class);

	// pipeline to TreeTagger process has to be refreshed, otherwise it breaks from time to time
	public static final String PARAM_EXTERNAL_PROCESS_REFRESH_RATE = "ExternalProcessRefreshRate";
	
	public static final String PARAM_TREETAGGER_PARAMETER_FILE = "TreeTaggerParameterFile";
	
    public static final String PARAM_LANGUAGE_CODE = "LanguageCode";

    public static final String RESOURCE_TREETAGGER = "TreeTagger";

    // time to wait for thread to finish before killing the thread
    private static final int WAIT_TIME = 5000;

    private static final String PACKAGE = "de.tudarmstadt.ukp.dkpro.core.type.pos.";
    
    private final String CHARSET_LATIN = "ISO-8859-1";
    private final String CHARSET_UTF8 = "UTF-8";
    
    private TreeTaggerWrapperAlive treeTagger; 
	private TaggerThread treeTaggerThread;
    
    private String treeTaggerPath;

    private int externalProcessRefreshRate = 1000;       // setting default to 1000
    private String parameterFile = "english.par";   
    private String languageCode = "en";             
    private boolean languageOverride = false;
    private String charset = CHARSET_LATIN;
    
    
    //*************************************************************
    //*                        initialize                         *
    //*************************************************************       
	public 
	void initialize(
			UimaContext aContext)
	throws ResourceInitializationException 
	{
		// This saves the value of aContext in a field and makes
        // it available via the getContext() method of the superclass
        super.initialize(aContext);

//        logger.setLevel(Level.FINE);
        logger.log(Level.CONFIG, "Initializing " + this.getClass().getSimpleName());

        // get parameters
		if ((Integer)getContext().getConfigParameterValue(PARAM_EXTERNAL_PROCESS_REFRESH_RATE) != null) {
		    // if parameter is set, override default
            externalProcessRefreshRate = (Integer) getContext().getConfigParameterValue(PARAM_EXTERNAL_PROCESS_REFRESH_RATE);
        }
 
        if ((String)getContext().getConfigParameterValue(PARAM_LANGUAGE_CODE) != null) {
            languageCode = (String) getContext().getConfigParameterValue(PARAM_LANGUAGE_CODE);
            languageOverride = true;

            if (languageCode.equals("en")) {
                parameterFile = "english.par";
                charset = CHARSET_LATIN;
            }
            else if (languageCode.equals("de")) {
                parameterFile = "german.par";
                charset = CHARSET_LATIN;
            }
            else if (languageCode.equals("ru")) {
                parameterFile = "russian-small.par";
                charset = CHARSET_UTF8;
            }else if (languageCode.equals("fr")) {
                parameterFile = "french.par";
                charset = CHARSET_LATIN;
            }else {
                throw new ResourceInitializationException(new Throwable("The language code '" + languageCode + "' is not supported by the current DKPro implementation of TreeTagger."));
            }
        }
        
        if ((String)getContext().getConfigParameterValue(PARAM_TREETAGGER_PARAMETER_FILE) != null) {
            parameterFile = (String) getContext().getConfigParameterValue(PARAM_TREETAGGER_PARAMETER_FILE);
        }
        
        treeTaggerPath = null;
        try {
            treeTaggerPath = getContext().getResourceURL(RESOURCE_TREETAGGER).toURI().getPath();
        } 
        catch (URISyntaxException e1) {
            throw new ResourceInitializationException(e1);
        }
        catch (ResourceAccessException e1) {
            throw new ResourceInitializationException(e1);
        }
	}

    @SuppressWarnings("deprecation")
    // I know that thread.stop() is deprecated, but is there another way to kill the thread?

    //*************************************************************
    //*                        process                            *
    //*************************************************************       
    public 
    void process(
    		JCas aJCas) 
    throws AnalysisEngineProcessException 
    {
        logger.log(Level.CONFIG, "Entering " + this.getClass().getSimpleName());

        // Start TT lazily
        if (treeTagger == null) {
            getInstance();
        }
        
        // If language override is not active && the document language is
		// "x-unspecified" which means that is has not been set at all
		// then we should throw an exception, as we do not know what language to
		// use. Using a default language in this case, could lead to very
		// confusing results for the user that are hard to track down.
        if (!languageOverride && aJCas.getDocumentLanguage().equals("x-unspecified")) {
            throw new AnalysisEngineProcessException(new Throwable("Neither the LanguageCode parameter nor the document language is set. Do not know what language to use. Exiting."));
        }

        // TODO an optimization would be to write a TreeTagger manager that
		// keeps references to different TreeTagger processes with different
		// parameter files if necessary.
        
        // If language override is not active, we switch the language version of
		// TreeTagger according to the document language set. If the current
		// language code is not the same as the document level, we have to
		// switch, i.e. we have to restart the TreeTagger with a different
		// parameter file.
        if (!languageOverride && !languageCode.equals(aJCas.getDocumentLanguage())) {
            String newParameterFile;
            String newCharset;
            if (aJCas.getDocumentLanguage().equals("en")) {
                newParameterFile = "english.par";
                newCharset = CHARSET_LATIN;
            }
            else if (aJCas.getDocumentLanguage().equals("de")) {
                newParameterFile = "german.par";
                newCharset = CHARSET_LATIN;
            }
            else if (languageCode.equals("ru")) {
                newParameterFile = "russian-small.par";
                newCharset = CHARSET_UTF8;
            }
            else {
                throw new AnalysisEngineProcessException(new Throwable("The language code '" + aJCas.getDocumentLanguage() + "' is not supported by the current UIMA implementation of TreeTagger."));
            }

            this.languageCode = aJCas.getDocumentLanguage();
            getInstance(newParameterFile,newCharset);
        }

        AnnotationIndex tokenIndex = (AnnotationIndex) aJCas.getJFSIndexRepository().getAnnotationIndex(Token.type);
        
        // get all tokens and write to a StringBuffer - one token a line
		String taggerInputString = getTokenString(tokenIndex);
        

        // create a new tagger thread
        try {
            treeTaggerThread = new TaggerThread(taggerInputString);
        } catch (IOException e) {
            logger.log(Level.INFO, "IOException while creating treeTagger.");
            throw new AnalysisEngineProcessException(e);
        }

        try {
            treeTaggerThread.start();
            treeTaggerThread.setAllDone(true);
            treeTaggerThread.join(WAIT_TIME);    // wait a maximum of WAIT_TIME milliseconds, before killing the thread
            if (treeTaggerThread.isAlive()) {
                treeTaggerThread.stop();
                treeTagger.destroy();
                treeTagger = null;
                logger.log(Level.INFO, "waited too long for TreeTagger to return. Trying to recover.");
                try {
                    treeTagger = new TreeTaggerWrapperAlive(treeTaggerPath, parameterFile, externalProcessRefreshRate,charset);
                    treeTaggerThread = new TaggerThread(taggerInputString);
                    treeTaggerThread.start();
                    treeTaggerThread.setAllDone(true);
                    treeTaggerThread.join(WAIT_TIME);
                    if (treeTaggerThread.isAlive()) {
                        treeTaggerThread.stop();
                        treeTagger.destroy();
                        treeTagger = null;
                        logger.log(Level.INFO, "waited too long for TreeTagger to return. Skipping that document.");
                        return;
                    }
                } catch (IOException e) {
                    logger.log(Level.INFO, "IOException while creating new instance of TreeTaggerWrapperAlive");
                    e.printStackTrace();
                    return;
                }
            }
        } catch (InterruptedException e) {
            logger.log(Level.INFO, "Thread was interrupted");
        }

		List<String> lemmas = treeTagger.getLemmas();
		List<String> tags = treeTagger.getTags();

		logger.log(Level.FINE, "tokens anno: " + tokenIndex.size() + " tt: " + treeTagger.getTokens().size());
		
		FSIterator tokenIt = tokenIndex.iterator();
		
		int i = 0;
		while(tokenIt.hasNext()) {

            Token tokenAnnotation = (Token) tokenIt.next();
            int begin = tokenAnnotation.getBegin();
            int end   = tokenAnnotation.getEnd(); 
            
            Lemma lemmaAnnotation = new Lemma(aJCas);
            lemmaAnnotation.setBegin(begin);
            lemmaAnnotation.setEnd(end);
            lemmaAnnotation.setValue(lemmas.get(i));
            lemmaAnnotation.addToIndexes();

            addPartOfSpeechAnnotation(aJCas, begin, end, tags.get(i));

			i++;
		}
	}

    @Override
    public 
    void collectionProcessComplete() 
    throws AnalysisEngineProcessException 
    {
    	destroy();
    }
    
    @Override
    public 
    void destroy() 
    {
    	if (treeTagger != null) {
    		treeTagger.destroy();
    	}
    }

    //*************************************************************
    //*                Private Methods                            *
    //*************************************************************         
    
    /**
     * Creates a input string for the TreeTagger from the token index.
     * One token has to be on a single line.
     * @param tokenIndex The UIMA index of all tokens.
     * @return A string with each token on a single line.
     */
    private 
    String getTokenString(
    		AnnotationIndex tokenIndex) 
    {
        FSIterator tokenIterator = tokenIndex.iterator();
        StringBuffer sb = new StringBuffer();
        
        while (tokenIterator.hasNext()) {
            Token tokenAnnotation = (Token) tokenIterator.next();
            String token=null;
            token = tokenAnnotation.getCoveredText();
            
            //convert | to ~ because TreeTagger is using | for separating lemmas
            token = token.replaceAll("\\|", "\\~");
            
            sb.append(token);
            sb.append(System.getProperty("line.separator"));
        }

        return sb.toString();
    }
    
    /**
     * Add the correct part of speech annotation for the given tag.
     * @param begin The begin offset of the annotation.
     * @param end The end offset of the annotation.
     * @param tag The tag as computed by TreeTagger
     * @throws AnalysisEngineProcessException 
     */
    private 
    void addPartOfSpeechAnnotation(
    		JCas aJCas, 
    		int begin, 
    		int end,
    		String tag)
    throws AnalysisEngineProcessException 
    {
        // TODO this depends on the language of the source document and the
		// tagset that is valid for this language

        String setBeginMethodName     = "setBegin";
        String setEndMethodName       = "setEnd";
        String setPosValueMethodName  = "setPosValue";
        String addToIndexesMethodName = "addToIndexes";
        
        String tagClass = getTagClass(tag);
        
        // create the necessary objects and methods
        String posClassName = PACKAGE + tagClass;
        Class posClass;
        Method setBegin;
        Method setEnd;
        Method setPosValue;
        Method addToIndexes;
        
        Object posInstance;
            try {
                posClass = Class.forName(posClassName);

                Class[] setBeginParameterTypes     = new Class[]{int.class};
                Class[] setEndParameterTypes       = new Class[]{int.class};
                Class[] setPosValueParameterTypes  = new Class[]{String.class};
                Class[] addToIndexesParameterTypes = new Class[]{};
                
                setBegin     = posClass.getMethod(setBeginMethodName,     setBeginParameterTypes);
                setEnd       = posClass.getMethod(setEndMethodName,       setEndParameterTypes);
                setPosValue  = posClass.getMethod(setPosValueMethodName,  setPosValueParameterTypes);
                addToIndexes = posClass.getMethod(addToIndexesMethodName, addToIndexesParameterTypes);
                
                Class[] constructorTypes = new Class[]{JCas.class};
                Constructor constructor = posClass.getConstructor(constructorTypes);
              
                Object[] constructorArguments = new Object[]{aJCas};
                posInstance = constructor.newInstance(constructorArguments);

                Object[] setBeginArguments    = new Object[]{begin};
                Object[] setEndArguments      = new Object[]{end};
                Object[] setPosValueArguments = new Object[]{tag};
                
                // invoke the setter methods on the POS object
                setBegin.invoke(posInstance, setBeginArguments);
                setEnd.invoke(posInstance, setEndArguments);
                setPosValue.invoke(posInstance, setPosValueArguments);
                addToIndexes.invoke(posInstance);
                
            } catch (ClassNotFoundException e) {
                logger.log(Level.SEVERE, "No such class " + posClassName, new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (NoSuchMethodException e) {
                logger.log(Level.SEVERE, "No such method", new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (IllegalArgumentException e) {
                logger.log(Level.SEVERE, "You can call this method, but not with THIS arguments.", new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (IllegalAccessException e) {
                logger.log(Level.SEVERE, "You're not allowed to call this method.", new Throwable());
                throw new AnalysisEngineProcessException(e);
            } catch (InvocationTargetException e) {
                logger.log(Level.SEVERE, "Invoked method has thrown an exception.", new Throwable(e.getCause()));
                throw new AnalysisEngineProcessException(e);
            } catch (InstantiationException e) {
                logger.log(Level.SEVERE, "Instantiation exception", new Throwable());
                throw new AnalysisEngineProcessException(e);
            }
        
    }
    
    private String getTagClass(String tag) throws AnalysisEngineProcessException {
        Map<String, String> tagMap = null;
        if (languageCode.equals("en")) {
            tagMap = TreeTaggerPosMapping.getEnglishTagMap(); 
        }
        else if (languageCode.equals("de")) {
            tagMap = TreeTaggerPosMapping.getGermanTagMap(); 
        } else if (languageCode.equals("ru")) {
        	tagMap = TreeTaggerPosMapping.getRussianTagMap();
        } else if (languageCode.equals("fr")) {
        	tagMap = TreeTaggerPosMapping.getFrenchTagMap();
        }
        else {
            throw new AnalysisEngineProcessException(new Throwable("There is no tag mapping for languageCode " + this.languageCode));
        }
        
        if (tagMap.containsKey(tag)) {
            return tagMap.get(tag);
        }
        else {
            logger.log(Level.WARNING, "TagMap does not contain tag: " + tag);
            return "O"; // return default "Other" tag for this tag
        }
        
    }
    
    /**
     * Get a new instance of the TreeTaggerWrapperAlive with the specified parameter file.
     * @param parameterFile A tree tagger parameter file.
     */
    private void getInstance(String parameterFile, String charset) {
        this.parameterFile = parameterFile;
        this.charset = charset;
        logger.log(Level.INFO, "Restarting TreeTagger with parameter file: " + parameterFile);
        getInstance();
    }

    /**
     * Get a new instance of the TreeTaggerWrapperAlive.
     */
    private void getInstance() {
        try {
            if (treeTagger != null) {
                treeTagger.destroy();    // destroy a running instance of TreeTagger before creating a new one
            }
//            logger.log(Level.INFO, treeTaggerPath + " " + parameterFile + " " + externalProcessRefreshRate);
            treeTagger = new TreeTaggerWrapperAlive(treeTaggerPath, parameterFile, externalProcessRefreshRate,charset);
        } catch (IOException e) {
            logger.log(Level.INFO, "IOException while creating new instance of TreeTaggerWrapperAlive");
            e.printStackTrace();
            return;
        }
    }
    
        

    /**
     * A thread that we use to run TreeTagger. If it crashes in an infinite loop, we are able to silently kill the thread.
     * @author zesch
     *
     */
    class TaggerThread extends Thread {
        
        private boolean allDone = false;
        private String inputString;
        
        public TaggerThread(String inputString) throws IOException {
            this.inputString = inputString;
        }
      
        public void run() {
            do {
                try {
                    treeTagger.runTagger(inputString);
                } catch (IOException e) {
                	//System.out.println(inputString);
                    e.printStackTrace();
                }
            } while (!allDone);
        }

        public void runTagger(String inputText) {
        }
        
        public String getInputString() {
            return inputString;
        }

        public void setAllDone(boolean allDone) {
            this.allDone = allDone;
        }
    }
}