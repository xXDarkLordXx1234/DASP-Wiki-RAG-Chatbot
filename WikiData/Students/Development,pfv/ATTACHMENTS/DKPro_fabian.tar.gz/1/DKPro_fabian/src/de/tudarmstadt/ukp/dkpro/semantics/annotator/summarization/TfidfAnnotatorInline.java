package de.tudarmstadt.ukp.dkpro.semantics.annotator.summarization;

import java.util.HashMap;
import java.util.Map;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.Lemma;
import de.tudarmstadt.ukp.dkpro.core.type.Stem;
import de.tudarmstadt.ukp.dkpro.core.type.Token;
import de.tudarmstadt.ukp.dkpro.semantics.type.SummarySourceDocument;
import de.tudarmstadt.ukp.dkpro.semantics.type.Tfidf;

// TODO there is a bug in the tfidf annotator. In case of multi-document summarization, the global tf value is taken for each document! It should be the local tf value.
/**
 * Annotates tf.idf scores inside a single CAS. Multiple documents are indicated by SummmarySourceDocument annotations.
 * Tf.idf scores are either based on tokens, stems, or lemmas.
 * The string value of the used term is written to the annotation. Thus subsequent annotators can build a vector space from these tf.idf score without having to know whether token, stems, or lemmas were used in the first place.
 *
 * @author zesch
 *
 */
public class TfidfAnnotatorInline extends JCasAnnotator_ImplBase {

    public final static Logger logger = UIMAFramework.getLogger(TfidfAnnotatorInline.class);

    protected Map<String, Integer> tfMap;
    protected Map<String, Integer> dfMap;

    public static final String TYPE_TO_ANNOTATE = "TypeToAnnotate";
    
    /**
     * Valid annotation types that can be used with this annotator.
     * @author zesch
     *
     */
    public enum KnownTypes {
        Token,
        Stem,
        Lemma,
    }

    private KnownTypes typeToAnnotate;
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
    	super.initialize(context);

    	tfMap  = new HashMap<String, Integer>();
        dfMap = new HashMap<String, Integer>();
    	
        String type = (String) context.getConfigParameterValue(TYPE_TO_ANNOTATE);
        typeToAnnotate = KnownTypes.valueOf(type);
        
        if (typeToAnnotate == null) {
            throw new ResourceInitializationException(new Throwable("Unknown type: " + type));
        }
    }

    @Override
    public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.FINE, "Entering TfidfAnnotatorInline");            
        
        AnnotationIndex documentIndex;
        if (typeToAnnotate.equals(KnownTypes.Token)) {
            documentIndex = ((AnnotationIndex) jcas.getAnnotationIndex(Token.type));
        }
        else if (typeToAnnotate.equals(KnownTypes.Stem)) {
            documentIndex = ((AnnotationIndex) jcas.getAnnotationIndex(Stem.type));
        }
        else if (typeToAnnotate.equals(KnownTypes.Lemma)) {
            documentIndex = ((AnnotationIndex) jcas.getAnnotationIndex(Lemma.type));
        }
        else {
            throw new AnalysisEngineProcessException(new Throwable("Unknown type: " + typeToAnnotate));
        }

        
        // fill the tf and idf maps
        FSIterator summarySourceDocumentIter = jcas.getAnnotationIndex(SummarySourceDocument.type).iterator();
        while (summarySourceDocumentIter.hasNext()) {
            SummarySourceDocument ssd = (SummarySourceDocument) summarySourceDocumentIter.next();
            FSIterator sourceDocumentTermIterator = documentIndex.subiterator(ssd);
            
            Map<String,Integer> documentTfMap = getTfMap(sourceDocumentTermIterator);
            
            updateGlobalMaps(documentTfMap);
        }

        // write tfidf annotations for each term
        summarySourceDocumentIter.moveToFirst();
        while (summarySourceDocumentIter.hasNext()) {
            SummarySourceDocument ssd = (SummarySourceDocument) summarySourceDocumentIter.next();
            FSIterator sourceDocumentTermIterator = documentIndex.subiterator(ssd);
            while (sourceDocumentTermIterator.hasNext()) {
                Object termObject = sourceDocumentTermIterator.next();
                Term term = getTerm(termObject);
                
                double tfidfValue = getTfidfValue(term.value);

                Tfidf tfidf = new Tfidf(jcas);
                tfidf.setTfidfValue(tfidfValue);
                tfidf.setTerm(term.value);
                tfidf.setBegin(term.begin);
                tfidf.setEnd(term.end);
                tfidf.addToIndexes();
            }
        }
    }
    
    /**
     * @param term A term.
     * @return The tf.idf value for a given term.
     * @throws AnalysisEngineProcessException If the term is not found in the map.
     */
    private double getTfidfValue(String term) throws AnalysisEngineProcessException {
        if (!tfMap.containsKey(term) || !dfMap.containsKey(term)){
            throw new AnalysisEngineProcessException(new Throwable(term + " is not found in the tf.idf map."));
        }
        double tf  = tfMap.get(term);
        double df = dfMap.get(term);
        return (1 + Math.log(tf)) * (1/df);
    }
    
    /**
     * @param termObject A 
     * @return A term object constructed using either tokens, or stems, or lemmas.
     */
    private Term getTerm(Object termObject) {
        Term term = new Term();
        if (typeToAnnotate.equals(KnownTypes.Token)) {
            Token token = (Token) termObject;
            term.value = token.getCoveredText();
            term.begin = token.getBegin();
            term.end = token.getEnd();
        }
        else if (typeToAnnotate.equals(KnownTypes.Stem)) {
            Stem stem = (Stem) termObject;
            term.value = stem.getValue();
            term.begin = stem.getBegin();
            term.end = stem.getEnd();
        }
        else if (typeToAnnotate.equals(KnownTypes.Lemma)) {
            Lemma lemma = (Lemma) termObject;
            term.value = lemma.getValue();
            term.begin = lemma.getBegin();
            term.end = lemma.getEnd();
        }
        return term;
    }
    
    /**
     * @param sourceDocumentTermIter An iterator over the terms in the source document.
     * @return A token frequency map build from the source document terms.
     */
    private Map<String,Integer> getTfMap(FSIterator sourceDocumentTermIter) {
        Map<String,Integer> tfMap = new HashMap<String,Integer>();
        
        while (sourceDocumentTermIter.hasNext()) {
            Object termObject = sourceDocumentTermIter.next();
            Term term = getTerm(termObject);
            if (tfMap.containsKey(term.value)) {
                int value = tfMap.get(term.value) + 1;
                tfMap.put(term.value, value);
            }
            else {
                tfMap.put(term.value, 1);
            }
        }
        return tfMap;
    }
    
    /**
     * Updates the global term frequency maps with the values from a local term frequency maps build from a single source document.
     * @param localTfMap
     */
    private void updateGlobalMaps(Map<String,Integer> localTfMap) {
        for (String term : localTfMap.keySet()) {
            // update tf map
            if (this.tfMap.containsKey(term)) {
                int value = this.tfMap.get(term) + localTfMap.get(term);
                this.tfMap.put(term, value);
            }
            else {
                int value = localTfMap.get(term);
                this.tfMap.put(term, value);
            }
            
            // update idf map
            if (this.dfMap.containsKey(term)) {
                int value = this.dfMap.get(term) + 1;
                this.dfMap.put(term, value);
            }
            else {
                this.dfMap.put(term, 1);
            }
        }
    }
    
    /**
     * Inner class for representing terms.
     * 
     * @author zesch
     */
    class Term {
        String value;
        int begin;
        int end;
    }
}