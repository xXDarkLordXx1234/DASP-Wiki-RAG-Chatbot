package de.tudarmstadt.ukp.dkpro.core.util;

import static org.apache.uima.UIMAFramework.getXMLParser;
import static org.apache.uima.util.CasCreationUtils.mergeTypeSystems;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.uima.UIMAFramework;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.analysis_engine.impl.AnalysisEngineDescription_impl;
import org.apache.uima.cas.CAS;
import org.apache.uima.cas.CASException;
import org.apache.uima.cas.FSIndex;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.FeatureStructure;
import org.apache.uima.cas.Type;
import org.apache.uima.cas.TypeSystem;
import org.apache.uima.cas.text.AnnotationFS;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.collection.CasConsumer;
import org.apache.uima.collection.CollectionException;
import org.apache.uima.collection.CollectionProcessingEngine;
import org.apache.uima.collection.CollectionReader;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.collection.metadata.CpeDescription;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.cas.TOP;
import org.apache.uima.jcas.tcas.Annotation;
import org.apache.uima.resource.CasManager;
import org.apache.uima.resource.ResourceConfigurationException;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.resource.ResourceManager;
import org.apache.uima.resource.ResourceProcessException;
import org.apache.uima.resource.ResourceSpecifier;
import org.apache.uima.resource.metadata.ConfigurationParameterSettings;
import org.apache.uima.resource.metadata.ProcessingResourceMetaData;
import org.apache.uima.resource.metadata.TypeSystemDescription;
import org.apache.uima.util.CasCreationUtils;
import org.apache.uima.util.InvalidXMLException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;
import org.apache.uima.util.XMLInputSource;
import org.apache.uima.util.XMLParser;

import de.tudarmstadt.ukp.dkpro.core.type.DocumentMetaData;

public class UimaUtils {

	final static Logger logger = UIMAFramework.getLogger(UimaUtils.class);
    private final static String DATA_PATH_FILE = ".datapath";
    private final static String CHARSET = "UTF-8";

    private static boolean allowDataPathMissing = false;

    public static
    void setAllowDataPathMissing(
    		boolean aAllowDataPathMissing)
    {
		allowDataPathMissing = aAllowDataPathMissing;
	}

    public static
    boolean isAllowDataPathMissing()
    {
		return allowDataPathMissing;
	}

    /**
     * Read the datapath from the DATA_PATH_FILE in the project root.
     * @return The data path.
     * @throws IOException
     */
    public static
    String getDataPath()
    throws IOException
    {
        File file = new File(DATA_PATH_FILE);

    	if (!file.canRead() && allowDataPathMissing) {
    		return "";
    	}

        if (!file.exists()) {
            throw new IOException(DATA_PATH_FILE + " does not exist.");
        }
        else if (!file.isFile()) {
            throw new IOException(DATA_PATH_FILE + " is not a file.");
        }
        else if (!file.canRead()) {
            throw new IOException(DATA_PATH_FILE + " is not readable.");
        }

        String dataPath = null;
        BufferedReader bufferedReader  = new BufferedReader(new InputStreamReader(new FileInputStream(file), CHARSET));
        dataPath = bufferedReader.readLine();
        bufferedReader.close();

        return dataPath;
    }

    /**
     * If a descriptor file in a project is referenced by a relative path to ensure portability, it is not found from inside another project.
     * This helper method returns the file by trying to instantiate the file from each project in the datapath.
     * @param dataPath
     * @param descriptorFilePath
     * @return The descriptor file or throws IOException, if no file was found.
     * @throws IOException
     */
    public static File getDescriptorFile(String dataPath, String descriptorFilePath) throws IOException {
        String[] paths;
        if (OsUtils.getOsType().equals("Windows")) {
            paths = dataPath.split(";");
        }
        else if (OsUtils.getOsType().equals("Linux")) {
            paths = dataPath.split(":");
        }
        else {
            throw new IOException("Unknown operating system " + OsUtils.getOsType());
        }

        // try to instantiate file
        for (String path : paths) {
            System.out.println(path + File.separator + descriptorFilePath);
            File file = new File(path + File.separator + descriptorFilePath);
            if (file.isFile() && file.canRead()) {
                return file;
            }
        }

        throw new IOException("Could not get file: " + descriptorFilePath + " using datapath: " + dataPath);
    }


    /**
     * Returns the absolute descriptor file path.
     *
     * If a descriptor file in a project is referenced by a relative path to ensure portability, it is not found from inside another project.
     * If the given descriptor file path is relative, the method tries to instantiate the file from each project in the datapath. If it is
     * successful then the corresponding absolute path is returned. Otherwise an IOException is thrown.
     * @param dataPath
     * @param descriptorFilePath
     * @return The absolute descriptor path or throws IOException, if no file was found.
     * @throws IOException
     */
    public static
    String getAbsoluteDescriptorFilePath(
    		String dataPath,
    		String descriptorFilePath)
    throws IOException
    {
        String[] paths;
        if(descriptorFilePath==null || descriptorFilePath.length()==0) {
			throw new IllegalArgumentException("descriptorFilePath is empty");
		}

        if(dataPath==null || dataPath.length()==0) {
        	throw new IllegalArgumentException("dataPath is empty while getting ["+descriptorFilePath+"]");
        }

        if (OsUtils.getOsType().equals("Windows")) {
            if(descriptorFilePath.length()>1 && descriptorFilePath.charAt(1)==':') {
				return descriptorFilePath;
			}
        	paths = dataPath.split(";");

        }
        else if (OsUtils.getOsType().equals("Linux")) {
        	if(descriptorFilePath.length()>1 && descriptorFilePath.startsWith("/")) {
				return descriptorFilePath;
			}
        	paths = dataPath.split(":");
        }
        else {
            throw new IOException("Unknown operating system " + OsUtils.getOsType());
        }

        // try to instantiate file
        for (String path : paths) {
            path = path.replace('\\', '/');
            if (!new File(path).canRead()) {
            	logger.log(Level.SEVERE, path + " is not a valid path.");
            }

            System.out.println(path + "/" + descriptorFilePath);
            File file = new File(path + "/" + descriptorFilePath);
            if (file.isFile() && file.canRead()) {
                return file.getAbsolutePath();
            }
        }

        throw new IOException("Could not get file: " + descriptorFilePath + " using datapath: " + dataPath);
    }


    /**
     * Write the data path to DATA_PATH_FILE.
     * @param dataPath The data path.
     * @throws IOException
     */
    public static void setDataPath(String dataPath) throws IOException {
        File file = new File(DATA_PATH_FILE);
        if (file.exists()) {
            file.delete();
        }

        BufferedWriter out = new BufferedWriter(new FileWriter(file));
        out.write(dataPath);
        out.close();

        if (!file.exists()) {
            throw new IOException(DATA_PATH_FILE + " does not exist.");
        }
        else if (!file.isFile()) {
            throw new IOException(DATA_PATH_FILE + " is not a file.");
        }
        else if (!file.canRead()) {
            throw new IOException(DATA_PATH_FILE + " is not readable.");
        }
    }

    public static
    JCas processAnnotator(
    		String dataPathString,
    		File descriptorFile)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		AnalysisEngineProcessException
    {

        AnalysisEngine analysisEngine = getAnalysisEngine(dataPathString, descriptorFile);
        JCas jCas = analysisEngine.newJCas();
        analysisEngine.process(jCas);
        analysisEngine.destroy();

        return jCas;
    }

    public static
    JCas processAnnotator(
    		String dataPathString,
    		File descriptorFile,
    		String documentText)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		AnalysisEngineProcessException
    {
        AnalysisEngine analysisEngine = getAnalysisEngine(dataPathString, descriptorFile);
        JCas jCas = analysisEngine.newJCas();

        jCas.setDocumentText(documentText);
        analysisEngine.process(jCas);
        analysisEngine.destroy();

        return jCas;
    }

    public static
    JCas processAnnotator(
    		String dataPathString,
    		File descriptorFile,
    		String documentText,
    		String language)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		AnalysisEngineProcessException
    {
        AnalysisEngine analysisEngine = getAnalysisEngine(dataPathString, descriptorFile);
        JCas jCas = analysisEngine.newJCas();
        jCas.setDocumentLanguage(language);

        jCas.setDocumentText(documentText);
        analysisEngine.process(jCas);
        analysisEngine.destroy();

        return jCas;
    }

    public static
    JCas processAnnotator(
    		String dataPathString,
    		File descriptorFile,
    		String documentText,
    		Map<String,Object> configParameters)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		AnalysisEngineProcessException, ResourceConfigurationException
    {
    	return processAnnotator(dataPathString, descriptorFile.toURI().toURL(),
    			documentText, null, configParameters);
    }

    public static
    JCas processAnnotator(
    		AnalysisEngine analysisEngine,
    		String documentText,
    		String documentLanguage)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		AnalysisEngineProcessException, ResourceConfigurationException
    {
        JCas jCas = analysisEngine.newJCas();

        if (documentLanguage != null) {
        	jCas.setDocumentLanguage(documentLanguage);
        }
        jCas.setDocumentText(documentText);

        analysisEngine.process(jCas);
        analysisEngine.destroy();

        return jCas;
    }

    public static
    JCas processAnnotator(
    		String dataPathString,
    		URL descriptorUrl,
    		String documentText,
    		String documentLanguage,
    		Map<String, ? extends Object> configParameters)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		AnalysisEngineProcessException, ResourceConfigurationException
    {
    	AnalysisEngine analysisEngine = getAnalysisEngine(dataPathString, descriptorUrl);
        analysisEngine = configureAnalysisEngine(analysisEngine, configParameters);

    	return processAnnotator(analysisEngine, documentText, documentLanguage);
    }

    public static
    void processAnnotator(
    		String dataPathString,
    		File descriptorFile,
    		JCas jcas, Map<String,Object> configParameters)
    throws InvalidXMLException, ResourceInitializationException, IOException,
    		ResourceConfigurationException, AnalysisEngineProcessException
    {
        AnalysisEngine analysisEngine = getAnalysisEngine(dataPathString, descriptorFile);
        analysisEngine = configureAnalysisEngine(analysisEngine, configParameters);
        analysisEngine.process(jcas);
        analysisEngine.destroy();
    }

    public static
    void processAnnotator(
    		String dataPathString,
    		File descriptorFile,
    		JCas jcas)
    throws InvalidXMLException, ResourceInitializationException, IOException,
    		ResourceConfigurationException, AnalysisEngineProcessException
    {
        AnalysisEngine analysisEngine = getAnalysisEngine(dataPathString, descriptorFile);
        analysisEngine.process(jcas);
        analysisEngine.destroy();
    }

    public static
    void processConsumer(
    		String dataPathString,
    		File descriptorFile,
    		JCas jcas)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		ResourceProcessException
    {
        ResourceManager resMgr = UIMAFramework.newDefaultResourceManager();
        resMgr.setDataPath(dataPathString);

        XMLInputSource xmlInput = new XMLInputSource(descriptorFile);
        ResourceSpecifier specifier = UIMAFramework.getXMLParser().parseResourceSpecifier(xmlInput);

        CasConsumer consumer = UIMAFramework.produceCasConsumer(specifier, resMgr, null);
        consumer.processCas(jcas.getCas());
    }

    public static
    void processConsumer(
    		String dataPathString,
    		File descriptorFile,
    		JCas jcas, Map<String,? extends Object> configParameters)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		ResourceProcessException, ResourceConfigurationException
    {
    	processConsumer(dataPathString, descriptorFile.toURI().toURL(), jcas,
    			configParameters);
    }

    public static
    void processConsumer(
    		String dataPathString,
    		URL descriptor,
    		JCas jcas, Map<String,? extends Object> configParameters)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		ResourceProcessException, ResourceConfigurationException
    {
        ResourceManager resMgr = UIMAFramework.newDefaultResourceManager();
        resMgr.setDataPath(dataPathString);

        XMLInputSource xmlInput = new XMLInputSource(descriptor);
        ResourceSpecifier specifier = UIMAFramework.getXMLParser().parseResourceSpecifier(xmlInput);

        CasConsumer consumer = UIMAFramework.produceCasConsumer(specifier, resMgr, null);
        consumer = UimaUtils.configureConsumer(consumer, configParameters);
        consumer.processCas(jcas.getCas());
    }

// TODO this makes little sense like this. Can not be used for testing and can only be used to run the Reader without doing anything.
    public static
    void processReader(
    		String dataPathString,
    		File descriptorFileReader)
    throws IOException, InvalidXMLException, ResourceInitializationException,
    		CollectionException
    {
        ResourceManager resMgr = UIMAFramework.newDefaultResourceManager();
        resMgr.setDataPath(dataPathString);
        CasManager casManager = resMgr.getCasManager();

        XMLInputSource xmlInput = new XMLInputSource(descriptorFileReader);
        ResourceSpecifier specifier = UIMAFramework.getXMLParser().parseResourceSpecifier(xmlInput);
        CollectionReader reader  = UIMAFramework.produceCollectionReader(specifier, resMgr, null);

        // With collection readers, the type system is only correctly initialized, if we add the MetaData to the CAS manager
        casManager.addMetaData((ProcessingResourceMetaData) reader.getMetaData());
        casManager.defineCasPool("pool", 3, null);

        while (reader.hasNext()) {
            CAS cas = casManager.getCas("pool");
            reader.getNext(cas);
            cas.release();  // release CAS. Otherwise you can only have as many CASes as defined by the limit constant when defining the CAS pool
        }
    }

    /**
     * Get a new collection reader.
     *
     * @param aResMgr a resource manager.
     * @param aUrl the descriptor URL.
     * @return the collection reader.
     * @throws IOException if the descriptor could not be accessed.
     * @throws InvalidXMLException if the descriptor could not be parsed.
     * @throws ResourceInitializationException if the collection reader could not
     * 		   be initialized.
     */
    public static
    CollectionReader getCollectionReader(
    		ResourceManager aResMgr,
    		URL aUrl)
    throws IOException, InvalidXMLException, ResourceInitializationException
    {
        XMLInputSource xmlInput = new XMLInputSource(aUrl);
        ResourceSpecifier specifier = UIMAFramework.getXMLParser().parseResourceSpecifier(xmlInput);
        return UIMAFramework.produceCollectionReader(specifier, aResMgr, null);
    }

    /**
     * Note: might return before CPE processing has finished.
     * @param dataPathString
     * @param descriptorFile
     * @throws IOException
     * @throws InvalidXMLException
     * @throws ResourceInitializationException
     */
    public static void processCpe(String dataPathString, File descriptorFile) throws IOException, InvalidXMLException, ResourceInitializationException {
        ResourceManager resMgr = UIMAFramework.newDefaultResourceManager();
        resMgr.setDataPath(dataPathString);

        XMLInputSource xmlInput = new XMLInputSource(descriptorFile);
        CpeDescription cpeDesc = UIMAFramework.getXMLParser().parseCpeDescription(xmlInput);
        CollectionProcessingEngine cpe = UIMAFramework.produceCollectionProcessingEngine(cpeDesc, resMgr, null);
        cpe.process();
    }

    public static
    AnalysisEngine getAnalysisEngine(
    		String dataPathString,
    		URL descriptorUrl)
    throws IOException, InvalidXMLException, ResourceInitializationException
    {
    	return getAnalysisEngine(dataPathString, descriptorUrl, null);
    }

    public static
    AnalysisEngine getAnalysisEngine(
    		String dataPathString,
    		URL descriptorUrl,
    		Map<String, Object> parameters)
    throws IOException, InvalidXMLException, ResourceInitializationException
    {
        ResourceManager resMgr = UIMAFramework.newDefaultResourceManager();
        resMgr.setDataPath(dataPathString);

        XMLInputSource xmlInput = new XMLInputSource(descriptorUrl);
        AnalysisEngineDescription_impl aed = (AnalysisEngineDescription_impl)
        	UIMAFramework.getXMLParser().parseResourceSpecifier(xmlInput);

        if (parameters != null) {
	        ConfigurationParameterSettings cps = aed.getMetaData().getConfigurationParameterSettings();
	        for (String param : parameters.keySet()) {
	            cps.setParameterValue(param, parameters.get(param));
	        }
        }

        return UIMAFramework.produceAnalysisEngine(aed, resMgr, null);
    }

    public static
    AnalysisEngine getAnalysisEngine(
    		String dataPathString,
    		File descriptorFile)
    throws IOException, InvalidXMLException, ResourceInitializationException
    {
    	return getAnalysisEngine(dataPathString, descriptorFile.toURI().toURL());
    }

    public static
    AnalysisEngine configureAnalysisEngine(
    		AnalysisEngine analysisEngine,
    		Map<String, ? extends Object> configParameters)
    throws IOException, InvalidXMLException, ResourceInitializationException, ResourceConfigurationException
    {
    	if (configParameters != null) {
	        for (String key : configParameters.keySet()) {
	            analysisEngine.setConfigParameterValue(key, configParameters.get(key));
	        }
    	}
        analysisEngine.reconfigure();
        return analysisEngine;
    }

    public
    static CasConsumer configureConsumer(
    		CasConsumer casConsumer,
    		Map<String, ? extends Object> configParameters)
    throws IOException, InvalidXMLException, ResourceInitializationException, ResourceConfigurationException {
        for (String key : configParameters.keySet()) {
            casConsumer.setConfigParameterValue(key, configParameters.get(key));
        }
        casConsumer.reconfigure();
        return casConsumer;
    }

    /**
     * Reconfigure a collection reader.
     * @param cr
     * @param configParameters
     * @return
     * @throws IOException
     * @throws InvalidXMLException
     * @throws ResourceInitializationException
     * @throws ResourceConfigurationException
     */
    public static CollectionReader reconfigureCollectionReader(CollectionReader cr, Map<String,Object> configParameters) throws IOException, InvalidXMLException, ResourceInitializationException, ResourceConfigurationException {
        for (String key : configParameters.keySet()) {
            cr.setConfigParameterValue(key, configParameters.get(key));
        }
        cr.reconfigure();
        return cr;
    }

    /**
     * Configure a collection reader description before it is initialized.
     * @param crd
     * @param configParameters
     * @return
     * @throws IOException
     * @throws InvalidXMLException
     * @throws ResourceInitializationException
     * @throws ResourceConfigurationException
     */
    public static CollectionReaderDescription configureCollectionReader(CollectionReaderDescription crd, Map<String,Object> configParameters) throws IOException, InvalidXMLException, ResourceInitializationException, ResourceConfigurationException {
        ConfigurationParameterSettings configParameterSettings = crd.getCollectionReaderMetaData().getConfigurationParameterSettings();
        for (String key : configParameters.keySet()) {
            configParameterSettings.setParameterValue(key, configParameters.get(key));
        }
        crd.getMetaData().setConfigurationParameterSettings(configParameterSettings);
        return crd;
    }

    /**
     * Creates a JCas with initialized type system as indicated by the given type files.
     * @param dataPath The datapath where the type files can be found.
     * @param typeFiles A list of type files to initialize within the JCas.
     * @return A JCas with initialized type system as indicated by the given type files.
     * @throws InvalidXMLException
     * @throws IOException
     * @throws ResourceInitializationException
     * @throws CASException
     */
    public static JCas getJCasWithTypeSystem(String dataPath, List<String> typeFiles) throws InvalidXMLException, IOException, ResourceInitializationException, CASException {

        List<TypeSystemDescription> typeSystemDescriptions = new ArrayList<TypeSystemDescription>();
        for (String typeFile : typeFiles) {
            XMLInputSource xmlInputType = new XMLInputSource(typeFile);
            typeSystemDescriptions.add(UIMAFramework.getXMLParser().parseTypeSystemDescription(xmlInputType));
        }

        TypeSystemDescription tsdAll = CasCreationUtils.mergeTypeSystems(typeSystemDescriptions);

        CAS cas = CasCreationUtils.createCas(tsdAll, null, null);
        return cas.getJCas();

    }

    /**
     * Creates a type system from a descriptor.
     *
     * Code was suggested by Thilo Goetz on uima-user mailinglist.
     *
     * @param typeSystemDescriptor The name (and path) of the type system descriptor.
     * @return A TypeSystem object according to the typeSystemDescriptor.
     * @throws InvalidXMLException
     * @throws IOException
     * @throws ResourceInitializationException
     */
    public static TypeSystem createTypeSystemFromDescriptor(String typeSystemDescriptor) throws InvalidXMLException, IOException, ResourceInitializationException {
        // Get XML parser from framework
        XMLParser xmlParser = UIMAFramework.getXMLParser();

        // Parse type system descriptor
        TypeSystemDescription tsDesc = xmlParser.parseTypeSystemDescription(new XMLInputSource( typeSystemDescriptor));

        // Use type system description to create CAS and get the type system object
        return CasCreationUtils.createCas(tsDesc, null, null).getTypeSystem();
    }

    /**
     * @param iter An UIMA FSIterator.
     * @param start A start offset.
     * @param end A end offset.
     * @return All annotations from the iterator that fully fall into the offsets indicated by start and end.
     */
    public static List<Annotation> getAnnotations(FSIterator iter, int start, int end) {
        iter.moveToFirst();
        List<Annotation> list = new ArrayList<Annotation>();
        while (iter.hasNext()) {
            Annotation a = (Annotation) iter.next();
            if (a.getBegin() >= start && a.getEnd() <= end) {
                list.add(a);
            }
        }
        return list;
    }

    // from the UIMA mailing list - posted by Thilo Goetz
    /**
     * Find a covering parent annotation of a certain type, e.g., the sentence containing a given
     * annotation.
     *
     * @param cas The CAS.
     * @param childAnnotation The annotation that we want to find a parent for (e.g., a token).
     * @param parentType The type of covering annotation we're looking for.
     * @return A parent annotation, if it exists; <code>null</code> else.
     */
    public static FeatureStructure findParentAnnotation(CAS cas, AnnotationFS childAnnotation, Type parentType) {
        final int start = childAnnotation.getBegin();
        final int end = childAnnotation.getEnd();
        // Find a parent FS by searching in the annotation index. Start by
        // creating a temp parent FS
        // which is only used to position an iterator. If this is done many
        // times, the search FS should
        // be cached and only the start/end position modified as necessary
        // (creating a FS allocates
        // space in the CAS that is not garbage collected).
        FeatureStructure searchFS = cas.createAnnotation(parentType, start, end);
        FSIterator parentIterator = cas.getAnnotationIndex(parentType).iterator();
        // Position the iterator.
        parentIterator.moveTo(searchFS);
        // Return parent at position if it is indeed a covering annotation.
        if (parentIterator.isValid()) {
            AnnotationFS candidateParent = (AnnotationFS) parentIterator.get();
            if ((candidateParent.getBegin() <= start) && (candidateParent.getEnd() >= end)) {
                return candidateParent;
            }
        }
        // If no parent annotation could be found.
        return null;
    }


//// Code to create ResourceSpecifiers without a descriptor. Not in use yet.
//    public static AnalysisEngine getAnalysisEngine( Class<? extends AnalysisComponent> componentClass, TypeSystemDescription typeSystem, Object ... configurationParameters) throws ResourceInitializationException {
//
//        // create the descriptor and set configuration parameters
//        AnalysisEngineDescription desc = new AnalysisEngineDescription_impl();
//        desc.setFrameworkImplementation(Constants.JAVA_FRAMEWORK_NAME);
//        desc.setPrimitive(true);
//        desc.setAnnotatorImplementationName(componentClass.getName());
//        setConfigurationParameters(desc, configurationParameters);
//
//        // set the type system
//        if (typeSystem != null) {
//            desc.getAnalysisEngineMetaData().setTypeSystem(typeSystem);
//        }
//
//        // create the AnalysisEngine, initialize it and return it
//        AnalysisEngine engine = new PrimitiveAnalysisEngine_impl();
//        engine.initialize(desc, null);
//        return engine;
//     }
//
//     public static CollectionReader getCollectionReader( Class<? extends CollectionReader> readerClass, TypeSystemDescription typeSystem, Object ... configurationParameters) throws ResourceInitializationException {
//
//         //  create the descriptor and set configuration parameters
//         CollectionReaderDescription desc = new CollectionReaderDescription_impl();
//         desc.setFrameworkImplementation(Constants.JAVA_FRAMEWORK_NAME);
//         desc.setImplementationName(readerClass.getName());
//         setConfigurationParameters(desc, configurationParameters);
//
//         // set the type system
//         if (typeSystem != null) {
//             desc.getCollectionReaderMetaData().setTypeSystem(typeSystem);
//         }
//
//         // create the CollectionReader
//         CollectionReader reader;
//         try {
//             reader = readerClass.newInstance();
//         } catch (InstantiationException e) {
//             throw new ResourceInitializationException(e);
//         } catch (IllegalAccessException e) {
//             throw new ResourceInitializationException(e);
//         }
//
//         // initialize the CollectionReader and return it
//         reader.initialize(desc, null);
//         return reader;
//     }
//
//     public static TypeSystemDescription getTypeSystem( Class<?> ... annotationClasses) {
//         TypeSystemDescription typeSystem = new TypeSystemDescription_impl();
//         List<Import> imports = new ArrayList<Import>();
//         for (Class<?> annotationClass : annotationClasses) {
//             Import imp = new Import_impl();
//             imp.setName(annotationClass.getName());
//             imports.add(imp);
//         }
//         Import[] importArray = new Import[imports.size()];
//         typeSystem.setImports(imports.toArray(importArray));
//         return typeSystem;
//     }
//
//     private static void setConfigurationParameters( ResourceCreationSpecifier specifier, Object ... configurationParameters) {
//         if (configurationParameters.length % 2 != 0) {
//             String message = "a value must be specified for each parameter";
//             throw new IllegalArgumentException(message);
//         }
//         ResourceMetaData metaData = specifier.getMetaData();
//         ConfigurationParameterDeclarations paramDecls = metaData.getConfigurationParameterDeclarations();
//         ConfigurationParameterSettings paramSettings = metaData.getConfigurationParameterSettings();
//         for (int i = 0; i < configurationParameters.length; i += 2) {
//             String name = (String)configurationParameters[i];
//             Object value = configurationParameters[i + 1];
//             String javaClassName = value.getClass().getName();
//             String uimaType = javaUimaTypeMap.get(javaClassName);
//             if (uimaType == null) {
//                 String message = "invalid parameter type " + javaClassName;
//                 throw new IllegalArgumentException(message);
//             }
//             ConfigurationParameter param = new ConfigurationParameter_impl();
//             param.setName(name);
//             param.setType(uimaType);
//             paramDecls.addConfigurationParameter(param);
//             paramSettings.setParameterValue(name, value);
//          }
//     }
//
//     private static final Map<String, String> javaUimaTypeMap = new HashMap<String, String>();
//     static {
//         javaUimaTypeMap.put(
//                 boolean.class.getName(),
//                 ConfigurationParameter.TYPE_BOOLEAN);
//         javaUimaTypeMap.put(
//                 float.class.getName(),
//                 ConfigurationParameter.TYPE_FLOAT);
//         javaUimaTypeMap.put(
//                 int.class.getName(),
//                 ConfigurationParameter.TYPE_INTEGER);
//         javaUimaTypeMap.put(
//                 String.class.getName(),
//                 ConfigurationParameter.TYPE_STRING);
//     };

	/**
	 * Returns an annotation of the specified type, which occurs exactly once in the JCas.
	 * @param jcas
	 * @param type
	 * @return
	 * @throws AnalysisEngineProcessException
	 */
	public static Annotation getSingleRequiredAnnotation(JCas jcas, int type) throws AnalysisEngineProcessException {
		Annotation result = null;
		AnnotationIndex annoIndex = jcas.getAnnotationIndex(type);
		FSIterator annoIt = annoIndex.iterator();
		if(annoIt.hasNext()) {
			result = (Annotation)annoIt.next();
		} else {
			throw new AnalysisEngineProcessException(new Throwable("no Annotation exists for type "+type));
			// TODO add message
		}
		if(annoIt.hasNext()) {
			throw new AnalysisEngineProcessException(new Throwable("more than one Annotation exists."));
			// TODO add message
		}
		return result;
	}

	public static TOP getSingleRequiredTOP(JCas jcas, int type) throws AnalysisEngineProcessException {
		TOP result = null;
		FSIterator annoIt = jcas.getJFSIndexRepository().getAllIndexedFS(type);
		if(annoIt.hasNext()) {
			result = (TOP)annoIt.next();
		} else {
			throw new AnalysisEngineProcessException(new Throwable("no TOP exists for type "+type));
			// TODO add message
		}
		if(annoIt.hasNext()) {
			throw new AnalysisEngineProcessException(new Throwable("more than one TOP exists."));
			// TODO add message
		}
		return result;
	}

	/**
	 * Load all the given types and return them in a merged type system.
	 *
	 * @param resMgr a resource manager through which to load the types.
	 * @param types the type names as via import-by-name (no .xml extension)
	 * @return the merged type system.
	 * @throws IOException if there was a error resolving a type name.
	 * @throws InvalidXMLException if the type system could not be parsed.
	 * @throws ResourceInitializationException the the type sytems could not be merged.
	 */
	public static
	TypeSystemDescription loadTypes(
			ResourceManager resMgr,
			String... types)
	throws IOException, InvalidXMLException, ResourceInitializationException
	{
        List<TypeSystemDescription> tsdList = new ArrayList<TypeSystemDescription>();
		for (String type : types) {
			URL url = resMgr.resolveRelativePath(type.replace(".", "/")+".xml");
			if (url == null) {
				throw new IOException("Unable to resolve XML file for ["+type+"]");
			}
	        XMLInputSource xmlInputType1 = new XMLInputSource(url);
	        tsdList.add(getXMLParser().parseTypeSystemDescription(xmlInputType1));
		}

        return mergeTypeSystems(tsdList, resMgr);
	}

	/**
	 * Copy the {@link DocumentMetaData} annotation from one view to another.
	 *
	 * @param aSourceView the source.
	 * @param aTargetView the target.
	 */
	public static
	void copyMetaData(
			final JCas aSourceView,
			final JCas aTargetView)
	{
		DocumentMetaData docMetaData = new DocumentMetaData(aTargetView);
		DocumentMetaData dmd = getMetaData(aSourceView);
		docMetaData.setDocumentId(dmd.getDocumentId());
		docMetaData.setDocumentUri(dmd.getDocumentUri());
		docMetaData.addToIndexes(aTargetView);
	}

	/**
	 * Get the {@link DocumentMetaData} for the given JCas.
	 *
	 * @param aJCas the JCas.
	 */
	public static
	DocumentMetaData getMetaData(
			final JCas aJCas)
	{
		FSIndex docMetaDataIndex = aJCas.getAnnotationIndex(DocumentMetaData.type);
		FSIterator it = docMetaDataIndex.iterator();
		return (DocumentMetaData) it.next();
	}
}