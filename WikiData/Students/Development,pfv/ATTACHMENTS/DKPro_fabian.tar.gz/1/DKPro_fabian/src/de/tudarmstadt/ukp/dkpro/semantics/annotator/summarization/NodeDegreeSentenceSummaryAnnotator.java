package de.tudarmstadt.ukp.dkpro.semantics.annotator.summarization;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.FSIterator;
import org.apache.uima.cas.text.AnnotationIndex;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.cas.FSArray;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.util.Level;
import org.apache.uima.util.Logger;

import de.tudarmstadt.ukp.dkpro.core.type.Sentence;
import de.tudarmstadt.ukp.dkpro.semantics.type.SentencePair;
import de.tudarmstadt.ukp.dkpro.semantics.type.Summary;
import de.tudarmstadt.ukp.dkpro.semantics.type.SummarySourceDocument;


/**
 * Creates a summary by selecting the sentences from a document that have the highest weighted node degree with the sentence graph.
 * The sentence graph is a fully connected graph of sentence pairs with similarity scores.
 * 
 * The parameter CompressionRatio controls the size of the summary. For example, a value of 0.5 means that the length of the summary is half of the length of the original document.
 * The parameter SingleGraph indicates whether all source documents are merged into a single graph (true), or each source document is represented by a graph of its own (false). 
 *   It must always be set to the same value set in the SentencePairAnnotator. The safest way is to use both within an aggregate AE, and use a shared parameter .
 * If SingleGraph is false, it is guanranteed that each source document contributes to the summary.
 * 
 * @author zesch
 *
 */
public class NodeDegreeSentenceSummaryAnnotator extends JCasAnnotator_ImplBase {

    public final static Logger logger = UIMAFramework.getLogger(NodeDegreeSentenceSummaryAnnotator.class);

    public static final String COMPRESSION_RATIO = "CompressionRatio";
    public static final String SINGLE_GRAPH = "SingleGraph";

    private float compressionRatio;
    private boolean singleGraph;
    
    private JCas jcas;
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
        super.initialize(context);
        
        this.compressionRatio = (Float) context.getConfigParameterValue(COMPRESSION_RATIO);
        this.singleGraph = (Boolean) context.getConfigParameterValue(SINGLE_GRAPH);    
    } 
        
    @Override
    public void process(JCas jcas) throws AnalysisEngineProcessException {
        logger.log(Level.FINE, "Entering NodeDegreeSentenceSummaryAnnotator");            
    
        this.jcas = jcas;
        
        List<Sentence> sortedSentences = null;
        long nrOfSentencesInSummary = 0;
        
        // all documents are treated as a single graph
        if (singleGraph) {

            AnnotationIndex sentenceIndex = jcas.getAnnotationIndex(Sentence.type);
            FSIterator sentencePairIter = ((AnnotationIndex) jcas.getAnnotationIndex(SentencePair.type)).iterator();
            sortedSentences = getSentencesSortedByScore(sentencePairIter, sentenceIndex.iterator());

            // the number of sentences in the summary depends on the compression ratio
            long nrOfSentences = sentenceIndex.size();
            nrOfSentencesInSummary = Math.round(nrOfSentences * compressionRatio);
        }
        // each document is treated as a graph of its own
        else {  
            List<List<Sentence>> sortedSentencesList = new ArrayList<List<Sentence>>();

            long nrOfSentences = 0;
            FSIterator sourceDocumentIter = jcas.getAnnotationIndex(SummarySourceDocument.type).iterator();
            while (sourceDocumentIter.hasNext()) {
                SummarySourceDocument summarySourceDocument = (SummarySourceDocument) sourceDocumentIter.next();
                FSIterator sentenceIter = jcas.getAnnotationIndex(Sentence.type).subiterator(summarySourceDocument);
                FSIterator sentencePairIter = jcas.getAnnotationIndex(SentencePair.type).subiterator(summarySourceDocument);
            
                // increase sentence counter
                while (sentenceIter.hasNext()) {
                    sentenceIter.next();
                    nrOfSentences++;
                }
                sentenceIter.moveToFirst();
                
                sortedSentencesList.add( getSentencesSortedByScore(sentencePairIter, sentenceIter) );
            }

            // merge the sorted sentences according to their rank in the lists (i.e. all sentences ranked first are grouped at the beginning of the list, and so on)
            sortedSentences = mergeSortedSentences(sortedSentencesList);
            
            int nrOfDocuments = sortedSentencesList.size();
            
            // the number of sentences in the summary depends on the compression ratio and the number of source documents
            // There should be a equal number of sentences from each document 
            nrOfSentencesInSummary = Math.round(nrOfSentences * compressionRatio);
            if (nrOfDocuments > 1) {
                nrOfSentencesInSummary = (new Double(Math.floor(nrOfSentencesInSummary / nrOfDocuments)).intValue() + 1) * nrOfDocuments;
            }
        }
        
        if (sortedSentences == null) {
            throw new AnalysisEngineProcessException(new Throwable("Sorted sentences is null. This should never happen. Summarization failed."));
        }

        if (sortedSentences.size() == 0) {
            logger.log(Level.WARNING, "No sentences in document with text: " + jcas.getDocumentText());
            return;
        }

        addSummaryAnnotation(nrOfSentencesInSummary, sortedSentences);
    }

    /**
     * @param sentencePairIter An iterator over the sentence pairs.
     * @param sentenceIter An iterator over the sentences.
     * @return The sentences from the sentence pairs sorted by their score.
     */
    private List<Sentence> getSentencesSortedByScore(FSIterator sentencePairIter, FSIterator sentenceIter) {
        Map<Sentence,List<Double>> sentenceWeightedDegreeMap = getSentenceWeightedDegreeMap(sentencePairIter);
        Map<Sentence,Double> sentenceNormalizedWeightedDegreeMap = normalizeWeightedDegreeMap(sentenceWeightedDegreeMap);
        List<Sentence> sortedSentences = new ArrayList<Sentence>();
        
        // if there are sentence pair annotations
        if (sentenceWeightedDegreeMap.size() > 1) {
            sortedSentences.addAll(sortByValue(sentenceNormalizedWeightedDegreeMap).keySet());
        }
        // if there are no sentence pair annotations, the document is empty or has only on sentence.
        else {
            if (sentenceIter.hasNext()) {
                sortedSentences.add((Sentence) sentenceIter.next());
            }
        }
        return sortedSentences;
    }

    /**
     * Merging means that in the resulting list first contains the highest sorted sentence from each document, then the second highest sorted sentence from each document, and so on.
     * 
     * @param sortedSentencesList A list of sorted sentence lists.
     * @return A merged list of sorted sentences.
     */
    private List<Sentence> mergeSortedSentences(List<List<Sentence>> sortedSentencesList) {
        List<Sentence> mergedSentenceList = new ArrayList<Sentence>();

        int sizeOfLargestList = 0;
        for (List<Sentence> item : sortedSentencesList) {
            if (item.size() > sizeOfLargestList) {
                sizeOfLargestList = item.size();
            }
        }
        int nrOfLists = sortedSentencesList.size();
        
        int arraySize = sizeOfLargestList * nrOfLists;
        
        Sentence[] sentenceArray = new Sentence[arraySize];
        
        for (int i=0; i<sortedSentencesList.size(); i++) {
            List<Sentence> list = sortedSentencesList.get(i);
            for (int j=0; j<list.size(); j++) {
                Sentence item = list.get(j);
                int offset = i*sizeOfLargestList + j;
                sentenceArray[offset] = item;
            }
        }
        
        for (int k=0; k<arraySize; k++) {
            if (sentenceArray[k] != null) {
                mergedSentenceList.add(sentenceArray[k]);
            }
        }

        return mergedSentenceList;
    }
    
    /**
     * @param sentenceWeightedDegreeMap A mapping between sentences and their weighted degree scores.
     * @return A mapping between sentences and their normalized weighted degree scores.
     */
    private Map<Sentence,Double> normalizeWeightedDegreeMap(Map<Sentence,List<Double>> sentenceWeightedDegreeMap) {
        Map<Sentence,Double> normalizedMap = new HashMap<Sentence,Double>();
        for (Sentence sentence : sentenceWeightedDegreeMap.keySet()) {
            List<Double> similarities = sentenceWeightedDegreeMap.get(sentence);
            double sum = 0.0;
            for (Double similarity : similarities) {
                sum += similarity;
            }
            double normalizedSum = sum / similarities.size();
            normalizedMap.put(sentence, normalizedSum);
        }
        return normalizedMap;
    }
    
    /**
     * A mapping between the a sentence and its similarity scores.
     * 
     * @param sentencePairIter An iterator over all sentence pairs in this document or the document collection.
     * @return A mapping between a sentence and its similarity scores.
     */
    private Map<Sentence,List<Double>> getSentenceWeightedDegreeMap(FSIterator sentencePairIter) {
        Map<Sentence,List<Double>> sentenceWeightedDegreeMap = new HashMap<Sentence,List<Double>>();
        
        while (sentencePairIter.hasNext()) {
            SentencePair sp = (SentencePair) sentencePairIter.next();
            Sentence s1 = sp.getSentence1();
            Sentence s2 = sp.getSentence2();
            double similarity = sp.getSimilarity();
            updateWeightedDegreeMap(sentenceWeightedDegreeMap, s1, similarity);
            updateWeightedDegreeMap(sentenceWeightedDegreeMap, s2, similarity);
        }

        return sentenceWeightedDegreeMap;
    }
    
    /**
     * Updates the WeightedDegreeMap given a sentence and a similarity score.
     * 
     * @param sentenceWeightedDegreeMap The map with the sentences and its degree scores.
     * @param sentence A sentence annotation.
     * @param similarity The similarity score of this sentence with another sentence.
     */
    private void updateWeightedDegreeMap(Map<Sentence,List<Double>> sentenceWeightedDegreeMap, Sentence sentence, double similarity) {

        List<Double> similarities;
        if (sentenceWeightedDegreeMap.containsKey(sentence)) {
            similarities = sentenceWeightedDegreeMap.get(sentence);
        }
        else {
            similarities = new ArrayList<Double>();
        }
        similarities.add(similarity);
        sentenceWeightedDegreeMap.put(sentence, similarities);
    }
    
    
    /**
     * Sorts the entries of the map by their value.
     * 
     * @param map The SentenceWeigthedDegreeMap.
     * @return The map sorted by the values in descending order.
     */
    private Map<Sentence,Double> sortByValue(Map<Sentence, Double> map) {
        List<Map.Entry<Sentence, Double>> list = new LinkedList<Map.Entry<Sentence, Double>>(map.entrySet());
        Collections.sort(list, new ValueComparator());
        Map<Sentence,Double> result = new LinkedHashMap<Sentence,Double>();
        for (Map.Entry<Sentence, Double> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    /**
     * Adds a summary annotation.
     * 
     * @param nrOfSentences The number of sentences that should appear in the summary.
     * @param sortedSentences The list of sorted sentences.
     */
    private void addSummaryAnnotation(long nrOfSentencesInSummary, List<Sentence> sortedSentences) {
                
        // there needs to be at least one sentence in each summary
        if (nrOfSentencesInSummary < 1) {
            nrOfSentencesInSummary = 1;
        }

        // create the summary annotation
        Summary summary = new Summary(jcas);
        FSArray sentenceArray = new FSArray(jcas, (int) nrOfSentencesInSummary);
        for (int i=0; i<nrOfSentencesInSummary; i++) {
            Sentence sentence = sortedSentences.get(i);
            sentenceArray.set(i, sentence);
        }
        summary.setSentences(sentenceArray);
        summary.addToIndexes();
    }
    
    /**
     * Compares entries of the SentenceWeightedDegreeMap by their weighted node degree value.
     * 
     * @author zesch
     *
     */
    class ValueComparator implements Comparator<Map.Entry<Sentence, Double>> {

        public int compare(Entry<Sentence, Double> e1, Entry<Sentence, Double> e2) {
            double c1 = e1.getValue();
            double c2 = e2.getValue();

            if (c1 < c2) {
                return 1;
            } else if (c1 > c2) {
                return -1;
            } else {
                return 0;
            }
        }
    }
}