

/* First created by JCasGen Wed Jan 28 13:01:14 CET 2009 */
package de.tudarmstadt.ukp.dkpro.semantics.type;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.tcas.Annotation;


/** 
 * Updated by JCasGen Wed Jan 28 13:01:14 CET 2009
 * XML source: /home/zesch/workspace/dkpro_semantics/desc/type/KeyphraseCandidatePair.xml
 * @generated */
public class KeyphraseCandidatePair extends Annotation {
  /** @generated
   * @ordered 
   */
  public final static int typeIndexID = JCasRegistry.register(KeyphraseCandidatePair.class);
  /** @generated
   * @ordered 
   */
  public final static int type = typeIndexID;
  /** @generated  */
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected KeyphraseCandidatePair() {}
    
  /** Internal - constructor used by generator 
   * @generated */
  public KeyphraseCandidatePair(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public KeyphraseCandidatePair(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public KeyphraseCandidatePair(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {}
     
 
    
  //*--------------*
  //* Feature: Candidate1

  /** getter for Candidate1 - gets 
   * @generated */
  public KeyphraseCandidate getCandidate1() {
    if (KeyphraseCandidatePair_Type.featOkTst && ((KeyphraseCandidatePair_Type)jcasType).casFeat_Candidate1 == null)
      jcasType.jcas.throwFeatMissing("Candidate1", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    return (KeyphraseCandidate)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr, ((KeyphraseCandidatePair_Type)jcasType).casFeatCode_Candidate1)));}
    
  /** setter for Candidate1 - sets  
   * @generated */
  public void setCandidate1(KeyphraseCandidate v) {
    if (KeyphraseCandidatePair_Type.featOkTst && ((KeyphraseCandidatePair_Type)jcasType).casFeat_Candidate1 == null)
      jcasType.jcas.throwFeatMissing("Candidate1", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    jcasType.ll_cas.ll_setRefValue(addr, ((KeyphraseCandidatePair_Type)jcasType).casFeatCode_Candidate1, jcasType.ll_cas.ll_getFSRef(v));}    
   
    
  //*--------------*
  //* Feature: Candidate2

  /** getter for Candidate2 - gets 
   * @generated */
  public KeyphraseCandidate getCandidate2() {
    if (KeyphraseCandidatePair_Type.featOkTst && ((KeyphraseCandidatePair_Type)jcasType).casFeat_Candidate2 == null)
      jcasType.jcas.throwFeatMissing("Candidate2", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    return (KeyphraseCandidate)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr, ((KeyphraseCandidatePair_Type)jcasType).casFeatCode_Candidate2)));}
    
  /** setter for Candidate2 - sets  
   * @generated */
  public void setCandidate2(KeyphraseCandidate v) {
    if (KeyphraseCandidatePair_Type.featOkTst && ((KeyphraseCandidatePair_Type)jcasType).casFeat_Candidate2 == null)
      jcasType.jcas.throwFeatMissing("Candidate2", "de.tudarmstadt.ukp.dkpro.semantics.type.KeyphraseCandidatePair");
    jcasType.ll_cas.ll_setRefValue(addr, ((KeyphraseCandidatePair_Type)jcasType).casFeatCode_Candidate2, jcasType.ll_cas.ll_getFSRef(v));}    
  }

    